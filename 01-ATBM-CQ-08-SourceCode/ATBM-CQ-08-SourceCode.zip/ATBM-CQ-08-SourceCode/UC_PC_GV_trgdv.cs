﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ATBM;
using static ATBM.UC_PhanCong_TDV;

namespace ATBM
{
    public partial class UC_PC_GV_trgdv : UserControl
    {
        public UC_PC_GV_trgdv()
        {
            InitializeComponent();
        }

        private void UC_PC_GV_trgdv_Load(object sender, EventArgs e)
        {
            label_infor_gv.Text += UC_Xem_GV.MaGV;
            string query_string = $"select * from admin1.x_phancong where magv = '{UC_Xem_GV.MaGV}'";
            DataSet ds_phancong = new DataSet();
            try
            {
                using (Oracle.ManagedDataAccess.Client.OracleConnection connection = new Oracle.ManagedDataAccess.Client.OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    //lấy dữ liệu từ bảng
                    Oracle.ManagedDataAccess.Client.OracleDataAdapter adapter = new Oracle.ManagedDataAccess.Client.OracleDataAdapter(query_string, connection);
                    adapter.Fill(ds_phancong);
                    // đóng kết nối
                    connection.Close();
                    // rót dữ liệu vào datagridview
                    dataGridView_PC_GV.DataSource = ds_phancong.Tables[0];
                }
                dataGridView_PC_GV.Columns[1].HeaderText = "Mã Giảng Viên";
                dataGridView_PC_GV.Columns[2].HeaderText = "Mã Học Phần";
                dataGridView_PC_GV.Columns[3].HeaderText = "Học Kì";
                dataGridView_PC_GV.Columns[4].HeaderText = "Năm";
                dataGridView_PC_GV.Columns[5].HeaderText = "Mã Chương Trình";
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: " + ex.Message);
            }
            dataGridView_PC_GV.Columns["Option"].DisplayIndex = dataGridView_PC_GV.Columns.Count - 1;
        }

        private void label_CTPC_TDV_Click(object sender, EventArgs e)
        {
            Form_TruongDV form = (Form_TruongDV)this.FindForm();
            form.panel_ControlContainer.Controls.Remove(this);

            foreach (Control control in form.panel_ControlContainer.Controls)
            {
                if (control is UC_Xem_GV)
                {
                    form.open_UC_control(control);
                }
            }
        }

        private void button_back_Click(object sender, EventArgs e)
        {
            label_CTPC_TDV_Click(sender, e);  
        }

        private void button_Them_PhanCong_Click(object sender, EventArgs e)
        {
            UC_PhanCong_TDV.loai_tuychinh = "insert";
            f_modify_PC_TDV f = new f_modify_PC_TDV();
            f.ShowDialog();
            UC_PC_GV_trgdv_Load(sender, e);
        }

        private void dataGridView_PC_GV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Selected_PC.Magv = dataGridView_PC_GV.Rows[e.RowIndex].Cells[1].Value.ToString();
            Selected_PC.Mahp = dataGridView_PC_GV.Rows[e.RowIndex].Cells[2].Value.ToString();
            Selected_PC.Hocki = dataGridView_PC_GV.Rows[e.RowIndex].Cells[3].Value.ToString();
            Selected_PC.Nam = dataGridView_PC_GV.Rows[e.RowIndex].Cells[4].Value.ToString();
            Selected_PC.Mact = dataGridView_PC_GV.Rows[e.RowIndex].Cells[5].Value.ToString();

            loai_tuychinh = "update";
            f_modify_PC_TDV f = new f_modify_PC_TDV();
            f.ShowDialog();
            UC_PC_GV_trgdv_Load(sender, e);
        }
    }
}
