﻿namespace ATBM
{
    partial class Form_Update_NS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_Caption = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_hoten = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_ngaysinh = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_sodienthoai = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_phucap = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.button_close = new System.Windows.Forms.Button();
            this.button_update = new System.Windows.Forms.Button();
            this.cmbVT = new System.Windows.Forms.ComboBox();
            this.cmbDV = new System.Windows.Forms.ComboBox();
            this.cmbGioi = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxMaNV = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label_Caption
            // 
            this.label_Caption.AutoSize = true;
            this.label_Caption.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold);
            this.label_Caption.ForeColor = System.Drawing.Color.Black;
            this.label_Caption.Location = new System.Drawing.Point(254, 27);
            this.label_Caption.Name = "label_Caption";
            this.label_Caption.Size = new System.Drawing.Size(299, 43);
            this.label_Caption.TabIndex = 2;
            this.label_Caption.Text = "THÊM NHÂN SỰ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(416, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 27);
            this.label2.TabIndex = 8;
            this.label2.Text = "Họ và Tên:";
            // 
            // textBox_hoten
            // 
            this.textBox_hoten.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_hoten.Font = new System.Drawing.Font("Arial", 11F);
            this.textBox_hoten.ForeColor = System.Drawing.Color.Black;
            this.textBox_hoten.Location = new System.Drawing.Point(421, 126);
            this.textBox_hoten.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox_hoten.Name = "textBox_hoten";
            this.textBox_hoten.Size = new System.Drawing.Size(289, 33);
            this.textBox_hoten.TabIndex = 7;
            this.textBox_hoten.TextChanged += new System.EventHandler(this.textBox_hoten_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F);
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(69, 184);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 27);
            this.label3.TabIndex = 10;
            this.label3.Text = "Ngày sinh:";
            // 
            // textBox_ngaysinh
            // 
            this.textBox_ngaysinh.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_ngaysinh.Font = new System.Drawing.Font("Arial", 11F);
            this.textBox_ngaysinh.ForeColor = System.Drawing.Color.Black;
            this.textBox_ngaysinh.Location = new System.Drawing.Point(73, 216);
            this.textBox_ngaysinh.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox_ngaysinh.Name = "textBox_ngaysinh";
            this.textBox_ngaysinh.Size = new System.Drawing.Size(289, 33);
            this.textBox_ngaysinh.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F);
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(418, 184);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(159, 27);
            this.label4.TabIndex = 12;
            this.label4.Text = "Số điện thoại:";
            // 
            // textBox_sodienthoai
            // 
            this.textBox_sodienthoai.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_sodienthoai.Font = new System.Drawing.Font("Arial", 11F);
            this.textBox_sodienthoai.ForeColor = System.Drawing.Color.Black;
            this.textBox_sodienthoai.Location = new System.Drawing.Point(423, 216);
            this.textBox_sodienthoai.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox_sodienthoai.Name = "textBox_sodienthoai";
            this.textBox_sodienthoai.Size = new System.Drawing.Size(289, 33);
            this.textBox_sodienthoai.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F);
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(69, 279);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(112, 27);
            this.label5.TabIndex = 14;
            this.label5.Text = "Giới tính:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 12F);
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(418, 279);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(109, 27);
            this.label6.TabIndex = 16;
            this.label6.Text = "Phụ cấp:";
            // 
            // textBox_phucap
            // 
            this.textBox_phucap.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_phucap.Font = new System.Drawing.Font("Arial", 11F);
            this.textBox_phucap.ForeColor = System.Drawing.Color.Black;
            this.textBox_phucap.Location = new System.Drawing.Point(423, 311);
            this.textBox_phucap.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox_phucap.Name = "textBox_phucap";
            this.textBox_phucap.Size = new System.Drawing.Size(289, 33);
            this.textBox_phucap.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 12F);
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(69, 382);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 27);
            this.label7.TabIndex = 18;
            this.label7.Text = "Vai trò:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 12F);
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(418, 382);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 27);
            this.label8.TabIndex = 20;
            this.label8.Text = "Đơn vị:";
            // 
            // button_close
            // 
            this.button_close.BackColor = System.Drawing.Color.Salmon;
            this.button_close.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_close.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button_close.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_close.Location = new System.Drawing.Point(73, 512);
            this.button_close.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_close.Name = "button_close";
            this.button_close.Size = new System.Drawing.Size(289, 56);
            this.button_close.TabIndex = 21;
            this.button_close.Text = "THOÁT";
            this.button_close.UseVisualStyleBackColor = false;
            this.button_close.Click += new System.EventHandler(this.button_close_Click);
            // 
            // button_update
            // 
            this.button_update.BackColor = System.Drawing.Color.CornflowerBlue;
            this.button_update.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_update.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button_update.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_update.Location = new System.Drawing.Point(423, 512);
            this.button_update.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_update.Name = "button_update";
            this.button_update.Size = new System.Drawing.Size(289, 56);
            this.button_update.TabIndex = 22;
            this.button_update.Text = "SỬA";
            this.button_update.UseVisualStyleBackColor = false;
            this.button_update.Click += new System.EventHandler(this.button_update_Click);
            // 
            // cmbVT
            // 
            this.cmbVT.Font = new System.Drawing.Font("Arial Narrow", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbVT.FormattingEnabled = true;
            this.cmbVT.Location = new System.Drawing.Point(75, 420);
            this.cmbVT.Name = "cmbVT";
            this.cmbVT.Size = new System.Drawing.Size(287, 34);
            this.cmbVT.TabIndex = 24;
            this.cmbVT.Click += new System.EventHandler(this.cmbVT_Click);
            // 
            // cmbDV
            // 
            this.cmbDV.Font = new System.Drawing.Font("Arial Narrow", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDV.FormattingEnabled = true;
            this.cmbDV.Location = new System.Drawing.Point(423, 420);
            this.cmbDV.Name = "cmbDV";
            this.cmbDV.Size = new System.Drawing.Size(287, 34);
            this.cmbDV.TabIndex = 25;
            this.cmbDV.Click += new System.EventHandler(this.cmbDV_Click);
            // 
            // cmbGioi
            // 
            this.cmbGioi.Font = new System.Drawing.Font("Arial Narrow", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbGioi.ForeColor = System.Drawing.SystemColors.WindowText;
            this.cmbGioi.FormattingEnabled = true;
            this.cmbGioi.Location = new System.Drawing.Point(75, 314);
            this.cmbGioi.Name = "cmbGioi";
            this.cmbGioi.Size = new System.Drawing.Size(287, 34);
            this.cmbGioi.TabIndex = 23;
            this.cmbGioi.Click += new System.EventHandler(this.cmbGioi_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(68, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 27);
            this.label1.TabIndex = 27;
            this.label1.Text = "Mã nhân viên";
            // 
            // textBoxMaNV
            // 
            this.textBoxMaNV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxMaNV.Enabled = false;
            this.textBoxMaNV.Font = new System.Drawing.Font("Arial", 11F);
            this.textBoxMaNV.ForeColor = System.Drawing.Color.Black;
            this.textBoxMaNV.Location = new System.Drawing.Point(73, 126);
            this.textBoxMaNV.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxMaNV.Name = "textBoxMaNV";
            this.textBoxMaNV.Size = new System.Drawing.Size(289, 33);
            this.textBoxMaNV.TabIndex = 26;
            // 
            // Form_Update_NS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(775, 609);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxMaNV);
            this.Controls.Add(this.cmbDV);
            this.Controls.Add(this.cmbVT);
            this.Controls.Add(this.cmbGioi);
            this.Controls.Add(this.button_update);
            this.Controls.Add(this.button_close);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBox_phucap);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox_sodienthoai);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox_ngaysinh);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox_hoten);
            this.Controls.Add(this.label_Caption);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form_Update_NS";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Form_Update_NS_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_Caption;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_hoten;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_ngaysinh;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_sodienthoai;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_phucap;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button_close;
        private System.Windows.Forms.Button button_update;
        private System.Windows.Forms.ComboBox cmbVT;
        private System.Windows.Forms.ComboBox cmbDV;
        private System.Windows.Forms.ComboBox cmbGioi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxMaNV;
    }
}