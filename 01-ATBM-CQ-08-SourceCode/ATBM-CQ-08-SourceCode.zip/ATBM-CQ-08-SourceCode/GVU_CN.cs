﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATBM
{
    public partial class GVU_CN : Form
    {
        public GVU_CN()
        {
            InitializeComponent();
        }

        private void GVU_CN_Load(object sender, EventArgs e)
        {
            // câu query1 lấy thông tin cá nhân 
            string query1 = "Select ns.*,(select TENDV from admin1.x_donvi dv where ns.MaDV = dv.Madv) as TENDV " +
                            "from admin1.UV_THONGTINCANHAN_NS ns";


            DataSet ds = new DataSet();
            try
            {
                // Mở kết nối đến cơ sở dữ liệu
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    OracleDataAdapter adapter = new OracleDataAdapter(query1, connection);
                    adapter.Fill(ds);
                    connection.Close();

                }
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có
                MessageBox.Show("Lỗi khi kiểm tra sự tồn tại của người dùng: " + ex.Message);
            }
            // hiển thị thông tin cá nhân của sinh viên
            gvu_textBox_manv.Text = ds.Tables[0].Rows[0]["MANV"].ToString();
            gvu_textBox_hoten.Text = ds.Tables[0].Rows[0]["HOTEN"].ToString();
            gvu_textBox_ngaysinh.Text = ds.Tables[0].Rows[0]["NGSINH"].ToString();
            gvu_textBox_phai.Text = ds.Tables[0].Rows[0]["PHAI"].ToString();
            gvu_textBox_dienthoai.Text = ds.Tables[0].Rows[0]["DT"].ToString();
            gvu_textBox_phucap.Text = ds.Tables[0].Rows[0]["PHUCAP"].ToString();
            gvu_textBox_vaitro.Text = ds.Tables[0].Rows[0]["VAITRO"].ToString();
            gvu_textBox_tendv.Text = ds.Tables[0].Rows[0]["TENDV"].ToString();
        }

















        private bool CheckUserExists(string username)
        {
            try
            {
                // Kết nối đến cơ sở dữ liệu Oracle
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    // Mở kết nối
                    connection.Open();

                    // Tạo câu lệnh SQL để kiểm tra sự tồn tại của người dùng
                    string sqlQuery = "SELECT COUNT(*) FROM DBA_USERS WHERE USERNAME = :username";

                    // Tạo một đối tượng Command
                    using (OracleCommand cmd = new OracleCommand(sqlQuery, connection))
                    {
                        // Thêm tham số vào command
                        cmd.Parameters.Add("username", OracleDbType.Varchar2).Value = username;

                        // Thực thi truy vấn và lấy kết quả
                        int count = Convert.ToInt32(cmd.ExecuteScalar());

                        // Trả về true nếu có ít nhất một người dùng có tên tương tự, ngược lại trả về false
                        return count > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có
                MessageBox.Show("Error checking user existence: " + ex.Message);
                return false; // Trả về false nếu xảy ra lỗi
            }
        }

        private void gvu_cn_button_Click(object sender, EventArgs e)
        {
            string sdt = this.gvu_textBox_dienthoai.Text;


            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();

                    OracleCommand cmd = new OracleCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "admin1.USP_UPDATE_SDT_NV";
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Input parameters
                    cmd.Parameters.Add("SODIENTHOAI", OracleDbType.Varchar2).Value = sdt;

                    // Output parameters
                    OracleParameter errorCodeParam = new OracleParameter("p_error_code", OracleDbType.Int32);
                    errorCodeParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(errorCodeParam);

                    OracleParameter errorMsgParam = new OracleParameter("p_error_msg", OracleDbType.Varchar2, 1000);
                    errorMsgParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(errorMsgParam);

                    // Execute the command
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Update thành công!");
                    // reload thông tin hiển thị trên form

                    connection.Close();

                }
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có
                MessageBox.Show("ERR: " + ex.Message);
            }
        }


        /*
         thực thi proc

         try
            {
                // Kết nối đến cơ sở dữ liệu Oracle
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    // Mở kết nối
                    connection.Open();

                    // Tạo một đối tượng Command để gọi procedure
                    using (OracleCommand cmd = new OracleCommand("sp_grant_privilege", connection))
                    {
                        // Xác định kiểu command là StoredProcedure
                        cmd.CommandType = CommandType.StoredProcedure;

                        // Thêm các tham số vào command
                        cmd.Parameters.Add("user_role_name", OracleDbType.Varchar2).Value = userName;
                        cmd.Parameters.Add("table_name", OracleDbType.Varchar2).Value = tableName;
                        cmd.Parameters.Add("privilege_type", OracleDbType.Varchar2).Value = privilegeType;
                        cmd.Parameters.Add("column_name", OracleDbType.Varchar2).Value = columnName;
                        cmd.Parameters.Add("with_grant_option", OracleDbType.Varchar2).Value = withGrantOption;

                        // Thực thi command
                        cmd.ExecuteNonQuery();

                        // Hiển thị thông báo
                        MessageBox.Show("Privilege granted successfully.");
                    }
                }
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có
                MessageBox.Show("Error granting privilege: " + ex.Message);
            }
         
         
         
         */
    }
}
