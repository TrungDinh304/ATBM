﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;

namespace ATBM
{
    public partial class UC_DangKyHocPhan_SV : UserControl
    {
        private int selectedRowIndex = -1;
        private int selectedRowIndex1 = -1;
        public UC_DangKyHocPhan_SV()
        {
            InitializeComponent();
            this.dataGridView_KHM.MouseDown += new MouseEventHandler(dataGridView_KHM_MouseDown);
            this.dataGridView_DKHP.MouseDown += new MouseEventHandler(dataGridView_DKHP_MouseDown);
        }

        private void Fill_comboBox()
        {
            string query = "select distinct HK ||'-'||nam as hocki from admin1.x_dangky";
            DataSet ds_hocky = new DataSet();
            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    OracleDataAdapter adapter = new OracleDataAdapter(query, connection);
                    adapter.Fill(ds_hocky);
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: " + ex.Message);
            }
            //comboBox_HocKy_DangKy.DataSource = ds_hocky.Tables[0];
            //comboBox_HocKy_DangKy.DisplayMember = "hocki";
            //comboBox_HocKy_DangKy.ValueMember = "hocki";
            // Tạo danh sách các học kỳ
            List<string> hocKyList = new List<string>();

            // Thêm mục "Tất cả" vào danh sách
            hocKyList.Add("Tất cả");

            // Thêm các học kỳ từ DataSet vào danh sách
            foreach (DataRow row in ds_hocky.Tables[0].Rows)
            {
                hocKyList.Add(row["hocki"].ToString());
            }

            // Gán dữ liệu nguồn cho ComboBox
            //comboBox_HocKy_DangKy.DisplayMember = hocKyList;
            comboBox_HocKy_DangKy.DataSource = hocKyList;
        }
        private void comboBox_HocKy_DangKy_SelectedIndexChanged(object sender, EventArgs e)
        {
            string hocki = comboBox_HocKy_DangKy.SelectedValue.ToString();
            if (hocki == "System.Data.DataRowView")
            {
                return;
            }

            string query = "";

            if (hocki == "Tất cả")
            {
                query = "select magv, mahp, hk, nam, mact, diemth, diemqt, diemck, diemtk from admin1.x_dangky";
            }
            else
            {
                query = $"select magv, mahp, hk, nam, mact, diemth, diemqt, diemck, diemtk from admin1.x_dangky where hk||'-'||nam = \'{hocki}\'";
            }
            
            DataSet ds = new DataSet();
            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    OracleDataAdapter adapter = new OracleDataAdapter(query, connection);
                    adapter.Fill(ds);
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: " + ex.Message);
            }
            dataGridView_DKHP.DataSource = ds.Tables[0];
            dataGridView_DKHP.Columns[0].HeaderText = "Mã giảng viên";
            dataGridView_DKHP.Columns[1].HeaderText = "Mã học phần";
            dataGridView_DKHP.Columns[2].HeaderText = "Học kì";
            dataGridView_DKHP.Columns[3].HeaderText = "Năm";
            dataGridView_DKHP.Columns[4].HeaderText = "Mã chương trình";
            dataGridView_DKHP.Columns[5].HeaderText = "Điểm thực hành";
            dataGridView_DKHP.Columns[6].HeaderText = "Điểm quá trình";
            dataGridView_DKHP.Columns[7].HeaderText = "Điểm cuối kì";
            dataGridView_DKHP.Columns[8].HeaderText = "Điểm tổng kết";
        }

        private void UC_DangKyHocPhan_SV_Load(object sender, EventArgs e)
        {
            Fill_comboBox();
            comboBox_HocKy_DangKy_SelectedIndexChanged(sender, e);

            string query = "select * from admin1.UV_HOCPHANMO";
            DataSet ds = new DataSet();
            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    OracleDataAdapter adapter = new OracleDataAdapter(query, connection);
                    adapter.Fill(ds);
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: " + ex.Message);
            }
            dataGridView_KHM.DataSource = ds.Tables[0];
            dataGridView_KHM.Columns[0].HeaderText = "Mã học phần";
            dataGridView_KHM.Columns[1].HeaderText = "Tên học phần";
            dataGridView_KHM.Columns[2].HeaderText = "Số tín chỉ";
            dataGridView_KHM.Columns[3].HeaderText = "Học kì";
            dataGridView_KHM.Columns[4].HeaderText = "Năm";
            dataGridView_KHM.Columns[5].HeaderText = "Mã chương trình";
            dataGridView_KHM.Columns[6].HeaderText = "Mã giáo viên";
        }

        private void dataGridView_KHM_MouseDown(object sender, MouseEventArgs e)
        {
            // Chỉ xử lý chuột phải
            if (e.Button == MouseButtons.Right)
            {
                // Lấy vị trí hàng tại vị trí chuột
                var hti = dataGridView_KHM.HitTest(e.X, e.Y);

                if (hti.RowIndex >= 0)
                {
                    // Chọn hàng tại vị trí này
                    dataGridView_KHM.ClearSelection();
                    dataGridView_KHM.Rows[hti.RowIndex].Selected = true;

                    // Cập nhật chỉ số hàng được chọn
                    selectedRowIndex = hti.RowIndex;

                    // Hiển thị ContextMenuStrip tại vị trí chuột
                    contextMenuStrip1.Show(dataGridView_KHM, new Point(e.X, e.Y));
                }
            }
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            try
            {
                if (selectedRowIndex >= 0)
                {
                    // Lấy dữ liệu của hàng được chọn
                    DataGridViewRow selectedRow = dataGridView_KHM.Rows[selectedRowIndex];
                    string maSinhVien = Login_information.username;
                    string maHocPhan = selectedRow.Cells["MAHP"].Value.ToString();
                    string hocKi = selectedRow.Cells["HK"].Value.ToString();
                    string nam = selectedRow.Cells["NAM"].Value.ToString();
                    string maChuongTrinh = selectedRow.Cells["MACT"].Value.ToString();
                    string maGiangVien = selectedRow.Cells["MAGV"].Value.ToString();

                    try
                    {
                        using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                        {
                            connection.Open();
                            OracleCommand cmd = new OracleCommand();
                            cmd.Connection = connection;
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = "admin1.USP_INSERT_DK";

                            cmd.Parameters.Add("masinhvien", OracleDbType.Varchar2).Value = maSinhVien;
                            cmd.Parameters.Add("magiangvien", OracleDbType.Varchar2).Value = maGiangVien;
                            cmd.Parameters.Add("mahocphan", OracleDbType.Varchar2).Value = maHocPhan;
                            cmd.Parameters.Add("hocki", OracleDbType.Varchar2).Value = hocKi;
                            cmd.Parameters.Add("namhoc", OracleDbType.Varchar2).Value = nam;
                            cmd.Parameters.Add("machuongtrinh", OracleDbType.Varchar2).Value = maChuongTrinh;

                            OracleParameter errorCodeParam = new OracleParameter("p_error_code", OracleDbType.Int32);
                            errorCodeParam.Direction = ParameterDirection.Output;
                            cmd.Parameters.Add(errorCodeParam);

                            OracleParameter errorMsgParam = new OracleParameter("p_error_msg", OracleDbType.Varchar2, 1000);
                            errorMsgParam.Direction = ParameterDirection.Output;
                            cmd.Parameters.Add(errorMsgParam);

                            cmd.ExecuteNonQuery();
                            connection.Close();

                            if (errorCodeParam.Value.ToString() == "0")
                            {
                                MessageBox.Show("Thêm đăng ký thành công");
                                UC_DangKyHocPhan_SV_Load(sender, e);
                            }
                            else if (errorCodeParam.Value.ToString() == "-2")
                            {
                                MessageBox.Show("Học phần này đã được đăng ký rồi");
                            }
                            else
                            {
                                MessageBox.Show("Thêm đăng ký thất bại");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("ERROR: " + ex.Message);
                    }
                }
                else
                {
                    MessageBox.Show("Không có hàng nào được chọn.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: " + ex.Message);
            }
            selectedRowIndex = -1;
        }

        private void dataGridView_DKHP_MouseDown(object sender, MouseEventArgs e)
        {
            // Chỉ xử lý chuột phải
            if (e.Button == MouseButtons.Right)
            {
                // Lấy vị trí hàng tại vị trí chuột
                var hti = dataGridView_DKHP.HitTest(e.X, e.Y);

                if (hti.RowIndex >= 0)
                {
                    // Chọn hàng tại vị trí này
                    dataGridView_DKHP.ClearSelection();
                    dataGridView_DKHP.Rows[hti.RowIndex].Selected = true;

                    // Cập nhật chỉ số hàng được chọn
                    selectedRowIndex1 = hti.RowIndex;

                    // Hiển thị ContextMenuStrip tại vị trí chuột
                    contextMenuStrip2.Show(dataGridView_DKHP, new Point(e.X, e.Y));
                }
            }
        }

        private void ToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            try
            {
                if (selectedRowIndex1 >= 0)
                {
                    // Lấy dữ liệu của hàng được chọn
                    DataGridViewRow selectedRow = dataGridView_DKHP.Rows[selectedRowIndex1];
                    string maSinhVien = Login_information.username;
                    string maGiangVien = selectedRow.Cells["MAGV"].Value.ToString();
                    string maHocPhan = selectedRow.Cells["MAHP"].Value.ToString();
                    string hocKi = selectedRow.Cells["HK"].Value.ToString();
                    string nam = selectedRow.Cells["NAM"].Value.ToString();
                    string maChuongTrinh = selectedRow.Cells["MACT"].Value.ToString();

                    try
                    {
                        using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                        {
                            connection.Open();
                            OracleCommand cmd = new OracleCommand();
                            cmd.Connection = connection;
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = "admin1.USP_DELETE_DK";

                            cmd.Parameters.Add("masinhvien", OracleDbType.Varchar2).Value = maSinhVien;
                            cmd.Parameters.Add("magiangvien", OracleDbType.Varchar2).Value = maGiangVien;
                            cmd.Parameters.Add("mahocphan", OracleDbType.Varchar2).Value = maHocPhan;
                            cmd.Parameters.Add("hocki", OracleDbType.Varchar2).Value = hocKi;
                            cmd.Parameters.Add("namhoc", OracleDbType.Varchar2).Value = nam;
                            cmd.Parameters.Add("machuongtrinh", OracleDbType.Varchar2).Value = maChuongTrinh;

                            OracleParameter errorCodeParam = new OracleParameter("p_error_code", OracleDbType.Int32);
                            errorCodeParam.Direction = ParameterDirection.Output;
                            cmd.Parameters.Add(errorCodeParam);

                            OracleParameter errorMsgParam = new OracleParameter("p_error_msg", OracleDbType.Varchar2, 1000);
                            errorMsgParam.Direction = ParameterDirection.Output;
                            cmd.Parameters.Add(errorMsgParam);

                            cmd.ExecuteNonQuery();
                            connection.Close();

                            if (errorCodeParam.Value.ToString() == "0")
                            {
                                MessageBox.Show("Xoá đăng ký thành công");
                                UC_DangKyHocPhan_SV_Load(sender, e);
                            }
                            else if (errorCodeParam.Value.ToString() == "-1")
                            {
                                MessageBox.Show("Thông tin đăng kí này đã hết hạn chỉnh sửa");
                                UC_DangKyHocPhan_SV_Load(sender, e);
                            }
                            else
                            {
                                MessageBox.Show("Xoá đăng ký thất bại");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("ERROR: " + ex.Message);
                    }
                }
                else
                {
                    MessageBox.Show("Không có hàng nào được chọn.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: " + ex.Message);
            }
            selectedRowIndex1 = -1;
        }
    }
}
