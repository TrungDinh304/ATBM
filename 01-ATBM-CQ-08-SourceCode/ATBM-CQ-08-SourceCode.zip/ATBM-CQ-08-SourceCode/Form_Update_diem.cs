﻿using NPOI.POIFS.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using ATBM;
using System.Linq.Expressions;
using static ATBM.UC_DanhSachLopHoc;

namespace ATBM
{
    public partial class Form_Update_diem : Form
    {
        public Form_Update_diem()
        {
            InitializeComponent();
        }


        private void Form_Update_diem_Load(object sender, EventArgs e)
        {
            string query_statement = $"Select Hoten from admin1.x_sinhvien where masv = \'{UC_DanhSachLopHoc.Selected_infor.MASV}\'";
            // kết nối với database oracle 
            DataSet ds_diem = new DataSet();
            try
            {
                // Mở kết nối đến cơ sở dữ liệu
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    //lấy dữ liệu từ bảng
                    OracleDataAdapter adapter = new OracleDataAdapter(query_statement, connection);
                    adapter.Fill(ds_diem);
                    // đóng kết nối
                    connection.Close();

                }
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có
                MessageBox.Show("Lỗi khi kiểm tra sự tồn tại của người dùng: " + ex.Message);
            }
            label_value_hoten.Text = ds_diem.Tables[0].Rows[0]["Hoten"].ToString();


            try
            {
                using(OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();

                    OracleCommand cmd = new OracleCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "admin1.USP_Select_DK_GV";
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Input parameters
                    cmd.Parameters.Add("p_masv", OracleDbType.Varchar2).Value = Selected_infor.MASV;
                    cmd.Parameters.Add("p_mahp", OracleDbType.Varchar2).Value = Selected_infor.MAHP;
                    cmd.Parameters.Add("p_hk", OracleDbType.Int32).Value = Selected_infor.HK;
                    cmd.Parameters.Add("p_nam", OracleDbType.Int32).Value = Selected_infor.NAM;
                    cmd.Parameters.Add("p_mact", OracleDbType.Varchar2).Value = Selected_infor.MACT;



                    // Output parameters
                    OracleParameter refcur = new OracleParameter("p_result", OracleDbType.RefCursor);
                    refcur.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(refcur);

                    OracleParameter errorCodeParam = new OracleParameter("p_error_code", OracleDbType.Int32);
                    errorCodeParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(errorCodeParam);

                    OracleParameter errorMsgParam = new OracleParameter("p_error_msg", OracleDbType.Varchar2, 1000);
                    errorMsgParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(errorMsgParam);

                    OracleDataReader dr = cmd.ExecuteReader();

                    DataTable dataTable = new DataTable();
                    dataTable.Load(dr);


                    UC_DanhSachLopHoc.Selected_infor.DiemLT = dataTable.Rows[0]["DIEMQT"].ToString();
                    UC_DanhSachLopHoc.Selected_infor.DiemTH = dataTable.Rows[0]["DIEMTH"].ToString();
                    UC_DanhSachLopHoc.Selected_infor.DiemCK = dataTable.Rows[0]["DIEMCK"].ToString();
                    UC_DanhSachLopHoc.Selected_infor.DiemTK = dataTable.Rows[0]["DIEMTK"].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi lấy điểm: " + ex.Message);
            }
            label_value_mssv.Text = UC_DanhSachLopHoc.Selected_infor.MASV;
            label_value_diemtk.Text = UC_DanhSachLopHoc.Selected_infor.DiemTK;
            textBox_DiemCK.Text = UC_DanhSachLopHoc.Selected_infor.DiemCK;
            textBox_DiemLT.Text = UC_DanhSachLopHoc.Selected_infor.DiemLT;
            textBox_DiemTH.Text = UC_DanhSachLopHoc.Selected_infor.DiemTH;
        }

        private void button_Dong_Click(object sender, EventArgs e)
        {
            // đóng form hiện tại
            this.Close();
        }

        private void button_Luu_Click(object sender, EventArgs e)
        {
            UC_DanhSachLopHoc.Selected_infor.DiemTH = textBox_DiemTH.Text;
            UC_DanhSachLopHoc.Selected_infor.DiemLT = textBox_DiemLT.Text;
            UC_DanhSachLopHoc.Selected_infor.DiemCK = textBox_DiemCK.Text;

            try
            {
                using(OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    OracleCommand cmd = new OracleCommand();
                    cmd.Connection = connection;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "admin1.USP_Update_DK_GV";
                    
                    cmd.Parameters.Add("p_MASV", OracleDbType.Varchar2).Value = UC_DanhSachLopHoc.Selected_infor.MASV;
                    cmd.Parameters.Add("p_MAHP", OracleDbType.Varchar2).Value = UC_DanhSachLopHoc.Selected_infor.MAHP;
                    cmd.Parameters.Add("p_HK", OracleDbType.Int32).Value = UC_DanhSachLopHoc.Selected_infor.HK;
                    cmd.Parameters.Add("p_NAM", OracleDbType.Int32).Value = UC_DanhSachLopHoc.Selected_infor.NAM;
                    cmd.Parameters.Add("p_MACT", OracleDbType.Varchar2).Value = UC_DanhSachLopHoc.Selected_infor.MACT;

                    cmd.Parameters.Add("p_DIEMLT", OracleDbType.Varchar2).Value = UC_DanhSachLopHoc.Selected_infor.DiemLT;
                    cmd.Parameters.Add("p_DIEMTH", OracleDbType.Varchar2).Value = UC_DanhSachLopHoc.Selected_infor.DiemTH;
                    cmd.Parameters.Add("p_DIEMCK", OracleDbType.Varchar2).Value = UC_DanhSachLopHoc.Selected_infor.DiemCK;

                    OracleParameter errorCodeParam = new OracleParameter("p_error_code", OracleDbType.Int32);
                    errorCodeParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(errorCodeParam);

                    OracleParameter errorMsgParam = new OracleParameter("p_error_msg", OracleDbType.Varchar2, 1000);
                    errorMsgParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(errorMsgParam);

                    OracleDataReader dr = cmd.ExecuteReader();
                    connection.Close();

                    if(errorCodeParam.Value.ToString() != "0")
                    {
                        MessageBox.Show("Cập nhật điểm thất bại: " + errorMsgParam.Value.ToString());

                        Form_Update_diem_Load(sender, e);
                        return;
                    }
                    else
                    {
                        MessageBox.Show("Cập nhật điểm thành công.");
                        Form_Update_diem_Load(sender, e);
                    }
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi cập nhật điểm: " + ex.Message);
            }
        }
    }
}
