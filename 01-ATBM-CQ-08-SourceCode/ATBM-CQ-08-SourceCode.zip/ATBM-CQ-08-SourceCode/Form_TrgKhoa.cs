﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ATBM;

namespace ATBM
{
    public partial class Form_TrgKhoa : Form
    {
        public Form_TrgKhoa()
        {
            InitializeComponent();
            pictureBox_LopHoc.Image = Image.FromFile("../../img/Pink_lophoc.png");
            UC_LopHoc uc = new UC_LopHoc();
            open_UC_control(uc);
        }
        public void open_UC_control(Control uc)
        {
            // Dock vào panel và đưa lên trước
            uc.Dock = DockStyle.Fill;
            panel_ControlContainer.Controls.Add(uc);
            uc.BringToFront();
        }
        private void lable_Username_Click(object sender, EventArgs e)
        {
            ATBM.Forrm_Personal_Information form = new ATBM.Forrm_Personal_Information();
            form.ShowDialog();
        }

        private void pictureBox_avatar_Click(object sender, EventArgs e)
        {
            ATBM.Forrm_Personal_Information form = new ATBM.Forrm_Personal_Information();
            form.ShowDialog();
        }

        private void pictureBox_LopHoc_Click(object sender, EventArgs e)
        {
            //Thay đổi ảnh khi click vào
            // ảnh lấy từ file được lưu local
            pictureBox_LopHoc.Image = Image.FromFile("../../img/Pink_lophoc.png");


            pictureBox_SinhVien.Image = Image.FromFile("../../img/Black_sinhvien.png");
            pictureBox_DonVi.Image = Image.FromFile("../../img/Black_donvi.png");
            pictureBox_KeHoachMo.Image = Image.FromFile("../../img/Black_kehoachmo.png");
            pictureBox_HocPhan.Image = Image.FromFile("../../img/Black_hocphan.png");
            pictureBox_PhanCong.Image = Image.FromFile("../../img/Black_phancong.png");
            pictureBox_GiangVien.Image = Image.FromFile("../../img/Black_nhansu1.png");

            // nếu chưa tạo UC_LopHoc thì tạo mới
            foreach (Control c in panel_ControlContainer.Controls)
            {
                if (c is UC_LopHoc)
                {
                    // Control is of type UC_LopHoc and is contained by the panel
                    open_UC_control(c);
                    return;
                }
            }
            UC_LopHoc uc = new UC_LopHoc();
            open_UC_control(uc);
        }

        private void pictureBox_PhanCong_Click(object sender, EventArgs e)
        {
            //Thay đổi ảnh khi click vào
            // ảnh lấy từ file được lưu local
            pictureBox_PhanCong.Image = Image.FromFile("../../img/Pink_phancong.png");


            pictureBox_LopHoc.Image = Image.FromFile("../../img/Black_lophoc.png");
            pictureBox_DonVi.Image = Image.FromFile("../../img/Black_donvi.png");
            pictureBox_KeHoachMo.Image = Image.FromFile("../../img/Black_kehoachmo.png");
            pictureBox_SinhVien.Image = Image.FromFile("../../img/Black_sinhvien.png");
            pictureBox_HocPhan.Image = Image.FromFile("../../img/Black_hocphan.png");
            pictureBox_GiangVien.Image = Image.FromFile("../../img/Black_nhansu1.png");


            // nếu chưa tạo UC_LopHoc thì tạo mới
            foreach (Control c in panel_ControlContainer.Controls)
            {
                if (c is UC_PhanCong_TK)
                {
                    // Control is of type UC_LopHoc and is contained by the panel
                    open_UC_control(c);
                    return;
                }
            }
            UC_PhanCong_TK uc = new UC_PhanCong_TK();
            open_UC_control(uc);
        }

        private void pictureBox_SinhVien_Click(object sender, EventArgs e)
        {
            //Thay đổi ảnh khi click vào
            // ảnh lấy từ file được lưu local
            pictureBox_SinhVien.Image = Image.FromFile("../../img/Pink_sinhvien.png");


            pictureBox_LopHoc.Image = Image.FromFile("../../img/Black_lophoc.png");
            pictureBox_DonVi.Image = Image.FromFile("../../img/Black_donvi.png");
            pictureBox_KeHoachMo.Image = Image.FromFile("../../img/Black_kehoachmo.png");
            pictureBox_HocPhan.Image = Image.FromFile("../../img/Black_hocphan.png");
            pictureBox_PhanCong.Image = Image.FromFile("../../img/Black_phancong.png");
            pictureBox_GiangVien.Image = Image.FromFile("../../img/Black_nhansu1.png");


            // nếu chưa tạo UC_LopHoc thì tạo mới
            foreach (Control c in panel_ControlContainer.Controls)
            {
                if (c is UC_TruyVan_SinhVien_GV)
                {
                    // Control is of type UC_LopHoc and is contained by the panel
                    open_UC_control(c);
                    return;
                }
            }
            UC_TruyVan_SinhVien_GV uc = new UC_TruyVan_SinhVien_GV();
            open_UC_control(uc);
        }

        private void pictureBox_DonVi_Click(object sender, EventArgs e)
        {
            //Thay đổi ảnh khi click vào
            // ảnh lấy từ file được lưu local
            pictureBox_DonVi.Image = Image.FromFile("../../img/Pink_donvi.png");


            pictureBox_LopHoc.Image = Image.FromFile("../../img/Black_lophoc.png");
            pictureBox_SinhVien.Image = Image.FromFile("../../img/Black_sinhvien.png");
            pictureBox_KeHoachMo.Image = Image.FromFile("../../img/Black_kehoachmo.png");
            pictureBox_HocPhan.Image = Image.FromFile("../../img/Black_hocphan.png");
            pictureBox_PhanCong.Image = Image.FromFile("../../img/Black_phancong.png");
            pictureBox_GiangVien.Image = Image.FromFile("../../img/Black_nhansu1.png");


            // nếu chưa tạo UC_LopHoc thì tạo mới
            foreach (Control c in panel_ControlContainer.Controls)
            {
                if (c is UC_TruyVan_DonVi_GV)
                {
                    // Control is of type UC_LopHoc and is contained by the panel
                    open_UC_control(c);
                    return;
                }
            }
            UC_TruyVan_DonVi_GV uc = new UC_TruyVan_DonVi_GV();
            open_UC_control(uc);
        }

        private void pictureBox_KeHoachMo_Click(object sender, EventArgs e)
        {
            //Thay đổi ảnh khi click vào
            // ảnh lấy từ file được lưu local
            pictureBox_KeHoachMo.Image = Image.FromFile("../../img/Pink_kehoachmo.png");


            pictureBox_LopHoc.Image = Image.FromFile("../../img/Black_lophoc.png");
            pictureBox_DonVi.Image = Image.FromFile("../../img/Black_donvi.png");
            pictureBox_SinhVien.Image = Image.FromFile("../../img/Black_sinhvien.png");
            pictureBox_HocPhan.Image = Image.FromFile("../../img/Black_hocphan.png");
            pictureBox_PhanCong.Image = Image.FromFile("../../img/Black_phancong.png");
            pictureBox_GiangVien.Image = Image.FromFile("../../img/Black_nhansu1.png");


            // nếu chưa tạo UC_LopHoc thì tạo mới
            foreach (Control c in panel_ControlContainer.Controls)
            {
                if (c is UC_TruyVan_KeHoachMo_GV)
                {
                    // Control is of type UC_LopHoc and is contained by the panel
                    open_UC_control(c);
                    return;
                }
            }
            UC_TruyVan_KeHoachMo_GV uc = new UC_TruyVan_KeHoachMo_GV();
            open_UC_control(uc);
        }

        private void pictureBox_HocPhan_Click(object sender, EventArgs e)
        {
            //Thay đổi ảnh khi click vào
            // ảnh lấy từ file được lưu local
            pictureBox_HocPhan.Image = Image.FromFile("../../img/Pink_hocphan.png");


            pictureBox_SinhVien.Image = Image.FromFile("../../img/Black_sinhvien.png");
            pictureBox_LopHoc.Image = Image.FromFile("../../img/Black_lophoc.png");
            pictureBox_DonVi.Image = Image.FromFile("../../img/Black_donvi.png");
            pictureBox_KeHoachMo.Image = Image.FromFile("../../img/Black_kehoachmo.png");
            pictureBox_PhanCong.Image = Image.FromFile("../../img/Black_phancong.png");
            pictureBox_GiangVien.Image = Image.FromFile("../../img/Black_nhansu1.png");


            // nếu chưa tạo UC_LopHoc thì tạo mới
            foreach (Control c in panel_ControlContainer.Controls)
            {
                if (c is UC_TruyVan_HocPhan_GV)
                {
                    // Control is of type UC_LopHoc and is contained by the panel
                    open_UC_control(c);
                    return;
                }
            }
            UC_TruyVan_HocPhan_GV uc = new UC_TruyVan_HocPhan_GV();
            open_UC_control(uc);
        }

        private void Form_TrgKhoa_Load(object sender, EventArgs e)
        {
            lable_Username.Text = Login_information.fullname;
            label_role.Text = Login_information.role;

        }

        private void pictureBox_GiangVien_Click(object sender, EventArgs e)
        {
            //Thay đổi ảnh khi click vào
            // ảnh lấy từ file được lưu local
            pictureBox_GiangVien.Image = Image.FromFile("../../img/Pink_nhansu1.png");


            pictureBox_SinhVien.Image = Image.FromFile("../../img/Black_sinhvien.png");
            pictureBox_LopHoc.Image = Image.FromFile("../../img/Black_lophoc.png");
            pictureBox_DonVi.Image = Image.FromFile("../../img/Black_donvi.png");
            pictureBox_KeHoachMo.Image = Image.FromFile("../../img/Black_kehoachmo.png");
            pictureBox_HocPhan.Image = Image.FromFile("../../img/Black_hocphan.png");
            pictureBox_PhanCong.Image = Image.FromFile("../../img/Black_phancong.png");


            // nếu chưa tạo UC_LopHoc thì tạo mới
            foreach (Control c in panel_ControlContainer.Controls)
            {
                if (c is UC_Xem_NS)
                {
                    // Control is of type UC_LopHoc and is contained by the panel
                    open_UC_control(c);
                    return;
                }
            }
            UC_Xem_NS uc = new UC_Xem_NS();
            open_UC_control(uc);
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            this.FindForm().Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
