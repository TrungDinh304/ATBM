﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;


namespace ATBM
{
    public partial class UC_Xem_GV : UserControl
    {
        public UC_Xem_GV()
        {
            InitializeComponent();
        }

        private void UC_Xem_GV_Load(object sender, EventArgs e)
        {
            button_TimKiem_GiangVien_Click(sender, e);
        }

        private void button_TimKiem_GiangVien_Click(object sender, EventArgs e)
        {
            string GiangVien_search = textBox_TimKiem_GiangVien.Text;
            string query_string = $"select * from admin1.V_GiangVien_PhanCong_donvi where manv like '%{GiangVien_search}%' or hoten like '%{GiangVien_search}%'";

            DataSet ds_phancong = new DataSet();

            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    //lấy dữ liệu từ bảng
                    OracleDataAdapter adapter = new OracleDataAdapter(query_string, connection);
                    adapter.Fill(ds_phancong);
                    // đóng kết nối
                    connection.Close();
                    // rót dữ liệu vào datagridview
                    dataGridView_DS_GiangVien.DataSource = ds_phancong.Tables[0];

                    dataGridView_DS_GiangVien.Columns[1].HeaderText = "Mã giảng viên";
                    dataGridView_DS_GiangVien.Columns[2].HeaderText = "Họ tên";
                    dataGridView_DS_GiangVien.Columns[3].HeaderText = "Số điện thoại";
                    dataGridView_DS_GiangVien.Columns[4].HeaderText = "Đơn vị";

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: " + ex.Message);
            }

            dataGridView_DS_GiangVien.Columns["XemPC"].DisplayIndex = dataGridView_DS_GiangVien.Columns.Count - 1;

        }
        static public int FormName;

        static public string MaGV;
        private void dataGridView_DS_GiangVien_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            MaGV = dataGridView_DS_GiangVien.Rows[e.RowIndex].Cells[1].Value.ToString();
            
            if(this.FindForm() is Form_TruongDV)
            {
                Form_TruongDV f = (Form_TruongDV)this.FindForm();
                UC_PC_GV_trgdv c = new UC_PC_GV_trgdv();
                f.open_UC_control(c);
            }
            else
            {
                UC_PC_GV_trgdv uc = new UC_PC_GV_trgdv();
                Form_TrgKhoa form = (Form_TrgKhoa)this.FindForm();
                form.open_UC_control(uc);
            }
        }
    }
}
