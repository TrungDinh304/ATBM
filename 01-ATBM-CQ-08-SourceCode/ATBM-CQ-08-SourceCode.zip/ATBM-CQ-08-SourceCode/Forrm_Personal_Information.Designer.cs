﻿namespace ATBM
{
    partial class Forrm_Personal_Information
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_Caption = new System.Windows.Forms.Label();
            this.textBox_username = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_hoten = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_ngaysinh = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_sodienthoai = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_gioitinh = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_phucap = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox_vaitro = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox_donvi = new System.Windows.Forms.TextBox();
            this.button_close = new System.Windows.Forms.Button();
            this.button_update = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label_Caption
            // 
            this.label_Caption.AutoSize = true;
            this.label_Caption.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold);
            this.label_Caption.ForeColor = System.Drawing.Color.Black;
            this.label_Caption.Location = new System.Drawing.Point(156, 28);
            this.label_Caption.Name = "label_Caption";
            this.label_Caption.Size = new System.Drawing.Size(327, 35);
            this.label_Caption.TabIndex = 2;
            this.label_Caption.Text = "THÔNG TIN CÁ NHÂN";
            // 
            // textBox_username
            // 
            this.textBox_username.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_username.Enabled = false;
            this.textBox_username.Font = new System.Drawing.Font("Arial", 11F);
            this.textBox_username.ForeColor = System.Drawing.Color.Gray;
            this.textBox_username.Location = new System.Drawing.Point(65, 98);
            this.textBox_username.Name = "textBox_username";
            this.textBox_username.Size = new System.Drawing.Size(257, 29);
            this.textBox_username.TabIndex = 5;
            this.textBox_username.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(61, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 23);
            this.label1.TabIndex = 6;
            this.label1.Text = "Mã nhân viên:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(372, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 23);
            this.label2.TabIndex = 8;
            this.label2.Text = "Họ và Tên:";
            // 
            // textBox_hoten
            // 
            this.textBox_hoten.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_hoten.Enabled = false;
            this.textBox_hoten.Font = new System.Drawing.Font("Arial", 11F);
            this.textBox_hoten.ForeColor = System.Drawing.Color.Gray;
            this.textBox_hoten.Location = new System.Drawing.Point(376, 98);
            this.textBox_hoten.Name = "textBox_hoten";
            this.textBox_hoten.Size = new System.Drawing.Size(257, 29);
            this.textBox_hoten.TabIndex = 7;
            this.textBox_hoten.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F);
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(61, 147);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 23);
            this.label3.TabIndex = 10;
            this.label3.Text = "Ngày sinh:";
            // 
            // textBox_ngaysinh
            // 
            this.textBox_ngaysinh.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_ngaysinh.Enabled = false;
            this.textBox_ngaysinh.Font = new System.Drawing.Font("Arial", 11F);
            this.textBox_ngaysinh.ForeColor = System.Drawing.Color.Gray;
            this.textBox_ngaysinh.Location = new System.Drawing.Point(65, 173);
            this.textBox_ngaysinh.Name = "textBox_ngaysinh";
            this.textBox_ngaysinh.Size = new System.Drawing.Size(257, 29);
            this.textBox_ngaysinh.TabIndex = 9;
            this.textBox_ngaysinh.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F);
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(372, 147);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(130, 23);
            this.label4.TabIndex = 12;
            this.label4.Text = "Số điện thoại:";
            // 
            // textBox_sodienthoai
            // 
            this.textBox_sodienthoai.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_sodienthoai.Font = new System.Drawing.Font("Arial", 11F);
            this.textBox_sodienthoai.ForeColor = System.Drawing.Color.Black;
            this.textBox_sodienthoai.Location = new System.Drawing.Point(376, 173);
            this.textBox_sodienthoai.Name = "textBox_sodienthoai";
            this.textBox_sodienthoai.Size = new System.Drawing.Size(257, 29);
            this.textBox_sodienthoai.TabIndex = 11;
            this.textBox_sodienthoai.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F);
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(61, 223);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 23);
            this.label5.TabIndex = 14;
            this.label5.Text = "Giới tính:";
            // 
            // textBox_gioitinh
            // 
            this.textBox_gioitinh.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_gioitinh.Enabled = false;
            this.textBox_gioitinh.Font = new System.Drawing.Font("Arial", 11F);
            this.textBox_gioitinh.ForeColor = System.Drawing.Color.Gray;
            this.textBox_gioitinh.Location = new System.Drawing.Point(65, 249);
            this.textBox_gioitinh.Name = "textBox_gioitinh";
            this.textBox_gioitinh.Size = new System.Drawing.Size(257, 29);
            this.textBox_gioitinh.TabIndex = 13;
            this.textBox_gioitinh.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 12F);
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(372, 223);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 23);
            this.label6.TabIndex = 16;
            this.label6.Text = "Phụ cấp:";
            // 
            // textBox_phucap
            // 
            this.textBox_phucap.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_phucap.Enabled = false;
            this.textBox_phucap.Font = new System.Drawing.Font("Arial", 11F);
            this.textBox_phucap.ForeColor = System.Drawing.Color.Gray;
            this.textBox_phucap.Location = new System.Drawing.Point(376, 249);
            this.textBox_phucap.Name = "textBox_phucap";
            this.textBox_phucap.Size = new System.Drawing.Size(257, 29);
            this.textBox_phucap.TabIndex = 15;
            this.textBox_phucap.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 12F);
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(61, 306);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 23);
            this.label7.TabIndex = 18;
            this.label7.Text = "Vai trò:";
            // 
            // textBox_vaitro
            // 
            this.textBox_vaitro.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_vaitro.Enabled = false;
            this.textBox_vaitro.Font = new System.Drawing.Font("Arial", 11F);
            this.textBox_vaitro.ForeColor = System.Drawing.Color.Gray;
            this.textBox_vaitro.Location = new System.Drawing.Point(65, 332);
            this.textBox_vaitro.Name = "textBox_vaitro";
            this.textBox_vaitro.Size = new System.Drawing.Size(257, 29);
            this.textBox_vaitro.TabIndex = 17;
            this.textBox_vaitro.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 12F);
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(372, 306);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 23);
            this.label8.TabIndex = 20;
            this.label8.Text = "Đơn vị:";
            // 
            // textBox_donvi
            // 
            this.textBox_donvi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_donvi.Enabled = false;
            this.textBox_donvi.Font = new System.Drawing.Font("Arial", 11F);
            this.textBox_donvi.ForeColor = System.Drawing.Color.Gray;
            this.textBox_donvi.Location = new System.Drawing.Point(376, 332);
            this.textBox_donvi.Name = "textBox_donvi";
            this.textBox_donvi.Size = new System.Drawing.Size(257, 29);
            this.textBox_donvi.TabIndex = 19;
            this.textBox_donvi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button_close
            // 
            this.button_close.BackColor = System.Drawing.SystemColors.ControlLight;
            this.button_close.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_close.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button_close.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_close.Location = new System.Drawing.Point(65, 399);
            this.button_close.Name = "button_close";
            this.button_close.Size = new System.Drawing.Size(257, 44);
            this.button_close.TabIndex = 21;
            this.button_close.Text = "Đóng";
            this.button_close.UseVisualStyleBackColor = false;
            this.button_close.Click += new System.EventHandler(this.button_close_Click);
            // 
            // button_update
            // 
            this.button_update.BackColor = System.Drawing.Color.Plum;
            this.button_update.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_update.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button_update.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_update.Location = new System.Drawing.Point(376, 399);
            this.button_update.Name = "button_update";
            this.button_update.Size = new System.Drawing.Size(257, 44);
            this.button_update.TabIndex = 22;
            this.button_update.Text = "Cập Nhật";
            this.button_update.UseVisualStyleBackColor = false;
            this.button_update.Click += new System.EventHandler(this.button_update_Click);
            // 
            // Forrm_Personal_Information
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(689, 511);
            this.Controls.Add(this.button_update);
            this.Controls.Add(this.button_close);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBox_donvi);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBox_vaitro);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBox_phucap);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox_gioitinh);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox_sodienthoai);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox_ngaysinh);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox_hoten);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox_username);
            this.Controls.Add(this.label_Caption);
            this.Name = "Forrm_Personal_Information";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "PROFILE";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Forrm_Personal_Information_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_Caption;
        private System.Windows.Forms.TextBox textBox_username;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_hoten;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_ngaysinh;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_sodienthoai;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_gioitinh;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_phucap;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_vaitro;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox_donvi;
        private System.Windows.Forms.Button button_close;
        private System.Windows.Forms.Button button_update;
    }
}