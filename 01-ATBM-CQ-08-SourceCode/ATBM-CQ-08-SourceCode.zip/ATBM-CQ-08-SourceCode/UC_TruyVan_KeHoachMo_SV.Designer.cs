﻿namespace ATBM
{
    partial class UC_TruyVan_KeHoachMo_SV
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridView_KeHoachMo = new System.Windows.Forms.DataGridView();
            this.label_HocKy = new System.Windows.Forms.Label();
            this.label_KeHoachMo = new System.Windows.Forms.Label();
            this.comboBox_HocKy_KeHoachMo = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_KeHoachMo)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView_KeHoachMo
            // 
            this.dataGridView_KeHoachMo.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView_KeHoachMo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_KeHoachMo.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_KeHoachMo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 10F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_KeHoachMo.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_KeHoachMo.Enabled = false;
            this.dataGridView_KeHoachMo.Location = new System.Drawing.Point(39, 123);
            this.dataGridView_KeHoachMo.Name = "dataGridView_KeHoachMo";
            this.dataGridView_KeHoachMo.ReadOnly = true;
            this.dataGridView_KeHoachMo.RowHeadersWidth = 51;
            this.dataGridView_KeHoachMo.RowTemplate.Height = 24;
            this.dataGridView_KeHoachMo.Size = new System.Drawing.Size(1134, 566);
            this.dataGridView_KeHoachMo.TabIndex = 29;
            // 
            // label_HocKy
            // 
            this.label_HocKy.AutoSize = true;
            this.label_HocKy.Font = new System.Drawing.Font("Arial", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_HocKy.Location = new System.Drawing.Point(34, 87);
            this.label_HocKy.Name = "label_HocKy";
            this.label_HocKy.Size = new System.Drawing.Size(107, 28);
            this.label_HocKy.TabIndex = 28;
            this.label_HocKy.Text = "Học Kỳ: ";
            // 
            // label_KeHoachMo
            // 
            this.label_KeHoachMo.AutoSize = true;
            this.label_KeHoachMo.Font = new System.Drawing.Font("Arial", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_KeHoachMo.Location = new System.Drawing.Point(32, 31);
            this.label_KeHoachMo.Name = "label_KeHoachMo";
            this.label_KeHoachMo.Size = new System.Drawing.Size(256, 38);
            this.label_KeHoachMo.TabIndex = 27;
            this.label_KeHoachMo.Text = "KẾ HOẠCH MỞ";
            // 
            // comboBox_HocKy_KeHoachMo
            // 
            this.comboBox_HocKy_KeHoachMo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.comboBox_HocKy_KeHoachMo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_HocKy_KeHoachMo.Font = new System.Drawing.Font("Arial", 10F);
            this.comboBox_HocKy_KeHoachMo.FormattingEnabled = true;
            this.comboBox_HocKy_KeHoachMo.Location = new System.Drawing.Point(164, 87);
            this.comboBox_HocKy_KeHoachMo.Name = "comboBox_HocKy_KeHoachMo";
            this.comboBox_HocKy_KeHoachMo.Size = new System.Drawing.Size(1009, 27);
            this.comboBox_HocKy_KeHoachMo.TabIndex = 30;
            this.comboBox_HocKy_KeHoachMo.SelectedIndexChanged += new System.EventHandler(this.comboBox_HocKy_KeHoachMo_SelectedIndexChanged);
            // 
            // UC_TruyVan_KeHoachMo_SV
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.dataGridView_KeHoachMo);
            this.Controls.Add(this.label_HocKy);
            this.Controls.Add(this.label_KeHoachMo);
            this.Controls.Add(this.comboBox_HocKy_KeHoachMo);
            this.Name = "UC_TruyVan_KeHoachMo_SV";
            this.Size = new System.Drawing.Size(1204, 720);
            this.Load += new System.EventHandler(this.UC_TruyVan_KeHoachMo_SV_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_KeHoachMo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView_KeHoachMo;
        private System.Windows.Forms.Label label_HocKy;
        private System.Windows.Forms.Label label_KeHoachMo;
        private System.Windows.Forms.ComboBox comboBox_HocKy_KeHoachMo;
    }
}
