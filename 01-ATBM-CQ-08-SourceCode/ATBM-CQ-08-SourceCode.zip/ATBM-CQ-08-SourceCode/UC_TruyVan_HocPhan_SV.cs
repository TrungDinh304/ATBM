﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;

namespace ATBM
{
    public partial class UC_TruyVan_HocPhan_SV : UserControl
    {
        public UC_TruyVan_HocPhan_SV()
        {
            InitializeComponent();
        }

        private void UC_TruyVan_HocPhan_SV_Load(object sender, EventArgs e)
        {
            string query = "select * from admin1.x_hocphan";
            DataSet ds = new DataSet();
            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    OracleDataAdapter adapter = new OracleDataAdapter(query, connection);
                    adapter.Fill(ds);
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: " + ex.Message);
            }
            dataGridView_HocPhan.DataSource = ds.Tables[0];
            dataGridView_HocPhan.Columns[0].HeaderText = "Mã học phần";
            dataGridView_HocPhan.Columns[1].HeaderText = "Tên học phần";
            dataGridView_HocPhan.Columns[2].HeaderText = "Số tín chỉ";
            dataGridView_HocPhan.Columns[3].HeaderText = "Số tiết lý thuyết";
            dataGridView_HocPhan.Columns[4].HeaderText = "Số tiết thực hành";
            dataGridView_HocPhan.Columns[5].HeaderText = "Số Sinh Viên Tối Đa";
            dataGridView_HocPhan.Columns[6].HeaderText = "Đơn Vị";
        }

        private void button_TimKiem_HocPhan_Click(object sender, EventArgs e)
        {
            string timkiem = textBox_TimKiem_HocPhan.Text;
            string query = $"select * from admin1.x_hocphan where tenhp like \'%{timkiem}%\' or mahp like '%{timkiem}%'";
            DataSet ds = new DataSet();
            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    OracleDataAdapter adapter = new OracleDataAdapter(query, connection);
                    adapter.Fill(ds);
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: " + ex.Message);
            }
            dataGridView_HocPhan.DataSource = ds.Tables[0];
            dataGridView_HocPhan.Columns[0].HeaderText = "Mã học phần";
            dataGridView_HocPhan.Columns[1].HeaderText = "Tên học phần";
            dataGridView_HocPhan.Columns[2].HeaderText = "Số tín chỉ";
            dataGridView_HocPhan.Columns[3].HeaderText = "Số tiết lý thuyết";
            dataGridView_HocPhan.Columns[4].HeaderText = "Số tiết thực hành";
            dataGridView_HocPhan.Columns[5].HeaderText = "Số Sinh Viên Tối Đa";
            dataGridView_HocPhan.Columns[6].HeaderText = "Đơn Vị";
        }
    }
}
