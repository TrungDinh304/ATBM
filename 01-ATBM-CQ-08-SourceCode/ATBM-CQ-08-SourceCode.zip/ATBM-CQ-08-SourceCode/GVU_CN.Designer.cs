﻿namespace ATBM
{
    partial class GVU_CN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gvu_textBox_manv = new System.Windows.Forms.TextBox();
            this.gvu_textBox_hoten = new System.Windows.Forms.TextBox();
            this.gvu_textBox_ngaysinh = new System.Windows.Forms.TextBox();
            this.gvu_textBox_phai = new System.Windows.Forms.TextBox();
            this.gvu_textBox_dienthoai = new System.Windows.Forms.TextBox();
            this.gvu_textBox_phucap = new System.Windows.Forms.TextBox();
            this.gvu_textBox_vaitro = new System.Windows.Forms.TextBox();
            this.gvu_textBox_tendv = new System.Windows.Forms.TextBox();
            this.gvu_label1 = new System.Windows.Forms.Label();
            this.gvu_label2 = new System.Windows.Forms.Label();
            this.gvu_label3 = new System.Windows.Forms.Label();
            this.gvu_label4 = new System.Windows.Forms.Label();
            this.gvu_label5 = new System.Windows.Forms.Label();
            this.gvu_label6 = new System.Windows.Forms.Label();
            this.gvu_label7 = new System.Windows.Forms.Label();
            this.gvu_label8 = new System.Windows.Forms.Label();
            this.gvu_cn_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // gvu_textBox_manv
            // 
            this.gvu_textBox_manv.Enabled = false;
            this.gvu_textBox_manv.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_textBox_manv.Location = new System.Drawing.Point(200, 50);
            this.gvu_textBox_manv.Name = "gvu_textBox_manv";
            this.gvu_textBox_manv.Size = new System.Drawing.Size(400, 30);
            this.gvu_textBox_manv.TabIndex = 0;
            // 
            // gvu_textBox_hoten
            // 
            this.gvu_textBox_hoten.Enabled = false;
            this.gvu_textBox_hoten.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_textBox_hoten.Location = new System.Drawing.Point(200, 100);
            this.gvu_textBox_hoten.Name = "gvu_textBox_hoten";
            this.gvu_textBox_hoten.Size = new System.Drawing.Size(400, 30);
            this.gvu_textBox_hoten.TabIndex = 1;
            // 
            // gvu_textBox_ngaysinh
            // 
            this.gvu_textBox_ngaysinh.Enabled = false;
            this.gvu_textBox_ngaysinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_textBox_ngaysinh.Location = new System.Drawing.Point(200, 150);
            this.gvu_textBox_ngaysinh.Name = "gvu_textBox_ngaysinh";
            this.gvu_textBox_ngaysinh.Size = new System.Drawing.Size(400, 30);
            this.gvu_textBox_ngaysinh.TabIndex = 2;
            // 
            // gvu_textBox_phai
            // 
            this.gvu_textBox_phai.Enabled = false;
            this.gvu_textBox_phai.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_textBox_phai.Location = new System.Drawing.Point(200, 200);
            this.gvu_textBox_phai.Name = "gvu_textBox_phai";
            this.gvu_textBox_phai.Size = new System.Drawing.Size(400, 30);
            this.gvu_textBox_phai.TabIndex = 3;
            // 
            // gvu_textBox_dienthoai
            // 
            this.gvu_textBox_dienthoai.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_textBox_dienthoai.Location = new System.Drawing.Point(200, 250);
            this.gvu_textBox_dienthoai.Name = "gvu_textBox_dienthoai";
            this.gvu_textBox_dienthoai.Size = new System.Drawing.Size(400, 30);
            this.gvu_textBox_dienthoai.TabIndex = 4;
            // 
            // gvu_textBox_phucap
            // 
            this.gvu_textBox_phucap.Enabled = false;
            this.gvu_textBox_phucap.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_textBox_phucap.Location = new System.Drawing.Point(200, 300);
            this.gvu_textBox_phucap.Name = "gvu_textBox_phucap";
            this.gvu_textBox_phucap.Size = new System.Drawing.Size(400, 30);
            this.gvu_textBox_phucap.TabIndex = 5;
            // 
            // gvu_textBox_vaitro
            // 
            this.gvu_textBox_vaitro.Enabled = false;
            this.gvu_textBox_vaitro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_textBox_vaitro.Location = new System.Drawing.Point(200, 350);
            this.gvu_textBox_vaitro.Name = "gvu_textBox_vaitro";
            this.gvu_textBox_vaitro.Size = new System.Drawing.Size(400, 30);
            this.gvu_textBox_vaitro.TabIndex = 6;
            // 
            // gvu_textBox_tendv
            // 
            this.gvu_textBox_tendv.Enabled = false;
            this.gvu_textBox_tendv.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_textBox_tendv.Location = new System.Drawing.Point(200, 400);
            this.gvu_textBox_tendv.Name = "gvu_textBox_tendv";
            this.gvu_textBox_tendv.Size = new System.Drawing.Size(400, 30);
            this.gvu_textBox_tendv.TabIndex = 7;
            // 
            // gvu_label1
            // 
            this.gvu_label1.AutoSize = true;
            this.gvu_label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_label1.Location = new System.Drawing.Point(50, 50);
            this.gvu_label1.Name = "gvu_label1";
            this.gvu_label1.Size = new System.Drawing.Size(130, 25);
            this.gvu_label1.TabIndex = 8;
            this.gvu_label1.Text = "Mã nhân viên";
            // 
            // gvu_label2
            // 
            this.gvu_label2.AutoSize = true;
            this.gvu_label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_label2.Location = new System.Drawing.Point(50, 100);
            this.gvu_label2.Name = "gvu_label2";
            this.gvu_label2.Size = new System.Drawing.Size(69, 25);
            this.gvu_label2.TabIndex = 9;
            this.gvu_label2.Text = "Họ tên";
            // 
            // gvu_label3
            // 
            this.gvu_label3.AutoSize = true;
            this.gvu_label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_label3.Location = new System.Drawing.Point(50, 150);
            this.gvu_label3.Name = "gvu_label3";
            this.gvu_label3.Size = new System.Drawing.Size(99, 25);
            this.gvu_label3.TabIndex = 10;
            this.gvu_label3.Text = "Ngày sinh";
            // 
            // gvu_label4
            // 
            this.gvu_label4.AutoSize = true;
            this.gvu_label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_label4.Location = new System.Drawing.Point(50, 200);
            this.gvu_label4.Name = "gvu_label4";
            this.gvu_label4.Size = new System.Drawing.Size(82, 25);
            this.gvu_label4.TabIndex = 11;
            this.gvu_label4.Text = "Giới tính";
            // 
            // gvu_label5
            // 
            this.gvu_label5.AutoSize = true;
            this.gvu_label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_label5.Location = new System.Drawing.Point(50, 250);
            this.gvu_label5.Name = "gvu_label5";
            this.gvu_label5.Size = new System.Drawing.Size(126, 25);
            this.gvu_label5.TabIndex = 12;
            this.gvu_label5.Text = "Số điện thoại";
            // 
            // gvu_label6
            // 
            this.gvu_label6.AutoSize = true;
            this.gvu_label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_label6.Location = new System.Drawing.Point(50, 300);
            this.gvu_label6.Name = "gvu_label6";
            this.gvu_label6.Size = new System.Drawing.Size(84, 25);
            this.gvu_label6.TabIndex = 13;
            this.gvu_label6.Text = "Phụ cấp";
            // 
            // gvu_label7
            // 
            this.gvu_label7.AutoSize = true;
            this.gvu_label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_label7.Location = new System.Drawing.Point(50, 350);
            this.gvu_label7.Name = "gvu_label7";
            this.gvu_label7.Size = new System.Drawing.Size(68, 25);
            this.gvu_label7.TabIndex = 14;
            this.gvu_label7.Text = "Vai trò";
            // 
            // gvu_label8
            // 
            this.gvu_label8.AutoSize = true;
            this.gvu_label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_label8.Location = new System.Drawing.Point(50, 400);
            this.gvu_label8.Name = "gvu_label8";
            this.gvu_label8.Size = new System.Drawing.Size(104, 25);
            this.gvu_label8.TabIndex = 15;
            this.gvu_label8.Text = "Tên đơn vị";
            // 
            // gvu_cn_button
            // 
            this.gvu_cn_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_cn_button.Location = new System.Drawing.Point(287, 465);
            this.gvu_cn_button.Name = "gvu_cn_button";
            this.gvu_cn_button.Size = new System.Drawing.Size(116, 38);
            this.gvu_cn_button.TabIndex = 16;
            this.gvu_cn_button.Text = "Cập nhật";
            this.gvu_cn_button.UseVisualStyleBackColor = true;
            this.gvu_cn_button.Click += new System.EventHandler(this.gvu_cn_button_Click);
            // 
            // GVU_CN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1282, 603);
            this.Controls.Add(this.gvu_cn_button);
            this.Controls.Add(this.gvu_label8);
            this.Controls.Add(this.gvu_label7);
            this.Controls.Add(this.gvu_label6);
            this.Controls.Add(this.gvu_label5);
            this.Controls.Add(this.gvu_label4);
            this.Controls.Add(this.gvu_label3);
            this.Controls.Add(this.gvu_label2);
            this.Controls.Add(this.gvu_label1);
            this.Controls.Add(this.gvu_textBox_tendv);
            this.Controls.Add(this.gvu_textBox_vaitro);
            this.Controls.Add(this.gvu_textBox_phucap);
            this.Controls.Add(this.gvu_textBox_dienthoai);
            this.Controls.Add(this.gvu_textBox_phai);
            this.Controls.Add(this.gvu_textBox_ngaysinh);
            this.Controls.Add(this.gvu_textBox_hoten);
            this.Controls.Add(this.gvu_textBox_manv);
            this.Name = "GVU_CN";
            this.Text = "GVU_CN";
            this.Load += new System.EventHandler(this.GVU_CN_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox gvu_textBox_manv;
        private System.Windows.Forms.TextBox gvu_textBox_hoten;
        private System.Windows.Forms.TextBox gvu_textBox_ngaysinh;
        private System.Windows.Forms.TextBox gvu_textBox_phai;
        private System.Windows.Forms.TextBox gvu_textBox_dienthoai;
        private System.Windows.Forms.TextBox gvu_textBox_phucap;
        private System.Windows.Forms.TextBox gvu_textBox_vaitro;
        private System.Windows.Forms.TextBox gvu_textBox_tendv;
        private System.Windows.Forms.Label gvu_label1;
        private System.Windows.Forms.Label gvu_label2;
        private System.Windows.Forms.Label gvu_label3;
        private System.Windows.Forms.Label gvu_label4;
        private System.Windows.Forms.Label gvu_label5;
        private System.Windows.Forms.Label gvu_label6;
        private System.Windows.Forms.Label gvu_label7;
        private System.Windows.Forms.Label gvu_label8;
        private System.Windows.Forms.Button gvu_cn_button;
    }
}