﻿namespace ATBM
{
    partial class GVU
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gvu_panel_left = new System.Windows.Forms.Panel();
            this.gvu_label6 = new System.Windows.Forms.Label();
            this.gvu_label5 = new System.Windows.Forms.Label();
            this.gvu_label_chucvu = new System.Windows.Forms.Label();
            this.gvu_label_ten = new System.Windows.Forms.Label();
            this.gvu_button_exit = new System.Windows.Forms.Button();
            this.gvu_button_pc = new System.Windows.Forms.Button();
            this.gvu_label2 = new System.Windows.Forms.Label();
            this.gvu_button_canhan = new System.Windows.Forms.Button();
            this.gvu_button_dkhp = new System.Windows.Forms.Button();
            this.gvu_button_khm = new System.Windows.Forms.Button();
            this.gvu_button_hp = new System.Windows.Forms.Button();
            this.gvu_button_dv = new System.Windows.Forms.Button();
            this.gvu_pictureBox = new System.Windows.Forms.PictureBox();
            this.gvu_button_sv = new System.Windows.Forms.Button();
            this.gvu_panel_top = new System.Windows.Forms.Panel();
            this.gvu_label1 = new System.Windows.Forms.Label();
            this.gvu_panel_body = new System.Windows.Forms.Panel();
            this.gvu_panel_left.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvu_pictureBox)).BeginInit();
            this.gvu_panel_top.SuspendLayout();
            this.SuspendLayout();
            // 
            // gvu_panel_left
            // 
            this.gvu_panel_left.BackColor = System.Drawing.Color.White;
            this.gvu_panel_left.Controls.Add(this.gvu_label6);
            this.gvu_panel_left.Controls.Add(this.gvu_label5);
            this.gvu_panel_left.Controls.Add(this.gvu_label_chucvu);
            this.gvu_panel_left.Controls.Add(this.gvu_label_ten);
            this.gvu_panel_left.Controls.Add(this.gvu_button_exit);
            this.gvu_panel_left.Controls.Add(this.gvu_button_pc);
            this.gvu_panel_left.Controls.Add(this.gvu_label2);
            this.gvu_panel_left.Controls.Add(this.gvu_button_canhan);
            this.gvu_panel_left.Controls.Add(this.gvu_button_dkhp);
            this.gvu_panel_left.Controls.Add(this.gvu_button_khm);
            this.gvu_panel_left.Controls.Add(this.gvu_button_hp);
            this.gvu_panel_left.Controls.Add(this.gvu_button_dv);
            this.gvu_panel_left.Controls.Add(this.gvu_pictureBox);
            this.gvu_panel_left.Controls.Add(this.gvu_button_sv);
            this.gvu_panel_left.Dock = System.Windows.Forms.DockStyle.Left;
            this.gvu_panel_left.Location = new System.Drawing.Point(0, 0);
            this.gvu_panel_left.Name = "gvu_panel_left";
            this.gvu_panel_left.Size = new System.Drawing.Size(270, 753);
            this.gvu_panel_left.TabIndex = 1;
            // 
            // gvu_label6
            // 
            this.gvu_label6.AutoSize = true;
            this.gvu_label6.Location = new System.Drawing.Point(4, 100);
            this.gvu_label6.Name = "gvu_label6";
            this.gvu_label6.Size = new System.Drawing.Size(252, 16);
            this.gvu_label6.TabIndex = 12;
            this.gvu_label6.Text = "___________________________________";
            this.gvu_label6.Click += new System.EventHandler(this.gvu_label6_Click);
            // 
            // gvu_label5
            // 
            this.gvu_label5.AutoSize = true;
            this.gvu_label5.Location = new System.Drawing.Point(4, 670);
            this.gvu_label5.Name = "gvu_label5";
            this.gvu_label5.Size = new System.Drawing.Size(252, 16);
            this.gvu_label5.TabIndex = 11;
            this.gvu_label5.Text = "___________________________________";
            this.gvu_label5.Click += new System.EventHandler(this.gvu_label5_Click);
            // 
            // gvu_label_chucvu
            // 
            this.gvu_label_chucvu.AutoSize = true;
            this.gvu_label_chucvu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_label_chucvu.Location = new System.Drawing.Point(25, 730);
            this.gvu_label_chucvu.Name = "gvu_label_chucvu";
            this.gvu_label_chucvu.Size = new System.Drawing.Size(59, 18);
            this.gvu_label_chucvu.TabIndex = 10;
            this.gvu_label_chucvu.Text = "Giáo vụ";
            this.gvu_label_chucvu.Click += new System.EventHandler(this.gvu_label_chucvu_Click);
            // 
            // gvu_label_ten
            // 
            this.gvu_label_ten.AutoSize = true;
            this.gvu_label_ten.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_label_ten.Location = new System.Drawing.Point(25, 705);
            this.gvu_label_ten.Name = "gvu_label_ten";
            this.gvu_label_ten.Size = new System.Drawing.Size(95, 20);
            this.gvu_label_ten.TabIndex = 9;
            this.gvu_label_ten.Text = "Tên giáo vụ";
            this.gvu_label_ten.Click += new System.EventHandler(this.gvu_label_ten_Click);
            // 
            // gvu_button_exit
            // 
            this.gvu_button_exit.FlatAppearance.BorderSize = 0;
            this.gvu_button_exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gvu_button_exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_button_exit.Image = global::ATBM.Properties.Resources.exit;
            this.gvu_button_exit.Location = new System.Drawing.Point(220, 703);
            this.gvu_button_exit.Name = "gvu_button_exit";
            this.gvu_button_exit.Size = new System.Drawing.Size(50, 50);
            this.gvu_button_exit.TabIndex = 0;
            this.gvu_button_exit.UseVisualStyleBackColor = true;
            this.gvu_button_exit.Click += new System.EventHandler(this.gvu_button_exit_Click);
            // 
            // gvu_button_pc
            // 
            this.gvu_button_pc.FlatAppearance.BorderSize = 0;
            this.gvu_button_pc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gvu_button_pc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_button_pc.Image = global::ATBM.Properties.Resources.phancong;
            this.gvu_button_pc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.gvu_button_pc.Location = new System.Drawing.Point(0, 400);
            this.gvu_button_pc.Name = "gvu_button_pc";
            this.gvu_button_pc.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.gvu_button_pc.Size = new System.Drawing.Size(270, 50);
            this.gvu_button_pc.TabIndex = 8;
            this.gvu_button_pc.Text = "Phân công";
            this.gvu_button_pc.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.gvu_button_pc.UseVisualStyleBackColor = true;
            this.gvu_button_pc.Click += new System.EventHandler(this.gvu_button_pc_Click);
            // 
            // gvu_label2
            // 
            this.gvu_label2.AutoSize = true;
            this.gvu_label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_label2.Location = new System.Drawing.Point(3, 150);
            this.gvu_label2.Name = "gvu_label2";
            this.gvu_label2.Size = new System.Drawing.Size(73, 20);
            this.gvu_label2.TabIndex = 7;
            this.gvu_label2.Text = "Truy vấn";
            // 
            // gvu_button_canhan
            // 
            this.gvu_button_canhan.FlatAppearance.BorderSize = 0;
            this.gvu_button_canhan.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.gvu_button_canhan.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.gvu_button_canhan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gvu_button_canhan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_button_canhan.Location = new System.Drawing.Point(0, 703);
            this.gvu_button_canhan.Name = "gvu_button_canhan";
            this.gvu_button_canhan.Size = new System.Drawing.Size(220, 50);
            this.gvu_button_canhan.TabIndex = 6;
            this.gvu_button_canhan.UseVisualStyleBackColor = true;
            this.gvu_button_canhan.Click += new System.EventHandler(this.gvu_button_canhan_Click);
            // 
            // gvu_button_dkhp
            // 
            this.gvu_button_dkhp.FlatAppearance.BorderSize = 0;
            this.gvu_button_dkhp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gvu_button_dkhp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_button_dkhp.Image = global::ATBM.Properties.Resources.hocphan1;
            this.gvu_button_dkhp.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.gvu_button_dkhp.Location = new System.Drawing.Point(0, 450);
            this.gvu_button_dkhp.Name = "gvu_button_dkhp";
            this.gvu_button_dkhp.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.gvu_button_dkhp.Size = new System.Drawing.Size(270, 50);
            this.gvu_button_dkhp.TabIndex = 5;
            this.gvu_button_dkhp.Text = "Đăng ký học phần";
            this.gvu_button_dkhp.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.gvu_button_dkhp.UseVisualStyleBackColor = true;
            this.gvu_button_dkhp.Click += new System.EventHandler(this.gvu_button_dkhp_Click);
            // 
            // gvu_button_khm
            // 
            this.gvu_button_khm.FlatAppearance.BorderSize = 0;
            this.gvu_button_khm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gvu_button_khm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_button_khm.Image = global::ATBM.Properties.Resources.kehoachmo;
            this.gvu_button_khm.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.gvu_button_khm.Location = new System.Drawing.Point(0, 350);
            this.gvu_button_khm.Name = "gvu_button_khm";
            this.gvu_button_khm.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.gvu_button_khm.Size = new System.Drawing.Size(270, 50);
            this.gvu_button_khm.TabIndex = 4;
            this.gvu_button_khm.Text = "Kế hoạch mở";
            this.gvu_button_khm.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.gvu_button_khm.UseVisualStyleBackColor = true;
            this.gvu_button_khm.Click += new System.EventHandler(this.gvu_button_khm_Click);
            // 
            // gvu_button_hp
            // 
            this.gvu_button_hp.FlatAppearance.BorderSize = 0;
            this.gvu_button_hp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gvu_button_hp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_button_hp.Image = global::ATBM.Properties.Resources.hocphan;
            this.gvu_button_hp.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.gvu_button_hp.Location = new System.Drawing.Point(0, 300);
            this.gvu_button_hp.Name = "gvu_button_hp";
            this.gvu_button_hp.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.gvu_button_hp.Size = new System.Drawing.Size(270, 50);
            this.gvu_button_hp.TabIndex = 3;
            this.gvu_button_hp.Text = "Học phần";
            this.gvu_button_hp.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.gvu_button_hp.UseVisualStyleBackColor = true;
            this.gvu_button_hp.Click += new System.EventHandler(this.gvu_button_hp_Click);
            // 
            // gvu_button_dv
            // 
            this.gvu_button_dv.FlatAppearance.BorderSize = 0;
            this.gvu_button_dv.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gvu_button_dv.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_button_dv.Image = global::ATBM.Properties.Resources.donvi;
            this.gvu_button_dv.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.gvu_button_dv.Location = new System.Drawing.Point(0, 250);
            this.gvu_button_dv.Name = "gvu_button_dv";
            this.gvu_button_dv.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.gvu_button_dv.Size = new System.Drawing.Size(270, 50);
            this.gvu_button_dv.TabIndex = 2;
            this.gvu_button_dv.Text = "Đơn vị";
            this.gvu_button_dv.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.gvu_button_dv.UseVisualStyleBackColor = true;
            this.gvu_button_dv.Click += new System.EventHandler(this.gvu_button_dv_Click);
            // 
            // gvu_pictureBox
            // 
            this.gvu_pictureBox.Dock = System.Windows.Forms.DockStyle.Top;
            this.gvu_pictureBox.Image = global::ATBM.Properties.Resources.logo;
            this.gvu_pictureBox.Location = new System.Drawing.Point(0, 0);
            this.gvu_pictureBox.Name = "gvu_pictureBox";
            this.gvu_pictureBox.Size = new System.Drawing.Size(270, 100);
            this.gvu_pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gvu_pictureBox.TabIndex = 1;
            this.gvu_pictureBox.TabStop = false;
            this.gvu_pictureBox.Click += new System.EventHandler(this.gvu_pictureBox_Click);
            // 
            // gvu_button_sv
            // 
            this.gvu_button_sv.BackColor = System.Drawing.Color.White;
            this.gvu_button_sv.FlatAppearance.BorderSize = 0;
            this.gvu_button_sv.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gvu_button_sv.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_button_sv.ForeColor = System.Drawing.SystemColors.ControlText;
            this.gvu_button_sv.Image = global::ATBM.Properties.Resources.sinhvien;
            this.gvu_button_sv.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.gvu_button_sv.Location = new System.Drawing.Point(0, 200);
            this.gvu_button_sv.Name = "gvu_button_sv";
            this.gvu_button_sv.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.gvu_button_sv.Size = new System.Drawing.Size(270, 50);
            this.gvu_button_sv.TabIndex = 0;
            this.gvu_button_sv.Text = "Sinh viên";
            this.gvu_button_sv.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.gvu_button_sv.UseVisualStyleBackColor = false;
            this.gvu_button_sv.Click += new System.EventHandler(this.gvu_button_sv_Click);
            // 
            // gvu_panel_top
            // 
            this.gvu_panel_top.BackColor = System.Drawing.Color.White;
            this.gvu_panel_top.Controls.Add(this.gvu_label1);
            this.gvu_panel_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.gvu_panel_top.Location = new System.Drawing.Point(270, 0);
            this.gvu_panel_top.Name = "gvu_panel_top";
            this.gvu_panel_top.Size = new System.Drawing.Size(1312, 100);
            this.gvu_panel_top.TabIndex = 2;
            this.gvu_panel_top.Paint += new System.Windows.Forms.PaintEventHandler(this.gvu_panel_top_Paint);
            // 
            // gvu_label1
            // 
            this.gvu_label1.AutoSize = true;
            this.gvu_label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_label1.Location = new System.Drawing.Point(20, 36);
            this.gvu_label1.Name = "gvu_label1";
            this.gvu_label1.Size = new System.Drawing.Size(179, 39);
            this.gvu_label1.TabIndex = 0;
            this.gvu_label1.Text = "Trang chủ";
            // 
            // gvu_panel_body
            // 
            this.gvu_panel_body.BackColor = System.Drawing.Color.White;
            this.gvu_panel_body.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gvu_panel_body.Location = new System.Drawing.Point(270, 100);
            this.gvu_panel_body.Name = "gvu_panel_body";
            this.gvu_panel_body.Size = new System.Drawing.Size(1312, 653);
            this.gvu_panel_body.TabIndex = 3;
            //this.gvu_panel_body.Paint += new System.Windows.Forms.PaintEventHandler(this.gvu_panel_body_Paint);
            // 
            // GVU
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1582, 753);
            this.Controls.Add(this.gvu_panel_body);
            this.Controls.Add(this.gvu_panel_top);
            this.Controls.Add(this.gvu_panel_left);
            this.Name = "GVU";
            this.Text = "GVU";
            this.Load += new System.EventHandler(this.GVU_Load);
            this.gvu_panel_left.ResumeLayout(false);
            this.gvu_panel_left.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvu_pictureBox)).EndInit();
            this.gvu_panel_top.ResumeLayout(false);
            this.gvu_panel_top.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel gvu_panel_left;
        private System.Windows.Forms.Panel gvu_panel_top;
        private System.Windows.Forms.Panel gvu_panel_body;
        private System.Windows.Forms.Button gvu_button_dv;
        private System.Windows.Forms.PictureBox gvu_pictureBox;
        private System.Windows.Forms.Label gvu_label1;
        private System.Windows.Forms.Button gvu_button_sv;
        private System.Windows.Forms.Button gvu_button_dkhp;
        private System.Windows.Forms.Button gvu_button_khm;
        private System.Windows.Forms.Button gvu_button_hp;
        private System.Windows.Forms.Button gvu_button_canhan;
        private System.Windows.Forms.Label gvu_label2;
        private System.Windows.Forms.Button gvu_button_pc;
        private System.Windows.Forms.Button gvu_button_exit;
        private System.Windows.Forms.Label gvu_label_chucvu;
        private System.Windows.Forms.Label gvu_label_ten;
        private System.Windows.Forms.Label gvu_label5;
        private System.Windows.Forms.Label gvu_label6;
    }
}