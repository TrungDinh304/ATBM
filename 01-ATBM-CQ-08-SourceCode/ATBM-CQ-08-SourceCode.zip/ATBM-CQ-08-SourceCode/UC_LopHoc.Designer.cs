﻿namespace ATBM
{
    partial class UC_LopHoc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label_LopHoc = new System.Windows.Forms.Label();
            this.dataGridView_LopHoc = new System.Windows.Forms.DataGridView();
            this.Option = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label_HocKy = new System.Windows.Forms.Label();
            this.comboBox_HocKy_LH = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_LopHoc)).BeginInit();
            this.SuspendLayout();
            // 
            // label_LopHoc
            // 
            this.label_LopHoc.AutoSize = true;
            this.label_LopHoc.Font = new System.Drawing.Font("Arial", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_LopHoc.Location = new System.Drawing.Point(32, 33);
            this.label_LopHoc.Name = "label_LopHoc";
            this.label_LopHoc.Size = new System.Drawing.Size(166, 38);
            this.label_LopHoc.TabIndex = 0;
            this.label_LopHoc.Text = "LỚP HỌC";
            // 
            // dataGridView_LopHoc
            // 
            this.dataGridView_LopHoc.AllowUserToAddRows = false;
            this.dataGridView_LopHoc.AllowUserToDeleteRows = false;
            this.dataGridView_LopHoc.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_LopHoc.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView_LopHoc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_LopHoc.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView_LopHoc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_LopHoc.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Option});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_LopHoc.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView_LopHoc.Location = new System.Drawing.Point(39, 132);
            this.dataGridView_LopHoc.Name = "dataGridView_LopHoc";
            this.dataGridView_LopHoc.ReadOnly = true;
            this.dataGridView_LopHoc.RowHeadersWidth = 51;
            this.dataGridView_LopHoc.RowTemplate.Height = 24;
            this.dataGridView_LopHoc.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_LopHoc.Size = new System.Drawing.Size(1134, 566);
            this.dataGridView_LopHoc.TabIndex = 1;
            this.dataGridView_LopHoc.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_LopHoc_CellContentDoubleClick);
            // 
            // Option
            // 
            this.Option.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Option.HeaderText = "Danh sách";
            this.Option.MinimumWidth = 6;
            this.Option.Name = "Option";
            this.Option.ReadOnly = true;
            this.Option.Text = "Xem";
            this.Option.UseColumnTextForButtonValue = true;
            // 
            // label_HocKy
            // 
            this.label_HocKy.AutoSize = true;
            this.label_HocKy.Font = new System.Drawing.Font("Arial", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_HocKy.Location = new System.Drawing.Point(34, 89);
            this.label_HocKy.Name = "label_HocKy";
            this.label_HocKy.Size = new System.Drawing.Size(100, 28);
            this.label_HocKy.TabIndex = 2;
            this.label_HocKy.Text = "Học Kỳ:";
            // 
            // comboBox_HocKy_LH
            // 
            this.comboBox_HocKy_LH.Cursor = System.Windows.Forms.Cursors.Hand;
            this.comboBox_HocKy_LH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_HocKy_LH.Font = new System.Drawing.Font("Arial", 10F);
            this.comboBox_HocKy_LH.FormattingEnabled = true;
            this.comboBox_HocKy_LH.Items.AddRange(new object[] {
            ""});
            this.comboBox_HocKy_LH.Location = new System.Drawing.Point(164, 93);
            this.comboBox_HocKy_LH.Name = "comboBox_HocKy_LH";
            this.comboBox_HocKy_LH.Size = new System.Drawing.Size(1009, 27);
            this.comboBox_HocKy_LH.Sorted = true;
            this.comboBox_HocKy_LH.TabIndex = 3;
            this.comboBox_HocKy_LH.SelectedIndexChanged += new System.EventHandler(this.comboBox_HocKy_LH_SelectedIndexChanged);
            // 
            // UC_LopHoc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.comboBox_HocKy_LH);
            this.Controls.Add(this.label_HocKy);
            this.Controls.Add(this.dataGridView_LopHoc);
            this.Controls.Add(this.label_LopHoc);
            this.Name = "UC_LopHoc";
            this.Size = new System.Drawing.Size(1204, 720);
            this.Load += new System.EventHandler(this.UC_LopHoc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_LopHoc)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_LopHoc;
        private System.Windows.Forms.DataGridView dataGridView_LopHoc;
        private System.Windows.Forms.Label label_HocKy;
        private System.Windows.Forms.ComboBox comboBox_HocKy_LH;
        private System.Windows.Forms.DataGridViewButtonColumn Option;
    }
}
