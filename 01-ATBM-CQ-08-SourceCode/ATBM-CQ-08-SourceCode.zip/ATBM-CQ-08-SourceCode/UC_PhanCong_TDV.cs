﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;


namespace ATBM
{
    public partial class UC_PhanCong_TDV : UserControl
    {
        public UC_PhanCong_TDV()
        {
            InitializeComponent();
        }

        private void fill_data_toComboBox()
        {
            // tạo câu lệnh truy vấn
            string query_statement = "select distinct HK ||'-'||nam as hocki from admin1.x_PhanCong";
            // kết nối với database oracle 
            DataSet ds_hocky = new DataSet();
            try
            {
                // Mở kết nối đến cơ sở dữ liệu
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    //lấy dữ liệu từ bảng
                    OracleDataAdapter adapter = new OracleDataAdapter(query_statement, connection);
                    adapter.Fill(ds_hocky);
                    // đóng kết nối
                    connection.Close();

                }
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có
                MessageBox.Show("Lỗi khi kiểm tra sự tồn tại của người dùng: " + ex.Message);
            }
            // rót dữ liệu vào combobox
            comboBox_HocKy_PC.DataSource = ds_hocky.Tables[0];
            comboBox_HocKy_PC.DisplayMember = "hocki";
            comboBox_HocKy_PC.ValueMember = "hocki";
        }   
        private void UC_PhanCong_TDV_Load(object sender, EventArgs e)
        {
            fill_data_toComboBox();
            comboBox_HocKy_PC_SelectedIndexChanged(sender, e);
        }

        private void comboBox_HocKy_PC_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox_HocKy_PC.Items.Count == 0)
            {
                return;
            }
            if (comboBox_HocKy_PC.SelectedValue == null)
            {
                return;
            }
            if (comboBox_HocKy_PC.SelectedValue.ToString() == "System.Data.DataRowView")
            {
                return;
            }

            // lấy giá trị của combobox
            string hocky = comboBox_HocKy_PC.SelectedValue.ToString();
            // tách chuỗi HOCKI để lấy thược tính HK và NAM
            string[] HOCKI = hocky.Split('-');
            string HK = HOCKI[0];
            string NAM = HOCKI[1];

            // tạo câu lệnh truy vấn
            string query_statement = "select * from admin1.x_phancong where HK = '" + HK + "' and NAM = '" + NAM + "'";

            DataSet ds_phancong = new DataSet();

            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    //lấy dữ liệu từ bảng
                    OracleDataAdapter adapter = new OracleDataAdapter(query_statement, connection);
                    adapter.Fill(ds_phancong);
                    // đóng kết nối
                    connection.Close();
                    // rót dữ liệu vào datagridview
                    dataGridView_PhanCong.DataSource = ds_phancong.Tables[0];
                }
                dataGridView_PhanCong.Columns[1].HeaderText = "Mã giáo viên";
                dataGridView_PhanCong.Columns[2].HeaderText = "Mã học phần";
                dataGridView_PhanCong.Columns[3].HeaderText = "Học kỳ";
                dataGridView_PhanCong.Columns[4].HeaderText = "Năm";
                dataGridView_PhanCong.Columns[5].HeaderText = "Mã chương trình";

            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: " + ex.Message);
            }
            this.dataGridView_PhanCong.Columns["Option"].DisplayIndex = dataGridView_PhanCong.ColumnCount - 1;
            this.dataGridView_PhanCong.Columns["Option"].Selected = true;
        }

        static public class Selected_PC
        {
            public static string Magv;
            public static string Mahp;
            public static string Hocki;
            public static string Nam;
            public static string Mact;
        }

        static public string loai_tuychinh;

        private void dataGridView_PhanCong_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Selected_PC.Magv = dataGridView_PhanCong.Rows[e.RowIndex].Cells[1].Value.ToString();
            Selected_PC.Mahp = dataGridView_PhanCong.Rows[e.RowIndex].Cells[2].Value.ToString();
            Selected_PC.Hocki = dataGridView_PhanCong.Rows[e.RowIndex].Cells[3].Value.ToString();
            Selected_PC.Nam = dataGridView_PhanCong.Rows[e.RowIndex].Cells[4].Value.ToString();
            Selected_PC.Mact = dataGridView_PhanCong.Rows[e.RowIndex].Cells[5].Value.ToString();

            loai_tuychinh = "update";
            f_modify_PC_TDV f = new f_modify_PC_TDV();
            f.ShowDialog();
            comboBox_HocKy_PC_SelectedIndexChanged(sender, e);
        }

        private void button_insert_Click(object sender, EventArgs e)
        {
            loai_tuychinh = "insert";
            f_modify_PC_TDV f = new f_modify_PC_TDV();
            f.ShowDialog();
            comboBox_HocKy_PC_SelectedIndexChanged(sender, e);

        }
    }
}
