﻿namespace ATBM
{
    partial class Form_Update_diem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label_MSSV = new System.Windows.Forms.Label();
            this.label_HoTen = new System.Windows.Forms.Label();
            this.label_DiemTK = new System.Windows.Forms.Label();
            this.label_diem_Cuoi_ki = new System.Windows.Forms.Label();
            this.label_LiThuyet = new System.Windows.Forms.Label();
            this.label_DiemTH = new System.Windows.Forms.Label();
            this.label_value_mssv = new System.Windows.Forms.Label();
            this.label_value_hoten = new System.Windows.Forms.Label();
            this.label_value_diemtk = new System.Windows.Forms.Label();
            this.textBox_DiemTH = new System.Windows.Forms.TextBox();
            this.textBox_DiemLT = new System.Windows.Forms.TextBox();
            this.textBox_DiemCK = new System.Windows.Forms.TextBox();
            this.button_Dong = new System.Windows.Forms.Button();
            this.button_Luu = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(105, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(243, 38);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cập nhật điểm";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.Enabled = false;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(12, 67);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(448, 441);
            this.button1.TabIndex = 1;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button2.Enabled = false;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(12, 228);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(448, 280);
            this.button2.TabIndex = 2;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // label_MSSV
            // 
            this.label_MSSV.AutoSize = true;
            this.label_MSSV.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_MSSV.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label_MSSV.Location = new System.Drawing.Point(55, 99);
            this.label_MSSV.Name = "label_MSSV";
            this.label_MSSV.Size = new System.Drawing.Size(71, 23);
            this.label_MSSV.TabIndex = 3;
            this.label_MSSV.Text = "MSSV:";
            // 
            // label_HoTen
            // 
            this.label_HoTen.AutoSize = true;
            this.label_HoTen.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_HoTen.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label_HoTen.Location = new System.Drawing.Point(55, 141);
            this.label_HoTen.Name = "label_HoTen";
            this.label_HoTen.Size = new System.Drawing.Size(105, 23);
            this.label_HoTen.TabIndex = 4;
            this.label_HoTen.Text = "Họ và Tên:";
            // 
            // label_DiemTK
            // 
            this.label_DiemTK.AutoSize = true;
            this.label_DiemTK.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_DiemTK.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label_DiemTK.Location = new System.Drawing.Point(55, 183);
            this.label_DiemTK.Name = "label_DiemTK";
            this.label_DiemTK.Size = new System.Drawing.Size(147, 23);
            this.label_DiemTK.TabIndex = 5;
            this.label_DiemTK.Text = "Điểm Tổng Kết:";
            // 
            // label_diem_Cuoi_ki
            // 
            this.label_diem_Cuoi_ki.AutoSize = true;
            this.label_diem_Cuoi_ki.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_diem_Cuoi_ki.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label_diem_Cuoi_ki.Location = new System.Drawing.Point(55, 350);
            this.label_diem_Cuoi_ki.Name = "label_diem_Cuoi_ki";
            this.label_diem_Cuoi_ki.Size = new System.Drawing.Size(131, 23);
            this.label_diem_Cuoi_ki.TabIndex = 8;
            this.label_diem_Cuoi_ki.Text = "Điểm Cuối Kì:";
            // 
            // label_LiThuyet
            // 
            this.label_LiThuyet.AutoSize = true;
            this.label_LiThuyet.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_LiThuyet.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label_LiThuyet.Location = new System.Drawing.Point(55, 265);
            this.label_LiThuyet.Name = "label_LiThuyet";
            this.label_LiThuyet.Size = new System.Drawing.Size(149, 23);
            this.label_LiThuyet.TabIndex = 7;
            this.label_LiThuyet.Text = "Điểm Lí Thuyết:";
            // 
            // label_DiemTH
            // 
            this.label_DiemTH.AutoSize = true;
            this.label_DiemTH.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_DiemTH.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label_DiemTH.Location = new System.Drawing.Point(55, 310);
            this.label_DiemTH.Name = "label_DiemTH";
            this.label_DiemTH.Size = new System.Drawing.Size(162, 23);
            this.label_DiemTH.TabIndex = 6;
            this.label_DiemTH.Text = "Điểm Thực Hành:";
            // 
            // label_value_mssv
            // 
            this.label_value_mssv.AutoSize = true;
            this.label_value_mssv.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_value_mssv.Location = new System.Drawing.Point(235, 99);
            this.label_value_mssv.Name = "label_value_mssv";
            this.label_value_mssv.Size = new System.Drawing.Size(72, 23);
            this.label_value_mssv.TabIndex = 9;
            this.label_value_mssv.Text = "# value";
            // 
            // label_value_hoten
            // 
            this.label_value_hoten.AutoSize = true;
            this.label_value_hoten.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_value_hoten.Location = new System.Drawing.Point(235, 141);
            this.label_value_hoten.Name = "label_value_hoten";
            this.label_value_hoten.Size = new System.Drawing.Size(72, 23);
            this.label_value_hoten.TabIndex = 10;
            this.label_value_hoten.Text = "# value";
            // 
            // label_value_diemtk
            // 
            this.label_value_diemtk.AutoSize = true;
            this.label_value_diemtk.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_value_diemtk.Location = new System.Drawing.Point(235, 183);
            this.label_value_diemtk.Name = "label_value_diemtk";
            this.label_value_diemtk.Size = new System.Drawing.Size(72, 23);
            this.label_value_diemtk.TabIndex = 11;
            this.label_value_diemtk.Text = "# value";
            // 
            // textBox_DiemTH
            // 
            this.textBox_DiemTH.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_DiemTH.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBox_DiemTH.Location = new System.Drawing.Point(294, 308);
            this.textBox_DiemTH.Name = "textBox_DiemTH";
            this.textBox_DiemTH.Size = new System.Drawing.Size(124, 30);
            this.textBox_DiemTH.TabIndex = 2;
            this.textBox_DiemTH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_DiemLT
            // 
            this.textBox_DiemLT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_DiemLT.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBox_DiemLT.Location = new System.Drawing.Point(294, 263);
            this.textBox_DiemLT.Name = "textBox_DiemLT";
            this.textBox_DiemLT.Size = new System.Drawing.Size(124, 30);
            this.textBox_DiemLT.TabIndex = 1;
            this.textBox_DiemLT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_DiemCK
            // 
            this.textBox_DiemCK.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_DiemCK.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBox_DiemCK.Location = new System.Drawing.Point(294, 348);
            this.textBox_DiemCK.Name = "textBox_DiemCK";
            this.textBox_DiemCK.Size = new System.Drawing.Size(124, 30);
            this.textBox_DiemCK.TabIndex = 3;
            this.textBox_DiemCK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button_Dong
            // 
            this.button_Dong.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.button_Dong.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button_Dong.Location = new System.Drawing.Point(59, 430);
            this.button_Dong.Name = "button_Dong";
            this.button_Dong.Size = new System.Drawing.Size(124, 43);
            this.button_Dong.TabIndex = 15;
            this.button_Dong.Text = "Đóng";
            this.button_Dong.UseVisualStyleBackColor = false;
            this.button_Dong.Click += new System.EventHandler(this.button_Dong_Click);
            // 
            // button_Luu
            // 
            this.button_Luu.BackColor = System.Drawing.Color.Plum;
            this.button_Luu.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button_Luu.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_Luu.Location = new System.Drawing.Point(294, 430);
            this.button_Luu.Name = "button_Luu";
            this.button_Luu.Size = new System.Drawing.Size(124, 43);
            this.button_Luu.TabIndex = 16;
            this.button_Luu.Text = "Lưu";
            this.button_Luu.UseVisualStyleBackColor = false;
            this.button_Luu.Click += new System.EventHandler(this.button_Luu_Click);
            // 
            // Form_Update_diem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(478, 520);
            this.Controls.Add(this.button_Luu);
            this.Controls.Add(this.button_Dong);
            this.Controls.Add(this.textBox_DiemCK);
            this.Controls.Add(this.textBox_DiemTH);
            this.Controls.Add(this.label_value_diemtk);
            this.Controls.Add(this.label_value_hoten);
            this.Controls.Add(this.label_value_mssv);
            this.Controls.Add(this.label_diem_Cuoi_ki);
            this.Controls.Add(this.label_LiThuyet);
            this.Controls.Add(this.label_DiemTH);
            this.Controls.Add(this.label_DiemTK);
            this.Controls.Add(this.label_HoTen);
            this.Controls.Add(this.label_MSSV);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox_DiemLT);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Form_Update_diem";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Cập nhật điểm";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Form_Update_diem_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label_MSSV;
        private System.Windows.Forms.Label label_HoTen;
        private System.Windows.Forms.Label label_DiemTK;
        private System.Windows.Forms.Label label_diem_Cuoi_ki;
        private System.Windows.Forms.Label label_LiThuyet;
        private System.Windows.Forms.Label label_DiemTH;
        private System.Windows.Forms.Label label_value_mssv;
        private System.Windows.Forms.Label label_value_hoten;
        private System.Windows.Forms.Label label_value_diemtk;
        private System.Windows.Forms.TextBox textBox_DiemTH;
        private System.Windows.Forms.TextBox textBox_DiemLT;
        private System.Windows.Forms.TextBox textBox_DiemCK;
        private System.Windows.Forms.Button button_Dong;
        private System.Windows.Forms.Button button_Luu;
    }
}