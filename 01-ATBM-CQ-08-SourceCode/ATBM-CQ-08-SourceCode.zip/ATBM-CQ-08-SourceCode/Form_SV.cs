﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Image = System.Drawing.Image;
using ATBM;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;

namespace ATBM
{
    public partial class Form_SV : Form
    {
        public Form_SV()
        {
            InitializeComponent();
            pictureBox_DangKy.Image = Image.FromFile("../../img/Pink_dangkihocphan.png");
            UC_DangKyHocPhan_SV uc = new UC_DangKyHocPhan_SV();
            open_UC_control(uc);
        }

        public void open_UC_control(Control uc)
        {
            // Dock vào panel và đưa lên trước
            uc.Dock = DockStyle.Fill;
            panel_ControlContainer.Controls.Add(uc);
            uc.BringToFront();
        }

        private void Form_SV_Load(object sender, EventArgs e)
        {
            label_role.Text = Login_information.role;
            lable_Username.Text = Login_information.fullname;
        }

        private void pictureBox_DangKy_Click(object sender, EventArgs e)
        {
            //Thay đổi ảnh khi click vào
            // ảnh lấy từ file được lưu local
            pictureBox_DangKy.Image = Image.FromFile("../../img/Pink_dangkihocphan.png");

            pictureBox_KeHoachMo.Image = Image.FromFile("../../img/Black_kehoachmo.png");
            pictureBox_HocPhan.Image = Image.FromFile("../../img/Black_hocphan.png");


            // nếu chưa tạo UC_LopHoc thì tạo mới
            foreach (Control c in panel_ControlContainer.Controls)
            {
                if (c is UC_TruyVan_KeHoachMo_GV)
                {
                    // Control is of type UC_LopHoc and is contained by the panel
                    open_UC_control(c);
                    return;
                }
            }
            UC_DangKyHocPhan_SV uc = new UC_DangKyHocPhan_SV();
            open_UC_control(uc);
        }

        private void pictureBox_KeHoachMo_Click(object sender, EventArgs e)
        {
            //Thay đổi ảnh khi click vào
            // ảnh lấy từ file được lưu local
            pictureBox_KeHoachMo.Image = Image.FromFile("../../img/Pink_kehoachmo.png");

            pictureBox_DangKy.Image = Image.FromFile("../../img/Black_dangkihocphan.png");
            pictureBox_HocPhan.Image = Image.FromFile("../../img/Black_hocphan.png");


            // nếu chưa tạo UC_LopHoc thì tạo mới
            foreach (Control c in panel_ControlContainer.Controls)
            {
                if (c is UC_TruyVan_KeHoachMo_GV)
                {
                    // Control is of type UC_LopHoc and is contained by the panel
                    open_UC_control(c);
                    return;
                }
            }
            UC_TruyVan_KeHoachMo_SV uc = new UC_TruyVan_KeHoachMo_SV();
            open_UC_control(uc);
        }

        private void pictureBox_HocPhan_Click(object sender, EventArgs e)
        {
            //Thay đổi ảnh khi click vào
            // ảnh lấy từ file được lưu local
            pictureBox_HocPhan.Image = Image.FromFile("../../img/Pink_hocphan.png");

            pictureBox_DangKy.Image = Image.FromFile("../../img/Black_dangkihocphan.png");
            pictureBox_KeHoachMo.Image = Image.FromFile("../../img/Black_kehoachmo.png");


            // nếu chưa tạo UC_LopHoc thì tạo mới
            foreach (Control c in panel_ControlContainer.Controls)
            {
                if (c is UC_TruyVan_HocPhan_GV)
                {
                    // Control is of type UC_LopHoc and is contained by the panel
                    open_UC_control(c);
                    return;
                }
            }
            UC_TruyVan_HocPhan_SV uc = new UC_TruyVan_HocPhan_SV();
            open_UC_control(uc);
        }

        private void pictureBox_avatar_Click(object sender, EventArgs e)
        {
            // Mở form thông tin cá nhân
            ATBM.Form_PI_SV form = new ATBM.Form_PI_SV();
            form.ShowDialog();
        }

        private void lable_Username_Click(object sender, EventArgs e)
        {
            // Mở form thông tin cá nhân
            ATBM.Form_PI_SV form = new ATBM.Form_PI_SV();
            form.ShowDialog();
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            this.FindForm().Close();
        }
    }
}
