﻿namespace ATBM
{
    partial class GVU_DV
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gvu_dv_label1 = new System.Windows.Forms.Label();
            this.gvu_dv_textBox1 = new System.Windows.Forms.TextBox();
            this.gvu_dv_btn1 = new System.Windows.Forms.Button();
            this.gvu_dv_btn2 = new System.Windows.Forms.Button();
            this.gvu_dv_dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.gvu_dv_dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // gvu_dv_label1
            // 
            this.gvu_dv_label1.AutoSize = true;
            this.gvu_dv_label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_dv_label1.Location = new System.Drawing.Point(18, 45);
            this.gvu_dv_label1.Name = "gvu_dv_label1";
            this.gvu_dv_label1.Size = new System.Drawing.Size(67, 25);
            this.gvu_dv_label1.TabIndex = 0;
            this.gvu_dv_label1.Text = "Đơn vị";
            // 
            // gvu_dv_textBox1
            // 
            this.gvu_dv_textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_dv_textBox1.Location = new System.Drawing.Point(117, 42);
            this.gvu_dv_textBox1.Name = "gvu_dv_textBox1";
            this.gvu_dv_textBox1.Size = new System.Drawing.Size(400, 30);
            this.gvu_dv_textBox1.TabIndex = 1;
            this.gvu_dv_textBox1.TextChanged += new System.EventHandler(this.gvu_dv_textBox1_TextChanged);
            // 
            // gvu_dv_btn1
            // 
            this.gvu_dv_btn1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(89)))), ((int)(((byte)(47)))));
            this.gvu_dv_btn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_dv_btn1.ForeColor = System.Drawing.Color.White;
            this.gvu_dv_btn1.Image = global::ATBM.Properties.Resources.them;
            this.gvu_dv_btn1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.gvu_dv_btn1.Location = new System.Drawing.Point(917, 36);
            this.gvu_dv_btn1.Margin = new System.Windows.Forms.Padding(0);
            this.gvu_dv_btn1.Name = "gvu_dv_btn1";
            this.gvu_dv_btn1.Size = new System.Drawing.Size(130, 42);
            this.gvu_dv_btn1.TabIndex = 2;
            this.gvu_dv_btn1.Text = "Thêm";
            this.gvu_dv_btn1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.gvu_dv_btn1.UseVisualStyleBackColor = false;
            this.gvu_dv_btn1.Click += new System.EventHandler(this.gvu_dv_btn1_Click);
            // 
            // gvu_dv_btn2
            // 
            this.gvu_dv_btn2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(139)))), ((int)(((byte)(17)))));
            this.gvu_dv_btn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_dv_btn2.ForeColor = System.Drawing.Color.White;
            this.gvu_dv_btn2.Image = global::ATBM.Properties.Resources.sua;
            this.gvu_dv_btn2.Location = new System.Drawing.Point(1063, 36);
            this.gvu_dv_btn2.Name = "gvu_dv_btn2";
            this.gvu_dv_btn2.Size = new System.Drawing.Size(160, 42);
            this.gvu_dv_btn2.TabIndex = 5;
            this.gvu_dv_btn2.Text = "Cập nhật";
            this.gvu_dv_btn2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.gvu_dv_btn2.UseVisualStyleBackColor = false;
            this.gvu_dv_btn2.Click += new System.EventHandler(this.gvu_dv_btn2_Click);
            // 
            // gvu_dv_dataGridView1
            // 
            this.gvu_dv_dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.gvu_dv_dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvu_dv_dataGridView1.Location = new System.Drawing.Point(23, 90);
            this.gvu_dv_dataGridView1.Name = "gvu_dv_dataGridView1";
            this.gvu_dv_dataGridView1.RowHeadersWidth = 51;
            this.gvu_dv_dataGridView1.RowTemplate.Height = 24;
            this.gvu_dv_dataGridView1.Size = new System.Drawing.Size(1200, 450);
            this.gvu_dv_dataGridView1.TabIndex = 5;
            this.gvu_dv_dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gvu_dv_dataGridView1_CellClick);
            // 
            // GVU_DV
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1282, 603);
            this.Controls.Add(this.gvu_dv_dataGridView1);
            this.Controls.Add(this.gvu_dv_btn2);
            this.Controls.Add(this.gvu_dv_btn1);
            this.Controls.Add(this.gvu_dv_textBox1);
            this.Controls.Add(this.gvu_dv_label1);
            this.Name = "GVU_DV";
            this.Text = "GVU_DV";
            this.Load += new System.EventHandler(this.GVU_DV_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gvu_dv_dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label gvu_dv_label1;
        private System.Windows.Forms.TextBox gvu_dv_textBox1;
        private System.Windows.Forms.Button gvu_dv_btn1;
        private System.Windows.Forms.Button gvu_dv_btn2;
        private System.Windows.Forms.DataGridView gvu_dv_dataGridView1;
    }
}