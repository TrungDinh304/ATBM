﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace ATBM
{

    public partial class Login_PH2 : Form
    {

        public Login_PH2()
        {
            InitializeComponent();
        }

        string textBox_Username_string = " # Tên đăng nhập.";
        string textBox_Password_string = " # Mật khẩu.";

        private void Login_PH2_Load(object sender, EventArgs e)
        {
            this.textBox_username.Text = textBox_Username_string;
            this.textBox_password.Text = textBox_Password_string;
        }

        private void textBox_username_Leave(object sender, EventArgs e)
        {
            if (textBox_username.Text == "")
            {
                textBox_username.Text = textBox_Username_string;
                // đổi màu chữ thành màu xám
                textBox_username.ForeColor = Color.Gray;
            }
        }

        private void textBox_password_Click(object sender, EventArgs e)
        {
            if (textBox_password.Text == textBox_Password_string)
            {
                textBox_password.Text = "";
                // đổi màu chữ thành màu đen
                textBox_password.ForeColor = Color.Black;
                textBox_password.PasswordChar = '*';
            }
        }

        private void textBox_password_Leave(object sender, EventArgs e)
        {
            if (textBox_password.Text == "")
            {
                textBox_password.Text = textBox_Password_string;
                // đổi màu chữ thành màu xám
                textBox_password.ForeColor = Color.Gray;
                textBox_password.PasswordChar = '\0';
            }
        }

        private void textBox_username_Click(object sender, EventArgs e)
        {
            if (textBox_username.Text == textBox_Username_string)
            {
                textBox_username.Text = "";
                // đổi màu chữ thành màu đen
                textBox_username.ForeColor = Color.Black;
            }
        }

        private void button_Login_Click(object sender, EventArgs e)
        {
            string current_username = textBox_username.Text;
            string current_password = textBox_password.Text;

            if (IsSysAdmin(current_username, current_password))
            {
                SysAdminLogin(current_username, current_password);
            }
            else
            {
                UserLogin(current_username, current_password);
            }
        }

        private bool IsSysAdmin(string username, string password)
        {
            return username.ToLower().Contains("admin");
        }

        private void SysAdminLogin(string username, string password)
        {
            try
            {
                ConnectionStr.connectionStr = $@"DATA SOURCE=localhost:1521/xe;PERSIST SECURITY INFO=True;USER ID={username};PASSWORD={password}";
                this.Hide();
                user newuser = new user();
                newuser.Show();
                newuser.FormClosed += (s, args) => this.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Đăng nhập thấy bại!");
            }
        }

        private void UserLogin(string username, string password)
        {
            ConnectionStr.connectionStr = $@"DATA SOURCE=localhost:1521/xe;PERSIST SECURITY INFO=True;USER ID={username};PASSWORD={password}";

            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                }

                Login_information.username = username;
                Login_information.password = password;

                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Đăng nhập thất bại. Vui lòng kiểm tra lại thông tin đăng nhập.\n" + ex.Message);
                textBox_password.Text = "";
                return;
            }

            if (username.ToLower().Contains("sv"))
            {
                HandleStudentLogin();
            }
            else
            {
                HandleNonStudentLogin();
            }

            Form nextForm = GetNextForm(Login_information.role);
            if (nextForm != null)
            {
                nextForm.Show();
                nextForm.FormClosed += (s, args) => this.Show();
            }
            else
            {
                MessageBox.Show("Role không hợp lệ.");
            }

            ResetTextBoxes();
        }

        private void HandleStudentLogin()
        {
            string query_sv = "select * from admin1.X_SINHVIEN";

            try
            {
                DataSet dssv = ExecuteQuery(query_sv);
                if (dssv.Tables[0].Rows.Count > 0)
                {
                    DataRow row = dssv.Tables[0].Rows[0];
                    Login_information.role = "Sinh vien";
                    Login_information.fullname = row["hoten"].ToString();
                    Login_information.Donvi = "";
                }
                else
                {
                    throw new Exception("Người dùng không tồn tại.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi kiểm tra sự tồn tại của người dùng: " + ex.Message);
            }
        }

        private void HandleNonStudentLogin()
        {
            string query = "select hoten, vaitro, madv from admin1.UV_THONGTINCANHAN_NS";

            try
            {
                DataSet dsns = ExecuteQuery(query);
                if (dsns.Tables[0].Rows.Count > 0)
                {
                    DataRow row = dsns.Tables[0].Rows[0];
                    Login_information.role = row["vaitro"].ToString();
                    Login_information.fullname = row["hoten"].ToString();
                    Login_information.Donvi = row["madv"].ToString();
                }
                else
                {
                    throw new Exception("Người dùng không tồn tại.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi kiểm tra sự tồn tại của người dùng: " + ex.Message);
            }
        }

        private DataSet ExecuteQuery(string query)
        {
            DataSet ds = new DataSet();
            using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
            {
                connection.Open();
                OracleDataAdapter adapter = new OracleDataAdapter(query, connection);
                adapter.Fill(ds);
            }
            return ds;
        }

        private Form GetNextForm(string role)
        {
            switch (role)
            {
                case "Giang vien":
                    return new Form_Home_GV();
                case "Truong don vi":
                    return new Form_TruongDV();
                case "Nhan vien co ban":
                    return new Form_NVCB();
                case "Sinh vien":
                    return new Form_SV();
                case "Truong khoa":
                    return new Form_TrgKhoa();
                case "Giao vu":
                    return new GVU();
                default:
                    return null;
            }
        }

        private void ResetTextBoxes()
        {
            textBox_username.Text = string.Empty;
            textBox_password.Text = string.Empty;
        }


        private void textBox_password_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button_Login_Click(sender, e);
            }
        }

        private void textBox_password_TextChanged(object sender, EventArgs e)
        {
            if (textBox_password.Text != textBox_Password_string)
            {
                textBox_password.PasswordChar = '*';
                textBox_password.ForeColor = Color.Black;
            }
            if (textBox_password.Text == textBox_Password_string)
            {
                textBox_password.PasswordChar = '\0';
                textBox_password.ForeColor = Color.Gray;
            }
        }

        private void textBox_username_TextChanged(object sender, EventArgs e)
        {
            if (textBox_username.Text != textBox_Username_string)
            {
                textBox_username.ForeColor = Color.Black;
            }
            if (textBox_username.Text == textBox_Username_string)
            {
                textBox_username.ForeColor = Color.Gray;
            }
        }
    }
}