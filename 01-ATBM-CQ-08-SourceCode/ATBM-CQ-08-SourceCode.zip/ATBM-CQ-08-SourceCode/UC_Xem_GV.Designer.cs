﻿namespace ATBM
{
    partial class UC_Xem_GV
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_Xem_GV));
            this.dataGridView_DS_GiangVien = new System.Windows.Forms.DataGridView();
            this.label_LopHoc = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button_TimKiem_GiangVien = new System.Windows.Forms.Button();
            this.textBox_TimKiem_GiangVien = new System.Windows.Forms.TextBox();
            this.label_TimKiem = new System.Windows.Forms.Label();
            this.XemPC = new System.Windows.Forms.DataGridViewButtonColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_DS_GiangVien)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView_DS_GiangVien
            // 
            this.dataGridView_DS_GiangVien.AllowUserToAddRows = false;
            this.dataGridView_DS_GiangVien.AllowUserToDeleteRows = false;
            this.dataGridView_DS_GiangVien.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_DS_GiangVien.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView_DS_GiangVien.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_DS_GiangVien.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_DS_GiangVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_DS_GiangVien.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.XemPC});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_DS_GiangVien.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_DS_GiangVien.Location = new System.Drawing.Point(39, 127);
            this.dataGridView_DS_GiangVien.Name = "dataGridView_DS_GiangVien";
            this.dataGridView_DS_GiangVien.ReadOnly = true;
            this.dataGridView_DS_GiangVien.RowHeadersWidth = 51;
            this.dataGridView_DS_GiangVien.RowTemplate.Height = 24;
            this.dataGridView_DS_GiangVien.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_DS_GiangVien.Size = new System.Drawing.Size(1134, 566);
            this.dataGridView_DS_GiangVien.TabIndex = 3;
            this.dataGridView_DS_GiangVien.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_DS_GiangVien_CellContentClick);
            // 
            // label_LopHoc
            // 
            this.label_LopHoc.AutoSize = true;
            this.label_LopHoc.Font = new System.Drawing.Font("Arial", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_LopHoc.Location = new System.Drawing.Point(32, 28);
            this.label_LopHoc.Name = "label_LopHoc";
            this.label_LopHoc.Size = new System.Drawing.Size(209, 38);
            this.label_LopHoc.TabIndex = 2;
            this.label_LopHoc.Text = "GIẢNG VIÊN";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(175, 80);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(35, 30);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 24;
            this.pictureBox1.TabStop = false;
            // 
            // button_TimKiem_GiangVien
            // 
            this.button_TimKiem_GiangVien.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_TimKiem_GiangVien.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_TimKiem_GiangVien.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_TimKiem_GiangVien.Font = new System.Drawing.Font("Arial", 10F);
            this.button_TimKiem_GiangVien.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_TimKiem_GiangVien.Location = new System.Drawing.Point(1029, 78);
            this.button_TimKiem_GiangVien.Name = "button_TimKiem_GiangVien";
            this.button_TimKiem_GiangVien.Size = new System.Drawing.Size(144, 30);
            this.button_TimKiem_GiangVien.TabIndex = 23;
            this.button_TimKiem_GiangVien.Text = "Tìm Kiếm";
            this.button_TimKiem_GiangVien.UseVisualStyleBackColor = false;
            this.button_TimKiem_GiangVien.Click += new System.EventHandler(this.button_TimKiem_GiangVien_Click);
            // 
            // textBox_TimKiem_GiangVien
            // 
            this.textBox_TimKiem_GiangVien.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_TimKiem_GiangVien.Font = new System.Drawing.Font("Arial", 14F);
            this.textBox_TimKiem_GiangVien.Location = new System.Drawing.Point(216, 80);
            this.textBox_TimKiem_GiangVien.Name = "textBox_TimKiem_GiangVien";
            this.textBox_TimKiem_GiangVien.Size = new System.Drawing.Size(818, 27);
            this.textBox_TimKiem_GiangVien.TabIndex = 22;
            // 
            // label_TimKiem
            // 
            this.label_TimKiem.AutoSize = true;
            this.label_TimKiem.Font = new System.Drawing.Font("Arial", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_TimKiem.Location = new System.Drawing.Point(36, 78);
            this.label_TimKiem.Name = "label_TimKiem";
            this.label_TimKiem.Size = new System.Drawing.Size(144, 28);
            this.label_TimKiem.TabIndex = 21;
            this.label_TimKiem.Text = "Giảng Viên:";
            // 
            // XemPC
            // 
            this.XemPC.HeaderText = "Xem Phân Công";
            this.XemPC.MinimumWidth = 6;
            this.XemPC.Name = "XemPC";
            this.XemPC.ReadOnly = true;
            this.XemPC.Text = "Xem";
            this.XemPC.UseColumnTextForButtonValue = true;
            // 
            // UC_Xem_GV
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button_TimKiem_GiangVien);
            this.Controls.Add(this.textBox_TimKiem_GiangVien);
            this.Controls.Add(this.label_TimKiem);
            this.Controls.Add(this.dataGridView_DS_GiangVien);
            this.Controls.Add(this.label_LopHoc);
            this.Name = "UC_Xem_GV";
            this.Size = new System.Drawing.Size(1204, 720);
            this.Load += new System.EventHandler(this.UC_Xem_GV_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_DS_GiangVien)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView_DS_GiangVien;
        private System.Windows.Forms.Label label_LopHoc;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button_TimKiem_GiangVien;
        private System.Windows.Forms.TextBox textBox_TimKiem_GiangVien;
        private System.Windows.Forms.Label label_TimKiem;
        private System.Windows.Forms.DataGridViewButtonColumn XemPC;
    }
}
