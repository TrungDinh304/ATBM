﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using ATBM;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using NPOI.SS.Formula.Functions;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using System.Globalization;


namespace ATBM
{
    public partial class Form_Insert_NS : Form
    {

        private UC_Xem_NS _form1;
        public Form_Insert_NS (UC_Xem_NS form1)
        {
            InitializeComponent();
            cmbGioi.Font = new Font("Arial", 11f); // Example font: Arial, size 11
            cmbDV.Font = new Font("Arial", 11f); // Example font: Arial, size 11
            cmbVT.Font = new Font("Arial", 11f); // Example font: Arial, size 11
        }



        private void button_close_Click(object sender, EventArgs e)
        {
            this.FindForm().Close();
        }

        private void button_update_Click(object sender, EventArgs e)
        {
            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();

                    OracleCommand cmd = new OracleCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "admin1.USP_INSERT_NHANSU";
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Input parameters
                    try
                    {
                        cmd.Parameters.Add("P_HOTEN", OracleDbType.Varchar2).Value = textBox_hoten.Text.ToString();
                        cmd.Parameters.Add("P_PHAI", OracleDbType.Varchar2).Value = cmbGioi.Text.ToString();

                        DateTime ngaysinh;
                        if (DateTime.TryParseExact(textBox_ngaysinh.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out ngaysinh))
                        {
                            cmd.Parameters.Add("P_NGSINH", OracleDbType.Date).Value = ngaysinh;
                        }
                        else
                        {
                            throw new FormatException("Invalid date format for Ngay Sinh. Please enter date in dd/MM/yyyy format.");
                        }

                        int phucap;
                        if (int.TryParse(textBox_phucap.Text, out phucap))
                        {
                            cmd.Parameters.Add("P_PHUCAP", OracleDbType.Int32).Value = phucap;
                        }
                        else
                        {
                            throw new FormatException("Invalid integer format for Phu Cap.");
                        }

                        cmd.Parameters.Add("P_DT", OracleDbType.Varchar2).Value = textBox_sodienthoai.Text.ToString();
                        cmd.Parameters.Add("P_VAITRO", OracleDbType.Varchar2).Value = cmbVT.Text.ToString();
                        cmd.Parameters.Add("P_MADV", OracleDbType.Varchar2).Value = cmbDV.Text.ToString();
                    }
                    catch (FormatException ex)
                    {
                        // Handle the format exception (e.g., log the error, show a message to the user)
                        MessageBox.Show("Input format error: " + ex.Message);
                    }
                    catch (Exception ex)
                    {
                        // Handle any other exceptions
                        MessageBox.Show("An error occurred: " + ex.Message);
                    }


                    // Output parameters
                    OracleParameter errorCodeParam = new OracleParameter("P_ERROR_CODE", OracleDbType.Int32);
                    errorCodeParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(errorCodeParam);

                    OracleParameter errorMsgParam = new OracleParameter("P_ERROR_MSG", OracleDbType.Varchar2, 1000);
                    errorMsgParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(errorMsgParam);

                    // Execute the command
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Thêm thành công!");
                    // reload thông tin hiển thị trên form

                    connection.Close();
                    //_form1.RefreshContent();  // Call the refresh method on Form1

                    this.FindForm().Close();
                }
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có
                MessageBox.Show("ERR: " + ex.Message);
            }
        }

        private void textBox_hoten_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form_Insert_NS_Load(object sender, EventArgs e)
        {
            // Them option cho cmbGioi
            cmbGioi.Items.Add("Nữ");
            cmbGioi.Items.Add("Nam");

            // Them option cho cmbVT
            cmbVT.Items.Add("Nhan vien co ban");
            cmbVT.Items.Add("Giang vien");
            cmbVT.Items.Add("Giao vu");
            cmbVT.Items.Add("Truong don vi");
            cmbVT.Items.Add("Truong khoa");

            // Them option cho cmbDV
            try
            {
                using (OracleConnection con = new OracleConnection(ConnectionStr.connectionStr))
                {
                    con.Open();
                    OracleDataAdapter adp = new OracleDataAdapter("SELECT MADV FROM ADMIN1.X_DONVI", con);
                    DataTable dt = new DataTable();
                    adp.Fill(dt);

                    cmbDV.DataSource = dt;
                    cmbDV.DisplayMember = "MADV";
                    cmbDV.ValueMember = "MADV";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading tables: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
