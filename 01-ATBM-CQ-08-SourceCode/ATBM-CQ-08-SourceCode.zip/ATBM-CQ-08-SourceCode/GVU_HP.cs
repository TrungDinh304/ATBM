﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;


namespace ATBM
{
    public partial class GVU_HP : Form
    {
        public GVU_HP()
        {
            InitializeComponent();

        }


        private void GVU_HP_Load(object sender, EventArgs e)
        {
            LoadUserData();
        }



        /*Hiển thị tất cả sinh viên */
        DataSet getAllUser()
        {
            DataSet data = new DataSet();
            String query = "select * from admin1.X_HOCPHAN";
            using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
            {
                connection.Open();
                OracleDataAdapter adapter = new OracleDataAdapter(query, connection);
                adapter.Fill(data);

                connection.Close();
            }
            return data;
        }

        private void LoadUserData()
        {
            // Call getAllUser to retrieve data
            DataSet userData = getAllUser();

            // Check if there is at least one table in the DataSet
            if (userData.Tables.Count > 0)
            {
                // Set the DataGridView DataSource to the first table in the DataSet
                gvu_hp_dataGridView1.DataSource = userData.Tables[0];
            }
        }


        private DataSet GetDataFromDatabase(string query)
        {
            DataSet data = new DataSet();
            using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
            {
                connection.Open();
                OracleDataAdapter adapter = new OracleDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }



        // tìm kiếm học phần theo mã và tên
        private void gvu_hp_textBox1_TextChanged(object sender, EventArgs e)
        {
            // Lấy dữ liệu từ TextBox
            string username = gvu_hp_textBox1.Text.Trim();

            // Kiểm tra xem người dùng đã nhập tên người dùng hay chưa
            if (!string.IsNullOrEmpty(username))
            {
                // Gọi phương thức để lấy dữ liệu từ cơ sở dữ liệu và hiển thị trên DataGridView
                LoadUserData(username);
            }
            else
            {
                LoadUserData();
            }
        }

        private void LoadUserData(string input)
        {
            // Format font column headers
            this.gvu_hp_dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft Sans Serif", 12, FontStyle.Bold);

            // Format font row
            foreach (DataGridViewRow row in gvu_hp_dataGridView1.Rows)
            {
                row.DefaultCellStyle.Font = new Font("Microsoft Sans Serif", 12, FontStyle.Regular);
            }

            // Tạo câu truy vấn dựa trên username
            string query = $"SELECT * FROM admin1.X_HOCPHAN WHERE MAHP LIKE '%{input}%' OR TENHP LIKE '%{input}%'";

            // Gọi phương thức để thực hiện truy vấn
            DataSet userData = GetDataFromDatabase(query);

            // Hiển thị dữ liệu trên DataGridView
            gvu_hp_dataGridView1.DataSource = userData.Tables[0];

        }


        private void insertHocPhan(string MAHP, string TENHP, int SOTC, int STLT, int STTH, int SOSVTD, string MADV)
        {
            string query = $"INSERT INTO admin1.X_HOCPHAN VALUES('{MAHP}','{TENHP}', {SOTC}, {STLT}, {STTH}, {SOSVTD}, '{MADV}')";

            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    using (OracleCommand alterSessionCommand = new OracleCommand(query, connection))
                    {
                        alterSessionCommand.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Học phần đã được thêm thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void updateHocPhan(string OLDMAHP, string MAHP, string TENHP, int SOTC, int STLT, int STTH, int SOSVTD, string MADV)
        {
            string query = $"UPDATE admin1.X_HOCPHAN SET MAHP='{MAHP}',TENHP='{TENHP}', SOTC={SOTC}, STLT={STLT},STTH= {STTH}, SOSVTD={SOSVTD}, MADV='{MADV}' WHERE MAHP='{OLDMAHP}'";

            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    using (OracleCommand alterSessionCommand = new OracleCommand(query, connection))
                    {
                        alterSessionCommand.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Học phần đã được cập nhật thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void deleteHocPhan(string MAHP)
        {
            string query = $"DELETE admin1.X_HOCPHAN WHERE MAHP='{MAHP}'";

            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    using (OracleCommand alterSessionCommand = new OracleCommand(query, connection))
                    {
                        alterSessionCommand.ExecuteNonQuery();
                    }
                }
                LoadUserData();
                MessageBox.Show("Học phần đã được xóa thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private int indexOfContent;
        private string OLDMAHP;
        private void gvu_hp_dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            indexOfContent = e.RowIndex;
            DataGridViewRow t = gvu_hp_dataGridView1.Rows[indexOfContent];
            //textBox1.Text = t.Cells[0].Value.ToString();
            OLDMAHP = t.Cells[0].Value.ToString();
        }

        private void gvu_hp_btn1_Click(object sender, EventArgs e)
        {
            DataGridViewRow t = gvu_hp_dataGridView1.Rows[indexOfContent];
            string MAHP = t.Cells[0].Value.ToString();
            string TENHP = t.Cells[1].Value.ToString();
            int SOTC = Convert.ToInt32(t.Cells[2].Value.ToString());
            int STLT = Convert.ToInt32(t.Cells[3].Value.ToString());
            int STTH = Convert.ToInt32(t.Cells[4].Value.ToString());
            int SOSVTD = Convert.ToInt32(t.Cells[5].Value.ToString());
            string MADV = t.Cells[6].Value.ToString();
            insertHocPhan(MAHP, TENHP, SOTC, STLT, STTH, SOSVTD, MADV);
        }

        private void gvu_hp_btn2_Click(object sender, EventArgs e)
        {
            DataGridViewRow t = gvu_hp_dataGridView1.Rows[indexOfContent];
            string MAHP = t.Cells[0].Value.ToString();
            string TENHP = t.Cells[1].Value.ToString();
            int SOTC = Convert.ToInt32(t.Cells[2].Value.ToString());
            int STLT = Convert.ToInt32(t.Cells[3].Value.ToString());
            int STTH = Convert.ToInt32(t.Cells[4].Value.ToString());
            int SOSVTD = Convert.ToInt32(t.Cells[5].Value.ToString());
            string MADV = t.Cells[6].Value.ToString();
            updateHocPhan(OLDMAHP, MAHP, TENHP, SOTC, STLT, STTH, SOSVTD, MADV);
        }

        private void gvu_hp_btn3_Click(object sender, EventArgs e)
        {
            DataGridViewRow t = gvu_hp_dataGridView1.Rows[indexOfContent];
            string MAHP = t.Cells[0].Value.ToString();
            deleteHocPhan(MAHP);
        }
    }
}
