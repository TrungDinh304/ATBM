﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;


namespace ATBM
{
    public partial class UC_TruyVan_DonVi_GV : UserControl
    {
        public UC_TruyVan_DonVi_GV()
        {
            InitializeComponent();
        }

        private void UC_TruyVan_DonVi_GV_Load(object sender, EventArgs e)
        {
            string query = "select * from admin1.x_donvi";
            DataSet ds = new DataSet();
            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    OracleDataAdapter adapter = new OracleDataAdapter(query, connection);
                    adapter.Fill(ds);
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: " + ex.Message);
            }
            dataGridView_DonVi.DataSource = ds.Tables[0];
            
            dataGridView_DonVi.Columns[0].HeaderText = "Mã Đơn Vị";
            dataGridView_DonVi.Columns[1].HeaderText = "Tên Đơn Vị";
            dataGridView_DonVi.Columns[2].HeaderText = "Trưởng Đơn Vị";
        }

        private void button_TimKiem_DonVi_Click(object sender, EventArgs e)
        {
            string TenDV = textBox_TimKiem_DonVi.Text;
            string query = $"select * from admin1.x_donvi where tendv like \'%{TenDV}%\' or madv like '%{TenDV}%'";
            DataSet ds = new DataSet();
            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    OracleDataAdapter adapter = new OracleDataAdapter(query, connection);
                    adapter.Fill(ds);
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: " + ex.Message);
            }
            dataGridView_DonVi.DataSource = ds.Tables[0];
            dataGridView_DonVi.Columns[0].HeaderText = "Mã Đơn Vị";
            dataGridView_DonVi.Columns[1].HeaderText = "Tên Đơn Vị";
            dataGridView_DonVi.Columns[2].HeaderText = "Trưởng Đơn Vị";
        }
    }
}
