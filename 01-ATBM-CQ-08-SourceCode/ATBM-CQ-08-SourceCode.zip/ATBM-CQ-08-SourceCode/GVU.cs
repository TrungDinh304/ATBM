﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace ATBM
{
    public partial class GVU : Form
    {
        public GVU()
        {
            InitializeComponent();
        }

        private void GVU_Load(object sender, EventArgs e)
        {

            gvu_label1.Text = "Xin chào " + Login_information.fullname;
            gvu_label_ten.Text = Login_information.fullname;

        }

        private Form currentFormChild;

        private void OpenChildForm(Form chilForm)
        {
            if (currentFormChild != null)
            {
                currentFormChild.Close();
            }
            currentFormChild = chilForm;
            chilForm.TopLevel = false;
            chilForm.FormBorderStyle = FormBorderStyle.None;
            chilForm.Dock = DockStyle.Fill;
            gvu_panel_body.Controls.Add(chilForm);
            gvu_panel_body.Tag = chilForm;
            chilForm.BringToFront();
            chilForm.Show();
        }

        private void gvu_button_sv_Click(object sender, EventArgs e)
        {
            //this.gvu_button_sv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(84)))), ((int)(((byte)(16)))), ((int)(((byte)(58)))));
            this.gvu_button_sv.BackColor = System.Drawing.Color.FromArgb(51, 84, 16, 58); // 51 is about 20% opaque
            this.gvu_button_dv.BackColor = System.Drawing.Color.White;
            this.gvu_button_hp.BackColor = System.Drawing.Color.White;
            this.gvu_button_khm.BackColor = System.Drawing.Color.White;
            this.gvu_button_pc.BackColor = System.Drawing.Color.White;
            this.gvu_button_dkhp.BackColor = System.Drawing.Color.White;
            OpenChildForm(new GVU_SV());
            gvu_label1.Text = gvu_button_sv.Text;
        }
        private void gvu_button_dv_Click(object sender, EventArgs e)
        {
            this.gvu_button_sv.BackColor = System.Drawing.Color.White;
            this.gvu_button_dv.BackColor = System.Drawing.Color.FromArgb(51, 84, 16, 58); // 51 is about 20% opaque;
            this.gvu_button_hp.BackColor = System.Drawing.Color.White;
            this.gvu_button_khm.BackColor = System.Drawing.Color.White;
            this.gvu_button_pc.BackColor = System.Drawing.Color.White;
            this.gvu_button_dkhp.BackColor = System.Drawing.Color.White;
            OpenChildForm(new GVU_DV());
            gvu_label1.Text = gvu_button_dv.Text;
        }

        private void gvu_button_hp_Click(object sender, EventArgs e)
        {
            this.gvu_button_sv.BackColor = System.Drawing.Color.White;
            this.gvu_button_dv.BackColor = System.Drawing.Color.White;
            this.gvu_button_hp.BackColor = System.Drawing.Color.FromArgb(51, 84, 16, 58); // 51 is about 20% opaque;
            this.gvu_button_khm.BackColor = System.Drawing.Color.White;
            this.gvu_button_pc.BackColor = System.Drawing.Color.White;
            this.gvu_button_dkhp.BackColor = System.Drawing.Color.White;
            OpenChildForm(new GVU_HP());
            gvu_label1.Text = gvu_button_hp.Text;
        }

        private void gvu_pictureBox_Click(object sender, EventArgs e)
        {
            if (currentFormChild != null)
            {
                currentFormChild.Close();
            }
            gvu_label1.Text = "Xin chào " + Login_information.fullname;
        }

        private void gvu_button_khm_Click(object sender, EventArgs e)
        {
            this.gvu_button_sv.BackColor = System.Drawing.Color.White;
            this.gvu_button_dv.BackColor = System.Drawing.Color.White;
            this.gvu_button_hp.BackColor = System.Drawing.Color.White;
            this.gvu_button_khm.BackColor = System.Drawing.Color.FromArgb(51, 84, 16, 58); // 51 is about 20% opaque;
            this.gvu_button_pc.BackColor = System.Drawing.Color.White;
            this.gvu_button_dkhp.BackColor = System.Drawing.Color.White;
            OpenChildForm(new GVU_KHM());
            gvu_label1.Text = gvu_button_khm.Text;
        }

        private void gvu_button_pc_Click(object sender, EventArgs e)
        {
            this.gvu_button_sv.BackColor = System.Drawing.Color.White;
            this.gvu_button_dv.BackColor = System.Drawing.Color.White;
            this.gvu_button_hp.BackColor = System.Drawing.Color.White;
            this.gvu_button_khm.BackColor = System.Drawing.Color.White;
            this.gvu_button_pc.BackColor = System.Drawing.Color.FromArgb(51, 84, 16, 58); // 51 is about 20% opaque;
            this.gvu_button_dkhp.BackColor = System.Drawing.Color.White;
            OpenChildForm(new GVU_PC());
            gvu_label1.Text = gvu_button_pc.Text;
        }

        private void gvu_button_dkhp_Click(object sender, EventArgs e)
        {
            this.gvu_button_sv.BackColor = System.Drawing.Color.White;
            this.gvu_button_dv.BackColor = System.Drawing.Color.White;
            this.gvu_button_hp.BackColor = System.Drawing.Color.White;
            this.gvu_button_khm.BackColor = System.Drawing.Color.White;
            this.gvu_button_pc.BackColor = System.Drawing.Color.White;
            this.gvu_button_dkhp.BackColor = System.Drawing.Color.FromArgb(51, 84, 16, 58); // 51 is about 20% opaque;
            OpenChildForm(new GVU_DKHP());
            gvu_label1.Text = gvu_button_dkhp.Text;
        }

        private void gvu_button_canhan_Click(object sender, EventArgs e)
        {
            OpenChildForm(new GVU_CN());
            gvu_label1.Text = "Thông tin cá nhân";
        }

        private void gvu_panel_top_Paint(object sender, PaintEventArgs e)
        {

        }

        private void gvu_label_ten_Click(object sender, EventArgs e)
        {
            OpenChildForm(new GVU_CN());
            gvu_label1.Text = "Thông tin cá nhân";
        }

        private void gvu_label_chucvu_Click(object sender, EventArgs e)
        {
            OpenChildForm(new GVU_CN());
            gvu_label1.Text = "Thông tin cá nhân";
        }

        private void gvu_button_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void gvu_label6_Click(object sender, EventArgs e)
        {

        }

        private void gvu_label5_Click(object sender, EventArgs e)
        {

        }
    }
}
