﻿namespace ATBM
{
    partial class UC_DangKyHocPhan_SV
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridView_DKHP = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label_HocKy = new System.Windows.Forms.Label();
            this.comboBox_HocKy_DangKy = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView_KHM = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_DKHP)).BeginInit();
            this.contextMenuStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_KHM)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView_DKHP
            // 
            this.dataGridView_DKHP.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView_DKHP.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_DKHP.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_DKHP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_DKHP.ContextMenuStrip = this.contextMenuStrip2;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 10F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_DKHP.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_DKHP.Location = new System.Drawing.Point(39, 116);
            this.dataGridView_DKHP.Name = "dataGridView_DKHP";
            this.dataGridView_DKHP.ReadOnly = true;
            this.dataGridView_DKHP.RowHeadersWidth = 51;
            this.dataGridView_DKHP.RowTemplate.Height = 24;
            this.dataGridView_DKHP.Size = new System.Drawing.Size(1134, 276);
            this.dataGridView_DKHP.TabIndex = 35;
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem2});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(105, 28);
            // 
            // ToolStripMenuItem2
            // 
            this.ToolStripMenuItem2.Name = "ToolStripMenuItem2";
            this.ToolStripMenuItem2.Size = new System.Drawing.Size(104, 24);
            this.ToolStripMenuItem2.Text = "Xoá";
            this.ToolStripMenuItem2.Click += new System.EventHandler(this.ToolStripMenuItem2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(32, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 38);
            this.label1.TabIndex = 33;
            this.label1.Text = "ĐĂNG KÝ";
            // 
            // label_HocKy
            // 
            this.label_HocKy.AutoSize = true;
            this.label_HocKy.Font = new System.Drawing.Font("Arial", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_HocKy.Location = new System.Drawing.Point(34, 83);
            this.label_HocKy.Name = "label_HocKy";
            this.label_HocKy.Size = new System.Drawing.Size(107, 28);
            this.label_HocKy.TabIndex = 36;
            this.label_HocKy.Text = "Học Kỳ: ";
            // 
            // comboBox_HocKy_DangKy
            // 
            this.comboBox_HocKy_DangKy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.comboBox_HocKy_DangKy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_HocKy_DangKy.Font = new System.Drawing.Font("Arial", 10F);
            this.comboBox_HocKy_DangKy.FormattingEnabled = true;
            this.comboBox_HocKy_DangKy.Location = new System.Drawing.Point(164, 83);
            this.comboBox_HocKy_DangKy.Name = "comboBox_HocKy_DangKy";
            this.comboBox_HocKy_DangKy.Size = new System.Drawing.Size(1009, 27);
            this.comboBox_HocKy_DangKy.TabIndex = 37;
            this.comboBox_HocKy_DangKy.SelectedIndexChanged += new System.EventHandler(this.comboBox_HocKy_DangKy_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.Location = new System.Drawing.Point(34, 417);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(430, 28);
            this.label2.TabIndex = 38;
            this.label2.Text = "Danh sách học phần có thể đăng ký: ";
            // 
            // dataGridView_KHM
            // 
            this.dataGridView_KHM.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView_KHM.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_KHM.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView_KHM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_KHM.ContextMenuStrip = this.contextMenuStrip1;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Arial", 10F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_KHM.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView_KHM.Location = new System.Drawing.Point(39, 448);
            this.dataGridView_KHM.Name = "dataGridView_KHM";
            this.dataGridView_KHM.ReadOnly = true;
            this.dataGridView_KHM.RowHeadersWidth = 51;
            this.dataGridView_KHM.RowTemplate.Height = 24;
            this.dataGridView_KHM.Size = new System.Drawing.Size(1134, 256);
            this.dataGridView_KHM.TabIndex = 39;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(116, 28);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(115, 24);
            this.toolStripMenuItem1.Text = "Thêm";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // UC_DangKyHocPhan_SV
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.dataGridView_KHM);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label_HocKy);
            this.Controls.Add(this.comboBox_HocKy_DangKy);
            this.Controls.Add(this.dataGridView_DKHP);
            this.Controls.Add(this.label1);
            this.Name = "UC_DangKyHocPhan_SV";
            this.Size = new System.Drawing.Size(1204, 720);
            this.Load += new System.EventHandler(this.UC_DangKyHocPhan_SV_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_DKHP)).EndInit();
            this.contextMenuStrip2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_KHM)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridView_DKHP;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label_HocKy;
        private System.Windows.Forms.ComboBox comboBox_HocKy_DangKy;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView_KHM;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem2;
    }
}
