﻿namespace ATBM
{
    partial class GVU_DKHP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gvu_dkhp_label1 = new System.Windows.Forms.Label();
            this.gvu_dkhp_textBox1 = new System.Windows.Forms.TextBox();
            this.gvu_dkhp_btn1 = new System.Windows.Forms.Button();
            this.gvu_dkhp_btn3 = new System.Windows.Forms.Button();
            this.gvu_dkhp_dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.gvu_dkhp_dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // gvu_dkhp_label1
            // 
            this.gvu_dkhp_label1.AutoSize = true;
            this.gvu_dkhp_label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_dkhp_label1.Location = new System.Drawing.Point(18, 45);
            this.gvu_dkhp_label1.Name = "gvu_dkhp_label1";
            this.gvu_dkhp_label1.Size = new System.Drawing.Size(164, 25);
            this.gvu_dkhp_label1.TabIndex = 0;
            this.gvu_dkhp_label1.Text = "Học phần đăng kí";
            // 
            // gvu_dkhp_textBox1
            // 
            this.gvu_dkhp_textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_dkhp_textBox1.Location = new System.Drawing.Point(197, 42);
            this.gvu_dkhp_textBox1.Name = "gvu_dkhp_textBox1";
            this.gvu_dkhp_textBox1.Size = new System.Drawing.Size(400, 30);
            this.gvu_dkhp_textBox1.TabIndex = 1;
            this.gvu_dkhp_textBox1.TextChanged += new System.EventHandler(this.gvu_dkhp_textBox1_TextChanged);
            // 
            // gvu_dkhp_btn1
            // 
            this.gvu_dkhp_btn1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(89)))), ((int)(((byte)(47)))));
            this.gvu_dkhp_btn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_dkhp_btn1.ForeColor = System.Drawing.Color.White;
            this.gvu_dkhp_btn1.Image = global::ATBM.Properties.Resources.them;
            this.gvu_dkhp_btn1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.gvu_dkhp_btn1.Location = new System.Drawing.Point(950, 36);
            this.gvu_dkhp_btn1.Margin = new System.Windows.Forms.Padding(0);
            this.gvu_dkhp_btn1.Name = "gvu_dkhp_btn1";
            this.gvu_dkhp_btn1.Size = new System.Drawing.Size(130, 42);
            this.gvu_dkhp_btn1.TabIndex = 2;
            this.gvu_dkhp_btn1.Text = "Thêm";
            this.gvu_dkhp_btn1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.gvu_dkhp_btn1.UseVisualStyleBackColor = false;
            this.gvu_dkhp_btn1.Click += new System.EventHandler(this.gvu_dkhp_btn1_Click);
            // 
            // gvu_dkhp_btn3
            // 
            this.gvu_dkhp_btn3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.gvu_dkhp_btn3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvu_dkhp_btn3.ForeColor = System.Drawing.Color.White;
            this.gvu_dkhp_btn3.Image = global::ATBM.Properties.Resources.xoa;
            this.gvu_dkhp_btn3.Location = new System.Drawing.Point(1103, 36);
            this.gvu_dkhp_btn3.Name = "gvu_dkhp_btn3";
            this.gvu_dkhp_btn3.Size = new System.Drawing.Size(120, 42);
            this.gvu_dkhp_btn3.TabIndex = 6;
            this.gvu_dkhp_btn3.Text = "Xóa";
            this.gvu_dkhp_btn3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.gvu_dkhp_btn3.UseVisualStyleBackColor = false;
            this.gvu_dkhp_btn3.Click += new System.EventHandler(this.gvu_dkhp_btn3_Click);
            // 
            // gvu_dkhp_dataGridView1
            // 
            this.gvu_dkhp_dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.gvu_dkhp_dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvu_dkhp_dataGridView1.Location = new System.Drawing.Point(23, 90);
            this.gvu_dkhp_dataGridView1.Name = "gvu_dkhp_dataGridView1";
            this.gvu_dkhp_dataGridView1.RowHeadersWidth = 51;
            this.gvu_dkhp_dataGridView1.RowTemplate.Height = 24;
            this.gvu_dkhp_dataGridView1.Size = new System.Drawing.Size(1200, 450);
            this.gvu_dkhp_dataGridView1.TabIndex = 5;
            this.gvu_dkhp_dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gvu_dkhp_dataGridView1_CellClick);
            // 
            // GVU_DKHP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1282, 603);
            this.Controls.Add(this.gvu_dkhp_dataGridView1);
            this.Controls.Add(this.gvu_dkhp_btn3);
            this.Controls.Add(this.gvu_dkhp_btn1);
            this.Controls.Add(this.gvu_dkhp_textBox1);
            this.Controls.Add(this.gvu_dkhp_label1);
            this.Name = "GVU_DKHP";
            this.Text = "GVU_DKHP";
            this.Load += new System.EventHandler(this.GVU_DKHP_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gvu_dkhp_dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label gvu_dkhp_label1;
        private System.Windows.Forms.TextBox gvu_dkhp_textBox1;
        private System.Windows.Forms.Button gvu_dkhp_btn1;
        private System.Windows.Forms.Button gvu_dkhp_btn3;
        private System.Windows.Forms.DataGridView gvu_dkhp_dataGridView1;
    }
}