﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ATBM.UC_DanhSachLopHoc;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using ATBM;


namespace ATBM
{
    public partial class f_modify_PC_TK : Form
    {
        public f_modify_PC_TK()
        {
            InitializeComponent();
            if (UC_PhanCong_TK.loai_tuychinh == "update")
            {
                textBox_magv.Text = UC_PhanCong_TK.Selected_PC.Magv;
                textBox_mahp.Text = UC_PhanCong_TK.Selected_PC.Mahp;
                textBox_hk.Text = UC_PhanCong_TK.Selected_PC.Hocki;
                textBox_nam.Text = UC_PhanCong_TK.Selected_PC.Nam;
                textBox_mact.Text = UC_PhanCong_TK.Selected_PC.Mact;

                button_insert.Visible = false;
                button_insert.Enabled = false;

            }
            else if (UC_PhanCong_TK.loai_tuychinh == "insert")
            {
                textBox_magv.Text = "";

                textBox_mahp.Text = "";
                textBox_mahp.Enabled = true;

                textBox_hk.Text = "";
                textBox_hk.Enabled = true;

                textBox_nam.Text = "";
                textBox_nam.Enabled = true;

                textBox_mact.Text = "";
                textBox_mact.Enabled = true;
                label_modify.Text = "THÊM PHÂN CÔNG";
                button_delete.Visible = false;
                button_delete.Enabled = false;
                button_update.Visible = false;
                button_update.Enabled = false;
            }

        }

        private void f_modify_PC_TK_Load(object sender, EventArgs e)
        {
            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();

                    OracleCommand cmd = new OracleCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "admin1.USP_SELECT_KHM_TDV";
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Input parameters
                    cmd.Parameters.Add("p_madv", OracleDbType.Varchar2).Value = Login_information.Donvi;


                    // Output parameters
                    OracleParameter refcur = new OracleParameter("p_result", OracleDbType.RefCursor);
                    refcur.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(refcur);

                    OracleParameter errorCodeParam = new OracleParameter("p_error_code", OracleDbType.Int32);
                    errorCodeParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(errorCodeParam);

                    OracleParameter errorMsgParam = new OracleParameter("p_error_msg", OracleDbType.Varchar2, 1000);
                    errorMsgParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(errorMsgParam);

                    OracleDataReader dr = cmd.ExecuteReader();

                    DataTable dataTable = new DataTable();
                    dataTable.Load(dr);
                    dataGridView_ds_KHM.DataSource = dataTable;
                    connection.Close();

                }
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có
                MessageBox.Show("ERROR: " + ex.Message);
            }
        }

        private void button_update_Click(object sender, EventArgs e)
        {
            string old_magv = UC_PhanCong_TK.Selected_PC.Magv;
            string magv = textBox_magv.Text;
            string mahp = textBox_mahp.Text;
            string hk = textBox_hk.Text;
            string nam = textBox_nam.Text;
            string mact = textBox_mact.Text;

            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();

                    OracleCommand cmd = new OracleCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "admin1.USP_UPDATE_PHANCONG_GV";
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Input parameters
                    cmd.Parameters.Add("p_old_magv", OracleDbType.Varchar2).Value = old_magv;
                    cmd.Parameters.Add("p_magv", OracleDbType.Varchar2).Value = magv;
                    cmd.Parameters.Add("p_mahp", OracleDbType.Varchar2).Value = mahp;
                    cmd.Parameters.Add("p_hk", OracleDbType.Int32).Value = hk;
                    cmd.Parameters.Add("p_nam", OracleDbType.Int32).Value = nam;
                    cmd.Parameters.Add("p_mact", OracleDbType.Varchar2).Value = mact;


                    OracleParameter errorCodeParam = new OracleParameter("p_error_code", OracleDbType.Int32);
                    errorCodeParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(errorCodeParam);

                    OracleParameter errorMsgParam = new OracleParameter("p_error_msg", OracleDbType.Varchar2, 1000);
                    errorMsgParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(errorMsgParam);

                    OracleDataReader dr = cmd.ExecuteReader();

                    DataTable dataTable = new DataTable();
                    dataTable.Load(dr);
                    dataGridView_ds_KHM.DataSource = dataTable;
                    connection.Close();

                    // get output due to check error or secussed
                    OracleDecimal errorCodeDecimal = (OracleDecimal)cmd.Parameters["p_error_code"].Value;
                    int errorCode = errorCodeDecimal.IsNull ? 0 : errorCodeDecimal.ToInt32();

                    OracleString errorMsgOracleString = (OracleString)cmd.Parameters["p_error_msg"].Value;
                    string errorMsg = errorMsgOracleString.IsNull ? "" : errorMsgOracleString.Value;

                    // check error or secussed
                    if (errorCode != 0)
                    {
                        MessageBox.Show($"Error {errorCode}: {errorMsg}");
                        return;
                    }
                    else
                    {
                        MessageBox.Show("Cập nhật phân công thành công");
                    }
                }
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có
                MessageBox.Show("ERROR: " + ex.Message);
            }
            f_modify_PC_TK_Load(sender, e);
        }

        private void button_insert_Click(object sender, EventArgs e)
        {
            if (textBox_magv.Text == "" || textBox_mahp.Text == "" || textBox_hk.Text == "" || textBox_nam.Text == "" || textBox_mact.Text == "")
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin");
                return;
            }
            string magv = textBox_magv.Text;
            string mahp = textBox_mahp.Text;
            string hk = textBox_hk.Text;
            string nam = textBox_nam.Text;
            string mact = textBox_mact.Text;

            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();

                    OracleCommand cmd = new OracleCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "admin1.USP_INSERT_PHANCONG1";
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Input parameters
                    cmd.Parameters.Add("p_magv", OracleDbType.Varchar2).Value = magv;
                    cmd.Parameters.Add("p_mahp", OracleDbType.Varchar2).Value = mahp;
                    cmd.Parameters.Add("p_hk", OracleDbType.Int32).Value = hk;
                    cmd.Parameters.Add("p_nam", OracleDbType.Int32).Value = nam;
                    cmd.Parameters.Add("p_mact", OracleDbType.Varchar2).Value = mact;


                    OracleParameter errorCodeParam = new OracleParameter("p_error_code", OracleDbType.Int32);
                    errorCodeParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(errorCodeParam);

                    OracleParameter errorMsgParam = new OracleParameter("p_error_msg", OracleDbType.Varchar2, 1000);
                    errorMsgParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(errorMsgParam);

                    cmd.ExecuteNonQuery();
                    connection.Close();


                    // get output due to check error or secussed
                    OracleDecimal errorCodeDecimal = (OracleDecimal)cmd.Parameters["p_error_code"].Value;
                    int errorCode = errorCodeDecimal.IsNull ? 0 : errorCodeDecimal.ToInt32();

                    OracleString errorMsgOracleString = (OracleString)cmd.Parameters["p_error_msg"].Value;
                    string errorMsg = errorMsgOracleString.IsNull ? "" : errorMsgOracleString.Value;

                    // check error or secussed
                    if (errorCode != 0)
                    {
                        MessageBox.Show($"Error {errorCode}: {errorMsg}");
                        return;
                    }
                    else
                    {
                        MessageBox.Show("Thêm phân công thành công.");
                    }

                }
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có
                MessageBox.Show("ERROR: " + ex.Message);
            }
            f_modify_PC_TK_Load(sender, e);

        }

        private void dataGridView_ds_KHM_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (UC_PhanCong_TK.loai_tuychinh == "update")
                return;
            if (UC_PhanCong_TK.loai_tuychinh == "insert" && dataGridView_ds_KHM.Rows[e.RowIndex].Cells[4].Value.ToString() != "")
            {
                MessageBox.Show("Lớp này đã được phân công rồi.");
                return;
            }

            textBox_mahp.Text = dataGridView_ds_KHM.Rows[e.RowIndex].Cells[0].Value.ToString();
            textBox_hk.Text = dataGridView_ds_KHM.Rows[e.RowIndex].Cells[1].Value.ToString();
            textBox_nam.Text = dataGridView_ds_KHM.Rows[e.RowIndex].Cells[2].Value.ToString();
            textBox_mact.Text = dataGridView_ds_KHM.Rows[e.RowIndex].Cells[3].Value.ToString();
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            if (textBox_magv.Text == "" || textBox_mahp.Text == "" || textBox_hk.Text == "" || textBox_nam.Text == "" || textBox_mact.Text == "")
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin");
                return;
            }
            string magv = textBox_magv.Text;
            string mahp = textBox_mahp.Text;
            string hk = textBox_hk.Text;
            string nam = textBox_nam.Text;
            string mact = textBox_mact.Text;

            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();

                    OracleCommand cmd = new OracleCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "admin1.USP_DELETE_PHANCONG1";
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Input parameters
                    cmd.Parameters.Add("p_magv", OracleDbType.Varchar2).Value = magv;
                    cmd.Parameters.Add("p_mahp", OracleDbType.Varchar2).Value = mahp;
                    cmd.Parameters.Add("p_hk", OracleDbType.Int32).Value = hk;
                    cmd.Parameters.Add("p_nam", OracleDbType.Int32).Value = nam;
                    cmd.Parameters.Add("p_mact", OracleDbType.Varchar2).Value = mact;


                    OracleParameter errorCodeParam = new OracleParameter("p_error_code", OracleDbType.Int32);
                    errorCodeParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(errorCodeParam);

                    OracleParameter errorMsgParam = new OracleParameter("p_error_msg", OracleDbType.Varchar2, 1000);
                    errorMsgParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(errorMsgParam);

                    cmd.ExecuteNonQuery();
                    connection.Close();


                    // get output due to check error or secussed
                    OracleDecimal errorCodeDecimal = (OracleDecimal)cmd.Parameters["p_error_code"].Value;
                    int errorCode = errorCodeDecimal.IsNull ? 0 : errorCodeDecimal.ToInt32();

                    OracleString errorMsgOracleString = (OracleString)cmd.Parameters["p_error_msg"].Value;
                    string errorMsg = errorMsgOracleString.IsNull ? "" : errorMsgOracleString.Value;

                    // check error or secussed
                    if (errorCode != 0)
                    {
                        MessageBox.Show($"Error {errorCode}: {errorMsg}");
                        return;
                    }
                    else
                    {
                        MessageBox.Show("Xóa thành công.");
                    }

                }
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có
                MessageBox.Show("ERROR: " + ex.Message);
            }
            f_modify_PC_TK_Load(sender, e);
        }

        private void dataGridView_ds_KHM_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox_mact_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox_nam_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox_hk_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox_mahp_TextChanged(object sender, EventArgs e)
        {

        }

        private void label_magv_Click(object sender, EventArgs e)
        {

        }

        private void textBox_magv_TextChanged(object sender, EventArgs e)
        {

        }
    }
}