﻿using NPOI.SS.Formula.Functions;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;

namespace ATBM
{
    public partial class UC_LopHoc : UserControl
    {
        public UC_LopHoc()
        {
            InitializeComponent();
        }

        private void dataGridView_LopHoc_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            UC_DanhSachLopHoc uc = new UC_DanhSachLopHoc();
            // tạo biến tạm lưu trữ form hiện tại
            Form_Home_GV form = (Form_Home_GV)this.FindForm();
            form.open_UC_control(uc);

        }

        private void fill_data_toComboBox()
        {
            // tạo câu lệnh truy vấn
            string query_statement = "select distinct HK ||'-'||nam as hocki from admin1.V_PhanCong_GV";
            // kết nối với database oracle 
            DataSet ds_hocky = new DataSet();
            try
            {
                // Mở kết nối đến cơ sở dữ liệu
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    //lấy dữ liệu từ bảng
                    OracleDataAdapter adapter = new OracleDataAdapter(query_statement, connection);
                    adapter.Fill(ds_hocky);
                    // đóng kết nối
                    connection.Close();

                }
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có
                MessageBox.Show("Lỗi hệ thống: " + ex.Message);
            }
            // rót dữ liệu vào combobox
            comboBox_HocKy_LH.DataSource = ds_hocky.Tables[0];
            comboBox_HocKy_LH.DisplayMember = "hocki";
            comboBox_HocKy_LH.ValueMember = "hocki";

        }

        private void UC_LopHoc_Load(object sender, EventArgs e)
        {
            /*string query_statement = "select * from admin1.V_PhanCong_GV";
            // kết nối với database oracle 
            DataSet ds_phancong = new DataSet();
            try
            {
                // Mở kết nối đến cơ sở dữ liệu
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    //lấy dữ liệu từ bảng
                    OracleDataAdapter adapter = new OracleDataAdapter(query_statement, connection);
                    adapter.Fill(ds_phancong);
                    // đóng kết nối
                    connection.Close();

                }
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có
                MessageBox.Show("Lỗi khi kiểm tra sự tồn tại của người dùng: " + ex.Message);
            }
            // rót dữ liệu vào datagridview
            dataGridView_LopHoc.DataSource = ds_phancong.Tables[0];*/
            fill_data_toComboBox();
            this.comboBox_HocKy_LH_SelectedIndexChanged(sender, e);
        }

        public static string current_LopHoc;


        private void dataGridView_LopHoc_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            // lấy dòng hiện tại
            DataGridViewRow row = dataGridView_LopHoc.Rows[e.RowIndex];
            // lấy mã lớp học
            current_LopHoc = row.Cells[1].Value.ToString();
            current_LopHoc += "-" + row.Cells[2].Value.ToString();
            current_LopHoc += "-" + row.Cells[3].Value.ToString();
            current_LopHoc += "-" + row.Cells[4].Value.ToString();

            if (e.RowIndex >= 0 && e.RowIndex < dataGridView_LopHoc.Rows.Count)
            {
                // Get the parent form
                var parentForm = this.FindForm();

                // Check if the parent form is of the expected type
                if (parentForm is ATBM.Form_Home_GV homeGVForm)
                {
                    // Perform the necessary operations with homeGVForm
                    Form_Home_GV form = (Form_Home_GV)this.FindForm();
                    UC_DanhSachLopHoc uc = new UC_DanhSachLopHoc();
                    form.open_UC_control(uc);
                }
                else if (parentForm is ATBM.Form_TruongDV truongDVForm)
                {
                    // Perform the necessary operations with trgKhoaForm
                    Form_TruongDV form = (Form_TruongDV)this.FindForm();
                    UC_DanhSachLopHoc uc = new UC_DanhSachLopHoc();
                    form.open_UC_control(uc);
                }
                else if (parentForm is ATBM.Form_TrgKhoa trgKhoaForm)
                {
                    // Perform the necessary operations with trgKhoaForm
                    Form_TrgKhoa form = (Form_TrgKhoa)this.FindForm();
                    UC_DanhSachLopHoc uc = new UC_DanhSachLopHoc();
                    form.open_UC_control(uc);
                }
                else
                {
                    // Handle the case where the parent form is neither of the expected types
                    MessageBox.Show("Unexpected form type.");
                }
            }
        }

        private void comboBox_HocKy_LH_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox_HocKy_LH.Items.Count == 0)
            {
                return;
            }
            if (comboBox_HocKy_LH.SelectedValue.ToString() == "System.Data.DataRowView")
            {
                return;
            }

            // lấy giá trị của combobox
            string hocky = comboBox_HocKy_LH.SelectedValue.ToString();
            // tách chuỗi HOCKI để lấy thược tính HK và NAM
            string[] HOCKI = hocky.Split('-');
            string HK = HOCKI[0];
            string NAM = HOCKI[1];

            // tạo câu lệnh truy vấn
            string query_statement = "select * from admin1.V_PhanCong_GV where HK = '" + HK + "' and NAM = '" + NAM + "'";

            DataSet ds_phancong = new DataSet();

            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    //lấy dữ liệu từ bảng
                    OracleDataAdapter adapter = new OracleDataAdapter(query_statement, connection);
                    adapter.Fill(ds_phancong);
                    // đóng kết nối
                    connection.Close();
                    // rót dữ liệu vào datagridview
                    dataGridView_LopHoc.DataSource = ds_phancong.Tables[0];
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: " + ex.Message);
            }
            this.dataGridView_LopHoc.Columns["Option"].DisplayIndex = dataGridView_LopHoc.ColumnCount - 1;
            this.dataGridView_LopHoc.Columns["Option"].Selected = true;

        }
    }
}