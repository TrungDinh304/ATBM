﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;


namespace ATBM
{
    public partial class GVU_PC : Form
    {
        public GVU_PC()
        {
            InitializeComponent();

        }


        private void GVU_PC_Load(object sender, EventArgs e)
        {
            LoadUserData();
        }



        /*Hiển thị tất cả sinh viên */
        DataSet getAllUser()
        {
            DataSet data = new DataSet();
            String query = "select * from admin1.X_PHANCONG";
            using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
            {
                connection.Open();
                OracleDataAdapter adapter = new OracleDataAdapter(query, connection);
                adapter.Fill(data);

                connection.Close();
            }
            return data;
        }

        private void LoadUserData()
        {
            // Call getAllUser to retrieve data
            DataSet userData = getAllUser();

            // Check if there is at least one table in the DataSet
            if (userData.Tables.Count > 0)
            {
                // Set the DataGridView DataSource to the first table in the DataSet
                gvu_pc_dataGridView1.DataSource = userData.Tables[0];
            }
        }


        private DataSet GetDataFromDatabase(string query)
        {
            DataSet data = new DataSet();
            using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
            {
                connection.Open();
                OracleDataAdapter adapter = new OracleDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }



        // tìm kiếm học phần đăng kí theo mã
        private void gvu_pc_textBox1_TextChanged(object sender, EventArgs e)
        {
            // Lấy dữ liệu từ TextBox
            string username = gvu_pc_textBox1.Text.Trim();

            // Kiểm tra xem người dùng đã nhập tên người dùng hay chưa
            if (!string.IsNullOrEmpty(username))
            {
                // Gọi phương thức để lấy dữ liệu từ cơ sở dữ liệu và hiển thị trên DataGridView
                LoadUserData(username);
            }
            else
            {
                LoadUserData();
            }
        }

        private void LoadUserData(string input)
        {
            // Format font column headers
            this.gvu_pc_dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft Sans Serif", 12, FontStyle.Bold);

            // Format font row
            foreach (DataGridViewRow row in gvu_pc_dataGridView1.Rows)
            {
                row.DefaultCellStyle.Font = new Font("Microsoft Sans Serif", 12, FontStyle.Regular);
            }

            // Tạo câu truy vấn dựa trên username
            string query = $"SELECT * FROM admin1.X_PHANCONG WHERE MAGV LIKE '%{input}%' OR MAHP LIKE '%{input}%'";

            // Gọi phương thức để thực hiện truy vấn
            DataSet userData = GetDataFromDatabase(query);

            // Hiển thị dữ liệu trên DataGridView
            gvu_pc_dataGridView1.DataSource = userData.Tables[0];

        }


        private void updatePhanCong(string MAGV2, string MAGV, string MAHP, string HK, string NAM, string MACT)
        {
            try
            {
                // Kết nối đến cơ sở dữ liệu Oracle
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    // Mở kết nối
                    connection.Open();
                    // Tạo một đối tượng Command để gọi procedure
                    using (OracleCommand cmd = new OracleCommand("admin1.USP_UPDATE_PHANCONG", connection))
                    {
                        // Xác định kiểu command là StoredProcedure
                        cmd.CommandType = CommandType.StoredProcedure;

                        // Thêm các tham số vào command
                        cmd.Parameters.Add("PMAGV2", OracleDbType.Varchar2).Value = MAGV2;
                        cmd.Parameters.Add("PMAGV", OracleDbType.Varchar2).Value = MAGV;
                        cmd.Parameters.Add("PMAHP", OracleDbType.Varchar2).Value = MAHP;
                        cmd.Parameters.Add("PHK", OracleDbType.Char).Value = HK;
                        cmd.Parameters.Add("PNAM", OracleDbType.Char).Value = NAM;
                        cmd.Parameters.Add("PMACT", OracleDbType.Varchar2).Value = MACT;

                        OracleParameter errorCodeParam = new OracleParameter("p_error_code", OracleDbType.Int32);
                        errorCodeParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(errorCodeParam);
                        // Thực thi command
                        cmd.ExecuteNonQuery();

                        OracleDecimal errorCodeDecimal = (OracleDecimal)cmd.Parameters["p_error_code"].Value;
                        int errorCode = errorCodeDecimal.ToInt32();

                        // check error or secussed
                        if (errorCode != 0)
                        {
                            MessageBox.Show("Cập nhật thất bại");
                            return;
                        }
                        else
                        {
                            MessageBox.Show("Cập nhật thành công!");
                        }
                        
                    }
                }

                LoadUserData();
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có
                MessageBox.Show("Error granting privilege: " + ex.Message);
            }
        }

        

        private int indexOfContent;
        private string MAGV;
        private void gvu_pc_dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            indexOfContent = e.RowIndex;
            DataGridViewRow t = gvu_pc_dataGridView1.Rows[indexOfContent];
            //textBox1.Text = t.Cells[0].Value.ToString();
            MAGV = t.Cells[0].Value.ToString();
        }

        private void gvu_pc_btn1_Click(object sender, EventArgs e)
        {
            DataGridViewRow t = gvu_pc_dataGridView1.Rows[indexOfContent];
            
            string MAGV2 = t.Cells[0].Value.ToString();
            string MAHP = t.Cells[1].Value.ToString();
            string HK = t.Cells[2].Value.ToString();
            string NAM = t.Cells[3].Value.ToString();
            string MACT = t.Cells[4].Value.ToString();
            //MessageBox.Show(MAPC+ MAGV+ MAHP+ HK+ NAM+ MACT);
            updatePhanCong(MAGV2, MAGV, MAHP, HK, NAM, MACT);
        }

        
    }
}
