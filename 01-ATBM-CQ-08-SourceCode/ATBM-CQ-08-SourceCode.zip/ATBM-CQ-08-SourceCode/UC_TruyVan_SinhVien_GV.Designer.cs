﻿namespace ATBM
{
    partial class UC_TruyVan_SinhVien_GV
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_TruyVan_SinhVien_GV));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label_SinhVien = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button_TimKiem_SinhVien = new System.Windows.Forms.Button();
            this.textBox_TimKiem_SinhVien = new System.Windows.Forms.TextBox();
            this.dataGridView_SinhVien = new System.Windows.Forms.DataGridView();
            this.label_TimKiem = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_SinhVien)).BeginInit();
            this.SuspendLayout();
            // 
            // label_SinhVien
            // 
            this.label_SinhVien.AutoSize = true;
            this.label_SinhVien.Font = new System.Drawing.Font("Arial", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_SinhVien.Location = new System.Drawing.Point(36, 41);
            this.label_SinhVien.Name = "label_SinhVien";
            this.label_SinhVien.Size = new System.Drawing.Size(219, 46);
            this.label_SinhVien.TabIndex = 11;
            this.label_SinhVien.Text = "SINH VIÊN";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(184, 111);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(39, 38);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            // 
            // button_TimKiem_SinhVien
            // 
            this.button_TimKiem_SinhVien.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_TimKiem_SinhVien.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_TimKiem_SinhVien.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_TimKiem_SinhVien.Font = new System.Drawing.Font("Arial", 10F);
            this.button_TimKiem_SinhVien.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_TimKiem_SinhVien.Location = new System.Drawing.Point(1158, 109);
            this.button_TimKiem_SinhVien.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_TimKiem_SinhVien.Name = "button_TimKiem_SinhVien";
            this.button_TimKiem_SinhVien.Size = new System.Drawing.Size(162, 38);
            this.button_TimKiem_SinhVien.TabIndex = 19;
            this.button_TimKiem_SinhVien.Text = "Tìm Kiếm";
            this.button_TimKiem_SinhVien.UseVisualStyleBackColor = false;
            this.button_TimKiem_SinhVien.Click += new System.EventHandler(this.button_TimKiem_SinhVien_Click);
            // 
            // textBox_TimKiem_SinhVien
            // 
            this.textBox_TimKiem_SinhVien.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_TimKiem_SinhVien.Font = new System.Drawing.Font("Arial", 14F);
            this.textBox_TimKiem_SinhVien.Location = new System.Drawing.Point(231, 111);
            this.textBox_TimKiem_SinhVien.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox_TimKiem_SinhVien.Name = "textBox_TimKiem_SinhVien";
            this.textBox_TimKiem_SinhVien.Size = new System.Drawing.Size(934, 33);
            this.textBox_TimKiem_SinhVien.TabIndex = 18;
            // 
            // dataGridView_SinhVien
            // 
            this.dataGridView_SinhVien.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_SinhVien.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView_SinhVien.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_SinhVien.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_SinhVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 10F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_SinhVien.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_SinhVien.Location = new System.Drawing.Point(44, 156);
            this.dataGridView_SinhVien.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridView_SinhVien.Name = "dataGridView_SinhVien";
            this.dataGridView_SinhVien.RowHeadersWidth = 51;
            this.dataGridView_SinhVien.RowTemplate.Height = 24;
            this.dataGridView_SinhVien.Size = new System.Drawing.Size(1276, 708);
            this.dataGridView_SinhVien.TabIndex = 17;
            // 
            // label_TimKiem
            // 
            this.label_TimKiem.AutoSize = true;
            this.label_TimKiem.Font = new System.Drawing.Font("Arial", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_TimKiem.Location = new System.Drawing.Point(38, 111);
            this.label_TimKiem.Name = "label_TimKiem";
            this.label_TimKiem.Size = new System.Drawing.Size(159, 35);
            this.label_TimKiem.TabIndex = 16;
            this.label_TimKiem.Text = "Sinh Viên: ";
            // 
            // UC_TruyVan_SinhVien_GV
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button_TimKiem_SinhVien);
            this.Controls.Add(this.textBox_TimKiem_SinhVien);
            this.Controls.Add(this.dataGridView_SinhVien);
            this.Controls.Add(this.label_TimKiem);
            this.Controls.Add(this.label_SinhVien);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "UC_TruyVan_SinhVien_GV";
            this.Size = new System.Drawing.Size(1354, 900);
            this.Load += new System.EventHandler(this.UC_TruyVan_SinhVien_GV_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_SinhVien)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_SinhVien;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button_TimKiem_SinhVien;
        private System.Windows.Forms.TextBox textBox_TimKiem_SinhVien;
        private System.Windows.Forms.DataGridView dataGridView_SinhVien;
        private System.Windows.Forms.Label label_TimKiem;
    }
}
