﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;


namespace ATBM
{
    public partial class GVU_SV : Form
    {
        public GVU_SV()
        {
            InitializeComponent();

        }


        private void GVU_SV_Load(object sender, EventArgs e)
        {
            LoadUserData();
        }

        

        /*Hiển thị tất cả sinh viên */
        DataSet getAllUser()
        {
            DataSet data = new DataSet();
            String query = "select * from admin1.X_SINHVIEN";
            using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
            {
                connection.Open();
                OracleDataAdapter adapter = new OracleDataAdapter(query, connection);
                adapter.Fill(data);

                connection.Close();
            }
            return data;
        }

        private void LoadUserData()
        {
            // Call getAllUser to retrieve data
            DataSet userData = getAllUser();

            // Check if there is at least one table in the DataSet
            if (userData.Tables.Count > 0)
            {
                // Set the DataGridView DataSource to the first table in the DataSet
                gvu_sv_dataGridView1.DataSource = userData.Tables[0];
            }
        }


        private DataSet GetDataFromDatabase(string query)
        {
            DataSet data = new DataSet();
            using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
            {
                connection.Open();
                OracleDataAdapter adapter = new OracleDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }


       
        // tìm kiếm sinh viên theo họ tên hoặc mã
        private void gvu_sv_textBox1_TextChanged(object sender, EventArgs e)
        {
            // Lấy dữ liệu từ TextBox
            string username = gvu_sv_textBox1.Text.Trim();

            // Kiểm tra xem người dùng đã nhập tên người dùng hay chưa
            if (!string.IsNullOrEmpty(username))
            {
                // Gọi phương thức để lấy dữ liệu từ cơ sở dữ liệu và hiển thị trên DataGridView
                LoadUserData(username);
            }
            else
            {
                LoadUserData();
            }
        }

        private void LoadUserData(string input)
        {
            // Format font column headers
            this.gvu_sv_dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft Sans Serif", 12, FontStyle.Bold);

            // Format font row
            foreach (DataGridViewRow row in gvu_sv_dataGridView1.Rows)
            {
                row.DefaultCellStyle.Font = new Font("Microsoft Sans Serif", 12, FontStyle.Regular);
            }

            // Tạo câu truy vấn dựa trên username
            string query = $"SELECT * FROM admin1.X_SINHVIEN WHERE HOTEN LIKE '%{input}%' OR MASV LIKE '%{input}%'";

            // Gọi phương thức để thực hiện truy vấn
            DataSet userData = GetDataFromDatabase(query);

            // Hiển thị dữ liệu trên DataGridView
            gvu_sv_dataGridView1.DataSource = userData.Tables[0];

        }


        private void insertSinhVien(string MASV, string HOTEN, string PHAI, string NGSINH, string DCHI, string DT, string MACT, string MANGANH, int SOTCTL, float DTBTL)
        {
            string query = $"INSERT INTO admin1.X_SINHVIEN VALUES('{MASV}','{HOTEN}', '{PHAI}', TO_DATE('{NGSINH}','DD/MM/YYYY'), '{DCHI}', '{DT}', '{MACT}', '{MANGANH}', {SOTCTL}, {DTBTL})";

            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    using (OracleCommand alterSessionCommand = new OracleCommand(query, connection))
                    {
                        alterSessionCommand.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Sinh viên đã được thêm thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message );
            }
        }

        private void updateSinhVien(string OLDMASV, string MASV, string HOTEN, string PHAI, string NGSINH, string DCHI, string DT, string MACT, string MANGANH, int SOTCTL, float DTBTL)
        {
            string query = $"UPDATE admin1.X_SINHVIEN SET MASV='{MASV}',HOTEN='{HOTEN}', PHAI='{PHAI}',NGSINH= TO_DATE('{NGSINH}','DD/MM/YYYY'), DCHI='{DCHI}',DT= '{DT}', MACT='{MACT}', MANGANH='{MANGANH}',SOTCTL= {SOTCTL}, DTBTL={DTBTL} WHERE MASV='{OLDMASV}'";

            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    using (OracleCommand alterSessionCommand = new OracleCommand(query, connection))
                    {
                        alterSessionCommand.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Sinh viên đã được cập nhật thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message );
            }
        }

        private void deleteSinhVien(string MASV)
        {
            string query = $"DELETE admin1.X_SINHVIEN WHERE MASV='{MASV}'";

            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    using (OracleCommand alterSessionCommand = new OracleCommand(query, connection))
                    {
                        alterSessionCommand.ExecuteNonQuery();
                    }
                }
                LoadUserData();
                MessageBox.Show("Sinh viên đã được xóa thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private int indexOfContent;
        private string OLDMASV;
        private void gvu_sv_dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            indexOfContent = e.RowIndex;
            DataGridViewRow t = gvu_sv_dataGridView1.Rows[indexOfContent];
            //textBox1.Text = t.Cells[0].Value.ToString();
            OLDMASV = t.Cells[0].Value.ToString();
        }

        private void gvu_sv_btn1_Click(object sender, EventArgs e)
        {
            DataGridViewRow t = gvu_sv_dataGridView1.Rows[indexOfContent];
            string MASV = t.Cells[0].Value.ToString();
            string HOTEN = t.Cells[1].Value.ToString();
            string PHAI = t.Cells[2].Value.ToString();
            string NGSINH = t.Cells[3].Value.ToString();
            NGSINH = NGSINH.Substring(0, 9);
            string DCHI = t.Cells[4].Value.ToString();
            string DT = t.Cells[5].Value.ToString();
            string MACT = t.Cells[6].Value.ToString();
            string MANGANH = t.Cells[7].Value.ToString();
            int SOTCTL = Convert.ToInt32(t.Cells[8].Value.ToString());
            float DTBTL = float.Parse(t.Cells[9].Value.ToString());
            insertSinhVien( MASV,HOTEN,PHAI,NGSINH,DCHI,DT,MACT,MANGANH,SOTCTL,DTBTL);
        }

        private void gvu_sv_btn2_Click(object sender, EventArgs e)
        {
            DataGridViewRow t = gvu_sv_dataGridView1.Rows[indexOfContent];
            string MASV = t.Cells[0].Value.ToString();
            string HOTEN = t.Cells[1].Value.ToString();
            string PHAI = t.Cells[2].Value.ToString();
            string NGSINH = t.Cells[3].Value.ToString();
            NGSINH = NGSINH.Substring(0, 9);
            string DCHI = t.Cells[4].Value.ToString();
            string DT = t.Cells[5].Value.ToString();
            string MACT = t.Cells[6].Value.ToString();
            string MANGANH = t.Cells[7].Value.ToString();
            int SOTCTL = Convert.ToInt32(t.Cells[8].Value.ToString());
            float DTBTL = float.Parse(t.Cells[9].Value.ToString());
            updateSinhVien(OLDMASV, MASV, HOTEN, PHAI, NGSINH, DCHI, DT, MACT, MANGANH, SOTCTL, DTBTL);
        }

        private void gvu_sv_btn3_Click(object sender, EventArgs e)
        {
            DataGridViewRow t = gvu_sv_dataGridView1.Rows[indexOfContent];
            string MASV = t.Cells[0].Value.ToString();
            deleteSinhVien(MASV);
        }
    }
}
