﻿namespace ATBM
{
    partial class UC_TruyVan_DonVi_GV
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_TruyVan_DonVi_GV));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label_DonVi = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button_TimKiem_DonVi = new System.Windows.Forms.Button();
            this.textBox_TimKiem_DonVi = new System.Windows.Forms.TextBox();
            this.dataGridView_DonVi = new System.Windows.Forms.DataGridView();
            this.label_TimKiem = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_DonVi)).BeginInit();
            this.SuspendLayout();
            // 
            // label_DonVi
            // 
            this.label_DonVi.AutoSize = true;
            this.label_DonVi.Font = new System.Drawing.Font("Arial", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_DonVi.Location = new System.Drawing.Point(36, 41);
            this.label_DonVi.Name = "label_DonVi";
            this.label_DonVi.Size = new System.Drawing.Size(160, 46);
            this.label_DonVi.TabIndex = 11;
            this.label_DonVi.Text = "ĐƠN VỊ";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(184, 112);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(39, 38);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            // 
            // button_TimKiem_DonVi
            // 
            this.button_TimKiem_DonVi.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_TimKiem_DonVi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_TimKiem_DonVi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_TimKiem_DonVi.Font = new System.Drawing.Font("Arial", 10F);
            this.button_TimKiem_DonVi.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_TimKiem_DonVi.Location = new System.Drawing.Point(1158, 110);
            this.button_TimKiem_DonVi.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_TimKiem_DonVi.Name = "button_TimKiem_DonVi";
            this.button_TimKiem_DonVi.Size = new System.Drawing.Size(162, 38);
            this.button_TimKiem_DonVi.TabIndex = 19;
            this.button_TimKiem_DonVi.Text = "Tìm Kiếm";
            this.button_TimKiem_DonVi.UseVisualStyleBackColor = false;
            this.button_TimKiem_DonVi.Click += new System.EventHandler(this.button_TimKiem_DonVi_Click);
            // 
            // textBox_TimKiem_DonVi
            // 
            this.textBox_TimKiem_DonVi.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_TimKiem_DonVi.Font = new System.Drawing.Font("Arial", 14F);
            this.textBox_TimKiem_DonVi.Location = new System.Drawing.Point(231, 112);
            this.textBox_TimKiem_DonVi.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox_TimKiem_DonVi.Name = "textBox_TimKiem_DonVi";
            this.textBox_TimKiem_DonVi.Size = new System.Drawing.Size(934, 33);
            this.textBox_TimKiem_DonVi.TabIndex = 18;
            // 
            // dataGridView_DonVi
            // 
            this.dataGridView_DonVi.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_DonVi.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView_DonVi.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_DonVi.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_DonVi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 10F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_DonVi.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_DonVi.Location = new System.Drawing.Point(44, 161);
            this.dataGridView_DonVi.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridView_DonVi.MultiSelect = false;
            this.dataGridView_DonVi.Name = "dataGridView_DonVi";
            this.dataGridView_DonVi.ReadOnly = true;
            this.dataGridView_DonVi.RowHeadersWidth = 51;
            this.dataGridView_DonVi.RowTemplate.Height = 24;
            this.dataGridView_DonVi.Size = new System.Drawing.Size(1276, 708);
            this.dataGridView_DonVi.TabIndex = 17;
            // 
            // label_TimKiem
            // 
            this.label_TimKiem.AutoSize = true;
            this.label_TimKiem.Font = new System.Drawing.Font("Arial", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_TimKiem.Location = new System.Drawing.Point(38, 111);
            this.label_TimKiem.Name = "label_TimKiem";
            this.label_TimKiem.Size = new System.Drawing.Size(116, 35);
            this.label_TimKiem.TabIndex = 16;
            this.label_TimKiem.Text = "Đơn Vị:";
            // 
            // UC_TruyVan_DonVi_GV
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button_TimKiem_DonVi);
            this.Controls.Add(this.textBox_TimKiem_DonVi);
            this.Controls.Add(this.dataGridView_DonVi);
            this.Controls.Add(this.label_TimKiem);
            this.Controls.Add(this.label_DonVi);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "UC_TruyVan_DonVi_GV";
            this.Size = new System.Drawing.Size(1354, 900);
            this.Load += new System.EventHandler(this.UC_TruyVan_DonVi_GV_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_DonVi)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_DonVi;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button_TimKiem_DonVi;
        private System.Windows.Forms.TextBox textBox_TimKiem_DonVi;
        private System.Windows.Forms.DataGridView dataGridView_DonVi;
        private System.Windows.Forms.Label label_TimKiem;
    }
}
