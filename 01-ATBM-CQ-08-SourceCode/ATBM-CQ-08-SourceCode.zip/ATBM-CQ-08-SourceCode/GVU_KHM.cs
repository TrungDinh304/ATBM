﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;


namespace ATBM
{
    public partial class GVU_KHM : Form
    {
        public GVU_KHM()
        {
            InitializeComponent();

        }


        private void GVU_KHM_Load(object sender, EventArgs e)
        {
            LoadUserData();
        }



        /*Hiển thị tất cả sinh viên */
        DataSet getAllUser()
        {
            DataSet data = new DataSet();
            String query = "select * from admin1.X_KHMO";
            using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
            {
                connection.Open();
                OracleDataAdapter adapter = new OracleDataAdapter(query, connection);
                adapter.Fill(data);

                connection.Close();
            }
            return data;
        }

        private void LoadUserData()
        {
            // Call getAllUser to retrieve data
            DataSet userData = getAllUser();

            // Check if there is at least one table in the DataSet
            if (userData.Tables.Count > 0)
            {
                // Set the DataGridView DataSource to the first table in the DataSet
                gvu_khm_dataGridView1.DataSource = userData.Tables[0];
            }
        }


        private DataSet GetDataFromDatabase(string query)
        {
            DataSet data = new DataSet();
            using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
            {
                connection.Open();
                OracleDataAdapter adapter = new OracleDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }



        // tìm kiếm kế hoạch mở theo mã
        private void gvu_khm_textBox1_TextChanged(object sender, EventArgs e)
        {
            // Lấy dữ liệu từ TextBox
            string username = gvu_khm_textBox1.Text.Trim();

            // Kiểm tra xem người dùng đã nhập tên người dùng hay chưa
            if (!string.IsNullOrEmpty(username))
            {
                // Gọi phương thức để lấy dữ liệu từ cơ sở dữ liệu và hiển thị trên DataGridView
                LoadUserData(username);
            }
            else
            {
                LoadUserData();
            }
        }

        private void LoadUserData(string input)
        {
            // Format font column headers
            this.gvu_khm_dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft Sans Serif", 12, FontStyle.Bold);

            // Format font row
            foreach (DataGridViewRow row in gvu_khm_dataGridView1.Rows)
            {
                row.DefaultCellStyle.Font = new Font("Microsoft Sans Serif", 12, FontStyle.Regular);
            }

            // Tạo câu truy vấn dựa trên username
            string query = $"SELECT * FROM admin1.X_KHMO WHERE MAHP LIKE '%{input}%'";

            // Gọi phương thức để thực hiện truy vấn
            DataSet userData = GetDataFromDatabase(query);

            // Hiển thị dữ liệu trên DataGridView
            gvu_khm_dataGridView1.DataSource = userData.Tables[0];

        }


        private void insertKeHoachMo(string MAHP, string HK, string NAM, string MACT)
        {
            string query = $"INSERT INTO admin1.X_KHMO VALUES('{MAHP}','{HK}', '{NAM}', '{MACT}')";

            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    using (OracleCommand alterSessionCommand = new OracleCommand(query, connection))
                    {
                        alterSessionCommand.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Kế hoạch mở đã được thêm thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void updateKeHoachMo(string OLDMAHP, string OLDHK, string OLDNAM, string OLDMACT, string MAHP, string HK, string NAM, string MACT)
        {
            string query = $"UPDATE admin1.X_KHMO SET MAHP='{MAHP}',HK='{HK}', NAM='{NAM}', MACT='{MACT}' WHERE MAHP='{OLDMAHP}' AND HK='{OLDHK}' AND NAM='{OLDNAM}' AND MACT='{OLDMACT}'";

            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    using (OracleCommand alterSessionCommand = new OracleCommand(query, connection))
                    {
                        alterSessionCommand.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Kế hoạch mở đã được cập nhật thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void deleteKeHoachMo(string MAHP, string HK, string NAM, string MACT)
        {
            string query = $"DELETE admin1.X_KHMO WHERE MAHP='{MAHP}' AND HK='{HK}' AND NAM='{NAM}' AND MACT='{MACT}'";

            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    using (OracleCommand alterSessionCommand = new OracleCommand(query, connection))
                    {
                        alterSessionCommand.ExecuteNonQuery();
                    }
                }
                LoadUserData();
                MessageBox.Show("Kế hoạch mở đã được xóa thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private int indexOfContent;
        private string OLDMAHP;
        private string OLDHK;
        private string OLDNAM;
        private string OLDMACT;

        private void gvu_khm_dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            indexOfContent = e.RowIndex;
            DataGridViewRow t = gvu_khm_dataGridView1.Rows[indexOfContent];
            //textBox1.Text = t.Cells[0].Value.ToString();
            OLDMAHP = t.Cells[0].Value.ToString();
            OLDHK = t.Cells[1].Value.ToString();
            OLDNAM = t.Cells[2].Value.ToString();
            OLDMACT = t.Cells[3].Value.ToString();
        }

        private void gvu_khm_btn1_Click(object sender, EventArgs e)
        {
            DataGridViewRow t = gvu_khm_dataGridView1.Rows[indexOfContent];
            string MAHP = t.Cells[0].Value.ToString();
            string HK = t.Cells[1].Value.ToString();
            string NAM = t.Cells[2].Value.ToString();
            string MACT = t.Cells[3].Value.ToString();
            insertKeHoachMo(MAHP, HK, NAM, MACT);
        }

        private void gvu_khm_btn2_Click(object sender, EventArgs e)
        {
            DataGridViewRow t = gvu_khm_dataGridView1.Rows[indexOfContent];
            string MAHP = t.Cells[0].Value.ToString();
            string HK = t.Cells[1].Value.ToString();
            string NAM = t.Cells[2].Value.ToString();
            string MACT = t.Cells[3].Value.ToString();
            //MessageBox.Show(OLDMAHP + " " + OLDHK + " " + OLDNAM + " " + OLDMACT + " ");
            //MessageBox.Show(MAHP + " " + HK + " " + NAM + " " + MACT + " ");
            updateKeHoachMo(OLDMAHP, OLDHK, OLDNAM, OLDMACT, MAHP, HK, NAM, MACT);
        }

        private void gvu_khm_btn3_Click(object sender, EventArgs e)
        {
            DataGridViewRow t = gvu_khm_dataGridView1.Rows[indexOfContent];
            string MAHP = t.Cells[0].Value.ToString();
            string HK = t.Cells[1].Value.ToString();
            string NAM = t.Cells[2].Value.ToString();
            string MACT = t.Cells[3].Value.ToString(); 
            deleteKeHoachMo(MAHP, HK, NAM, MACT);
        }
    }
}
