﻿namespace ATBM
{
    partial class UC_DanhSachLopHoc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_DanhSachLopHoc));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button_TimKiem_SinhVien_DSL = new System.Windows.Forms.Button();
            this.textBox_filter_SinhVien_DSL = new System.Windows.Forms.TextBox();
            this.dataGridView_DanhSachLopHoc = new System.Windows.Forms.DataGridView();
            this.label_SinhVien = new System.Windows.Forms.Label();
            this.label_LopHoc = new System.Windows.Forms.Label();
            this.label_Current = new System.Windows.Forms.Label();
            this.Update = new System.Windows.Forms.DataGridViewButtonColumn();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_DanhSachLopHoc)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(164, 87);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(35, 30);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // button_TimKiem_SinhVien_DSL
            // 
            this.button_TimKiem_SinhVien_DSL.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_TimKiem_SinhVien_DSL.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_TimKiem_SinhVien_DSL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_TimKiem_SinhVien_DSL.Font = new System.Drawing.Font("Arial", 10F);
            this.button_TimKiem_SinhVien_DSL.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_TimKiem_SinhVien_DSL.Location = new System.Drawing.Point(1029, 85);
            this.button_TimKiem_SinhVien_DSL.Name = "button_TimKiem_SinhVien_DSL";
            this.button_TimKiem_SinhVien_DSL.Size = new System.Drawing.Size(144, 30);
            this.button_TimKiem_SinhVien_DSL.TabIndex = 14;
            this.button_TimKiem_SinhVien_DSL.Text = "Tìm Kiếm";
            this.button_TimKiem_SinhVien_DSL.UseVisualStyleBackColor = false;
            this.button_TimKiem_SinhVien_DSL.Click += new System.EventHandler(this.button_TimKiem_SinhVien_DSL_Click);
            // 
            // textBox_filter_SinhVien_DSL
            // 
            this.textBox_filter_SinhVien_DSL.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_filter_SinhVien_DSL.Font = new System.Drawing.Font("Arial", 14F);
            this.textBox_filter_SinhVien_DSL.Location = new System.Drawing.Point(205, 87);
            this.textBox_filter_SinhVien_DSL.Name = "textBox_filter_SinhVien_DSL";
            this.textBox_filter_SinhVien_DSL.Size = new System.Drawing.Size(830, 27);
            this.textBox_filter_SinhVien_DSL.TabIndex = 13;
            // 
            // dataGridView_DanhSachLopHoc
            // 
            this.dataGridView_DanhSachLopHoc.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView_DanhSachLopHoc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial", 10F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_DanhSachLopHoc.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_DanhSachLopHoc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_DanhSachLopHoc.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Update});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Arial", 10F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_DanhSachLopHoc.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView_DanhSachLopHoc.Location = new System.Drawing.Point(39, 126);
            this.dataGridView_DanhSachLopHoc.Name = "dataGridView_DanhSachLopHoc";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Arial", 10F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_DanhSachLopHoc.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView_DanhSachLopHoc.RowHeadersWidth = 51;
            this.dataGridView_DanhSachLopHoc.RowTemplate.Height = 24;
            this.dataGridView_DanhSachLopHoc.Size = new System.Drawing.Size(1134, 566);
            this.dataGridView_DanhSachLopHoc.TabIndex = 12;
            this.dataGridView_DanhSachLopHoc.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_DanhSachLopHoc_CellContentClick);
            // 
            // label_SinhVien
            // 
            this.label_SinhVien.AutoSize = true;
            this.label_SinhVien.Font = new System.Drawing.Font("Arial", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_SinhVien.Location = new System.Drawing.Point(34, 89);
            this.label_SinhVien.Name = "label_SinhVien";
            this.label_SinhVien.Size = new System.Drawing.Size(135, 28);
            this.label_SinhVien.TabIndex = 11;
            this.label_SinhVien.Text = "Sinh Viên: ";
            // 
            // label_LopHoc
            // 
            this.label_LopHoc.AutoSize = true;
            this.label_LopHoc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label_LopHoc.Font = new System.Drawing.Font("Arial", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_LopHoc.Location = new System.Drawing.Point(32, 28);
            this.label_LopHoc.Name = "label_LopHoc";
            this.label_LopHoc.Size = new System.Drawing.Size(166, 38);
            this.label_LopHoc.TabIndex = 10;
            this.label_LopHoc.Text = "LỚP HỌC";
            this.label_LopHoc.Click += new System.EventHandler(this.label_LopHoc_Click);
            // 
            // label_Current
            // 
            this.label_Current.AutoSize = true;
            this.label_Current.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label_Current.Font = new System.Drawing.Font("Arial", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_Current.Location = new System.Drawing.Point(204, 28);
            this.label_Current.Name = "label_Current";
            this.label_Current.Size = new System.Drawing.Size(45, 38);
            this.label_Current.TabIndex = 16;
            this.label_Current.Text = "> ";
            // 
            // Update
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.NullValue = "Sửa";
            this.Update.DefaultCellStyle = dataGridViewCellStyle2;
            this.Update.HeaderText = "";
            this.Update.MinimumWidth = 6;
            this.Update.Name = "Update";
            this.Update.ReadOnly = true;
            this.Update.Text = "Sửa";
            this.Update.UseColumnTextForButtonValue = true;
            this.Update.Width = 125;
            // 
            // UC_DanhSachLopHoc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label_Current);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button_TimKiem_SinhVien_DSL);
            this.Controls.Add(this.textBox_filter_SinhVien_DSL);
            this.Controls.Add(this.dataGridView_DanhSachLopHoc);
            this.Controls.Add(this.label_SinhVien);
            this.Controls.Add(this.label_LopHoc);
            this.Name = "UC_DanhSachLopHoc";
            this.Size = new System.Drawing.Size(1204, 720);
            this.Load += new System.EventHandler(this.UC_DanhSachLopHoc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_DanhSachLopHoc)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button_TimKiem_SinhVien_DSL;
        private System.Windows.Forms.TextBox textBox_filter_SinhVien_DSL;
        private System.Windows.Forms.DataGridView dataGridView_DanhSachLopHoc;
        private System.Windows.Forms.Label label_SinhVien;
        private System.Windows.Forms.Label label_LopHoc;
        private System.Windows.Forms.Label label_Current;
        private System.Windows.Forms.DataGridViewButtonColumn Update;
    }
}
