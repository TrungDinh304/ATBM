﻿namespace ATBM
{
    partial class UC_Xem_NS
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridView_DS_GiangVien = new System.Windows.Forms.DataGridView();
            this.label_LopHoc = new System.Windows.Forms.Label();
            this.textBox_TimKiem_GiangVien = new System.Windows.Forms.TextBox();
            this.label_TimKiem = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_DS_GiangVien)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView_DS_GiangVien
            // 
            this.dataGridView_DS_GiangVien.AllowUserToAddRows = false;
            this.dataGridView_DS_GiangVien.AllowUserToDeleteRows = false;
            this.dataGridView_DS_GiangVien.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_DS_GiangVien.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView_DS_GiangVien.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_DS_GiangVien.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_DS_GiangVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_DS_GiangVien.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_DS_GiangVien.Location = new System.Drawing.Point(44, 159);
            this.dataGridView_DS_GiangVien.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridView_DS_GiangVien.Name = "dataGridView_DS_GiangVien";
            this.dataGridView_DS_GiangVien.ReadOnly = true;
            this.dataGridView_DS_GiangVien.RowHeadersWidth = 51;
            this.dataGridView_DS_GiangVien.RowTemplate.Height = 24;
            this.dataGridView_DS_GiangVien.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_DS_GiangVien.Size = new System.Drawing.Size(1276, 708);
            this.dataGridView_DS_GiangVien.TabIndex = 3;
            this.dataGridView_DS_GiangVien.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_DS_GiangVien_CellClick);
            this.dataGridView_DS_GiangVien.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_DS_GiangVien_CellContentClick);
            // 
            // label_LopHoc
            // 
            this.label_LopHoc.AutoSize = true;
            this.label_LopHoc.Font = new System.Drawing.Font("Arial", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_LopHoc.Location = new System.Drawing.Point(36, 35);
            this.label_LopHoc.Name = "label_LopHoc";
            this.label_LopHoc.Size = new System.Drawing.Size(207, 46);
            this.label_LopHoc.TabIndex = 2;
            this.label_LopHoc.Text = "NHÂN SỰ";
            // 
            // textBox_TimKiem_GiangVien
            // 
            this.textBox_TimKiem_GiangVien.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_TimKiem_GiangVien.Font = new System.Drawing.Font("Arial", 14F);
            this.textBox_TimKiem_GiangVien.Location = new System.Drawing.Point(216, 98);
            this.textBox_TimKiem_GiangVien.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox_TimKiem_GiangVien.Name = "textBox_TimKiem_GiangVien";
            this.textBox_TimKiem_GiangVien.Size = new System.Drawing.Size(577, 33);
            this.textBox_TimKiem_GiangVien.TabIndex = 22;
            this.textBox_TimKiem_GiangVien.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_TimKiem_GiangVien_KeyPress);
            // 
            // label_TimKiem
            // 
            this.label_TimKiem.AutoSize = true;
            this.label_TimKiem.Font = new System.Drawing.Font("Arial", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_TimKiem.Location = new System.Drawing.Point(40, 98);
            this.label_TimKiem.Name = "label_TimKiem";
            this.label_TimKiem.Size = new System.Drawing.Size(131, 35);
            this.label_TimKiem.TabIndex = 21;
            this.label_TimKiem.Text = "Nhân sự";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Arial", 10F);
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(1020, 93);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(117, 38);
            this.button1.TabIndex = 24;
            this.button1.Text = "SỬA";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Crimson;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Arial", 10F);
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button2.Location = new System.Drawing.Point(1179, 93);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(118, 38);
            this.button2.TabIndex = 25;
            this.button2.Text = "XÓA";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.SlateBlue;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Arial", 10F);
            this.button3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button3.Location = new System.Drawing.Point(868, 93);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(118, 38);
            this.button3.TabIndex = 26;
            this.button3.Text = "THÊM";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // UC_Xem_NS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox_TimKiem_GiangVien);
            this.Controls.Add(this.label_TimKiem);
            this.Controls.Add(this.dataGridView_DS_GiangVien);
            this.Controls.Add(this.label_LopHoc);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "UC_Xem_NS";
            this.Size = new System.Drawing.Size(1354, 900);
            this.Load += new System.EventHandler(this.UC_Xem_NS_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_DS_GiangVien)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView_DS_GiangVien;
        private System.Windows.Forms.Label label_LopHoc;
        private System.Windows.Forms.TextBox textBox_TimKiem_GiangVien;
        private System.Windows.Forms.Label label_TimKiem;
        //private System.Windows.Forms.DataGridViewButtonColumn XemPC;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}
