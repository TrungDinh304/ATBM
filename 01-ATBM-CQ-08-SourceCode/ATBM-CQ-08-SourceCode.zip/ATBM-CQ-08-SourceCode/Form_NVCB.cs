﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Image = System.Drawing.Image;

namespace ATBM
{
    public partial class Form_NVCB : Form
    {
        public Form_NVCB()
        {
            InitializeComponent();
            pictureBox_SinhVien.Image = Image.FromFile("../../img/Pink_sinhvien.png");
            UC_TruyVan_SinhVien_GV uc = new UC_TruyVan_SinhVien_GV();
            open_UC_control(uc);
        }

        public void open_UC_control(Control uc)
        {
            // Dock vào panel và đưa lên trước
            uc.Dock = DockStyle.Fill;
            panel_ControlContainer.Controls.Add(uc);
            uc.BringToFront();
        }

        private void pictureBox_SinhVien_Click(object sender, EventArgs e)
        {
            //Thay đổi ảnh khi click vào
            // ảnh lấy từ file được lưu local
            pictureBox_SinhVien.Image = Image.FromFile("../../img/Pink_sinhvien.png");

            pictureBox_DonVi.Image = Image.FromFile("../../img/Black_donvi.png");
            pictureBox_KeHoachMo.Image = Image.FromFile("../../img/Black_kehoachmo.png");
            pictureBox_HocPhan.Image = Image.FromFile("../../img/Black_hocphan.png");


            // nếu chưa tạo UC_LopHoc thì tạo mới
            foreach (Control c in panel_ControlContainer.Controls)
            {
                if (c is UC_TruyVan_SinhVien_GV)
                {
                    // Control is of type UC_LopHoc and is contained by the panel
                    open_UC_control(c);
                    return;
                }
            }
            UC_TruyVan_SinhVien_GV uc = new UC_TruyVan_SinhVien_GV();
            open_UC_control(uc);
        }

        private void pictureBox_DonVi_Click(object sender, EventArgs e)
        {
            //Thay đổi ảnh khi click vào
            // ảnh lấy từ file được lưu local
            pictureBox_DonVi.Image = Image.FromFile("../../img/Pink_donvi.png");

            pictureBox_SinhVien.Image = Image.FromFile("../../img/Black_sinhvien.png");
            pictureBox_KeHoachMo.Image = Image.FromFile("../../img/Black_kehoachmo.png");
            pictureBox_HocPhan.Image = Image.FromFile("../../img/Black_hocphan.png");


            // nếu chưa tạo UC_LopHoc thì tạo mới
            foreach (Control c in panel_ControlContainer.Controls)
            {
                if (c is UC_TruyVan_DonVi_GV)
                {
                    // Control is of type UC_LopHoc and is contained by the panel
                    open_UC_control(c);
                    return;
                }
            }
            UC_TruyVan_DonVi_GV uc = new UC_TruyVan_DonVi_GV();
            open_UC_control(uc);
        }

        private void pictureBox_KeHoachMo_Click(object sender, EventArgs e)
        {
            //Thay đổi ảnh khi click vào
            // ảnh lấy từ file được lưu local
            pictureBox_KeHoachMo.Image = Image.FromFile("../../img/Pink_kehoachmo.png");

            pictureBox_DonVi.Image = Image.FromFile("../../img/Black_donvi.png");
            pictureBox_SinhVien.Image = Image.FromFile("../../img/Black_sinhvien.png");
            pictureBox_HocPhan.Image = Image.FromFile("../../img/Black_hocphan.png");


            // nếu chưa tạo UC_LopHoc thì tạo mới
            foreach (Control c in panel_ControlContainer.Controls)
            {
                if (c is UC_TruyVan_KeHoachMo_GV)
                {
                    // Control is of type UC_LopHoc and is contained by the panel
                    open_UC_control(c);
                    return;
                }
            }
            UC_TruyVan_KeHoachMo_GV uc = new UC_TruyVan_KeHoachMo_GV();
            open_UC_control(uc);
        }

        private void pictureBox_HocPhan_Click(object sender, EventArgs e)
        {
            //Thay đổi ảnh khi click vào
            // ảnh lấy từ file được lưu local
            pictureBox_HocPhan.Image = Image.FromFile("../../img/Pink_hocphan.png");

            pictureBox_DonVi.Image = Image.FromFile("../../img/Black_donvi.png");
            pictureBox_SinhVien.Image = Image.FromFile("../../img/Black_sinhvien.png");
            pictureBox_KeHoachMo.Image = Image.FromFile("../../img/Black_kehoachmo.png");


            // nếu chưa tạo UC_LopHoc thì tạo mới
            foreach (Control c in panel_ControlContainer.Controls)
            {
                if (c is UC_TruyVan_HocPhan_GV)
                {
                    // Control is of type UC_LopHoc and is contained by the panel
                    open_UC_control(c);
                    return;
                }
            }
            UC_TruyVan_HocPhan_GV uc = new UC_TruyVan_HocPhan_GV();
            open_UC_control(uc);
        }


        private void Form_NVCB_Load(object sender, EventArgs e)
        {
            label_role.Text = Login_information.role;
            lable_Username.Text = Login_information.fullname;
        }

        


        private void pictureBox_avatar_Click(object sender, EventArgs e)
        {
            // Mở form thông tin cá nhân
            ATBM.Forrm_Personal_Information form = new ATBM.Forrm_Personal_Information();
            form.ShowDialog();
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            this.FindForm().Close();
        }

        private void lable_Username_Click(object sender, EventArgs e)
        {
            // Mở form thông tin cá nhân
            ATBM.Forrm_Personal_Information form = new ATBM.Forrm_Personal_Information();
            form.ShowDialog();
        }
    }
}
