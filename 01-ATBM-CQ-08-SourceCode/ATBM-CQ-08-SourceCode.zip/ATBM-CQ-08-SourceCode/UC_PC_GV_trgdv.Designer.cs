﻿namespace ATBM
{
    partial class UC_PC_GV_trgdv
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridView_PC_GV = new System.Windows.Forms.DataGridView();
            this.Option = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label_CTPC_TDV = new System.Windows.Forms.Label();
            this.label_infor_gv = new System.Windows.Forms.Label();
            this.button_back = new System.Windows.Forms.Button();
            this.button_Them_PhanCong = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_PC_GV)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView_PC_GV
            // 
            this.dataGridView_PC_GV.AllowUserToAddRows = false;
            this.dataGridView_PC_GV.AllowUserToDeleteRows = false;
            this.dataGridView_PC_GV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_PC_GV.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView_PC_GV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_PC_GV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_PC_GV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_PC_GV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Option});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_PC_GV.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_PC_GV.Location = new System.Drawing.Point(39, 127);
            this.dataGridView_PC_GV.Name = "dataGridView_PC_GV";
            this.dataGridView_PC_GV.ReadOnly = true;
            this.dataGridView_PC_GV.RowHeadersWidth = 51;
            this.dataGridView_PC_GV.RowTemplate.Height = 24;
            this.dataGridView_PC_GV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_PC_GV.Size = new System.Drawing.Size(1134, 470);
            this.dataGridView_PC_GV.TabIndex = 5;
            this.dataGridView_PC_GV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_PC_GV_CellContentClick);
            // 
            // Option
            // 
            this.Option.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Option.HeaderText = "";
            this.Option.MinimumWidth = 6;
            this.Option.Name = "Option";
            this.Option.ReadOnly = true;
            this.Option.Text = "Tùy chỉnh";
            this.Option.UseColumnTextForButtonValue = true;
            // 
            // label_CTPC_TDV
            // 
            this.label_CTPC_TDV.AutoSize = true;
            this.label_CTPC_TDV.Font = new System.Drawing.Font("Arial", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_CTPC_TDV.Location = new System.Drawing.Point(32, 28);
            this.label_CTPC_TDV.Name = "label_CTPC_TDV";
            this.label_CTPC_TDV.Size = new System.Drawing.Size(209, 38);
            this.label_CTPC_TDV.TabIndex = 4;
            this.label_CTPC_TDV.Text = "GIẢNG VIÊN";
            this.label_CTPC_TDV.Click += new System.EventHandler(this.label_CTPC_TDV_Click);
            // 
            // label_infor_gv
            // 
            this.label_infor_gv.AutoSize = true;
            this.label_infor_gv.Font = new System.Drawing.Font("Arial", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_infor_gv.Location = new System.Drawing.Point(262, 28);
            this.label_infor_gv.Name = "label_infor_gv";
            this.label_infor_gv.Size = new System.Drawing.Size(55, 38);
            this.label_infor_gv.TabIndex = 6;
            this.label_infor_gv.Text = ">>";
            // 
            // button_back
            // 
            this.button_back.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button_back.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button_back.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_back.Location = new System.Drawing.Point(64, 623);
            this.button_back.Name = "button_back";
            this.button_back.Size = new System.Drawing.Size(196, 48);
            this.button_back.TabIndex = 7;
            this.button_back.Text = "Trở về";
            this.button_back.UseVisualStyleBackColor = false;
            this.button_back.Click += new System.EventHandler(this.button_back_Click);
            // 
            // button_Them_PhanCong
            // 
            this.button_Them_PhanCong.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button_Them_PhanCong.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button_Them_PhanCong.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_Them_PhanCong.Location = new System.Drawing.Point(327, 623);
            this.button_Them_PhanCong.Name = "button_Them_PhanCong";
            this.button_Them_PhanCong.Size = new System.Drawing.Size(277, 48);
            this.button_Them_PhanCong.TabIndex = 8;
            this.button_Them_PhanCong.Text = "Thêm Phân Công";
            this.button_Them_PhanCong.UseVisualStyleBackColor = false;
            this.button_Them_PhanCong.Click += new System.EventHandler(this.button_Them_PhanCong_Click);
            // 
            // UC_PC_GV_trgdv
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.button_Them_PhanCong);
            this.Controls.Add(this.button_back);
            this.Controls.Add(this.label_infor_gv);
            this.Controls.Add(this.dataGridView_PC_GV);
            this.Controls.Add(this.label_CTPC_TDV);
            this.Name = "UC_PC_GV_trgdv";
            this.Size = new System.Drawing.Size(1204, 720);
            this.Load += new System.EventHandler(this.UC_PC_GV_trgdv_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_PC_GV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView_PC_GV;
        private System.Windows.Forms.Label label_CTPC_TDV;
        private System.Windows.Forms.Label label_infor_gv;
        private System.Windows.Forms.Button button_back;
        private System.Windows.Forms.DataGridViewButtonColumn Option;
        private System.Windows.Forms.Button button_Them_PhanCong;
    }
}
