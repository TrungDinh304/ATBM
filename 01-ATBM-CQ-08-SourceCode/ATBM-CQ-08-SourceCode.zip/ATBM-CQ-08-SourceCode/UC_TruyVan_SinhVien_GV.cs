﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;


namespace ATBM
{
    public partial class UC_TruyVan_SinhVien_GV : UserControl
    {
        public UC_TruyVan_SinhVien_GV()
        {
            InitializeComponent();
        }

        private void UC_TruyVan_SinhVien_GV_Load(object sender, EventArgs e)
        {
            string query = "select * from admin1.x_sinhvien";
            DataSet ds = new DataSet();
            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    OracleDataAdapter adapter = new OracleDataAdapter(query, connection);
                    adapter.Fill(ds);
                    connection.Close();
                }
            }


            catch (Exception ex)
            {
                MessageBox.Show("ERROR: " + ex.Message);
            }
            dataGridView_SinhVien.DataSource = ds.Tables[0];
            dataGridView_SinhVien.Columns[0].HeaderText = "Mã sinh viên";
            dataGridView_SinhVien.Columns[1].HeaderText = "Họ tên";
            dataGridView_SinhVien.Columns[2].HeaderText = "Giới tính";
            dataGridView_SinhVien.Columns[3].HeaderText = "Ngày sinh";
            dataGridView_SinhVien.Columns[4].HeaderText = "Địa chỉ";
            dataGridView_SinhVien.Columns[5].HeaderText = "Số điện thoại";
            dataGridView_SinhVien.Columns[6].HeaderText = "Chương Trình";
            dataGridView_SinhVien.Columns[7].HeaderText = "Ngành";
            dataGridView_SinhVien.Columns[8].HeaderText = "Số tính chỉ tích lũy";
            dataGridView_SinhVien.Columns[9].HeaderText = "Điểm trung bình tích lũy";
        }

        private void button_TimKiem_SinhVien_Click(object sender, EventArgs e)
        {
            string timkiem = textBox_TimKiem_SinhVien.Text;
            string query = $"select * from admin1.x_sinhvien where hoten like \'%{timkiem}%\' or masv like \'%{timkiem}%\'";
            DataSet ds = new DataSet();
            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    OracleDataAdapter adapter = new OracleDataAdapter(query, connection);
                    adapter.Fill(ds);
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: " + ex.Message);
            }
            dataGridView_SinhVien.DataSource = ds.Tables[0];

        
            dataGridView_SinhVien.Columns[0].HeaderText = "Mã sinh viên";
            dataGridView_SinhVien.Columns[1].HeaderText = "Họ tên";
            dataGridView_SinhVien.Columns[2].HeaderText = "Giới tính";
            dataGridView_SinhVien.Columns[3].HeaderText = "Ngày sinh";
            dataGridView_SinhVien.Columns[4].HeaderText = "Địa chỉ";
            dataGridView_SinhVien.Columns[5].HeaderText = "Số điện thoại";
            dataGridView_SinhVien.Columns[6].HeaderText = "Chương Trình";
            dataGridView_SinhVien.Columns[7].HeaderText = "Ngành";
            dataGridView_SinhVien.Columns[8].HeaderText = "Số tính chỉ tích lũy";
            dataGridView_SinhVien.Columns[9].HeaderText = "Điểm trung bình tích lũy";
        }
    }
}
