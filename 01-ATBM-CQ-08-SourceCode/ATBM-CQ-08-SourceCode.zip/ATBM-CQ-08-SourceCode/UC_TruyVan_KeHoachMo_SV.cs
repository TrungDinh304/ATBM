﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;

namespace ATBM
{
    public partial class UC_TruyVan_KeHoachMo_SV : UserControl
    {
        public UC_TruyVan_KeHoachMo_SV()
        {
            InitializeComponent();
        }
        private void Fill_comboBox()
        {
            string query = "select distinct HK ||'-'||nam as hocki from admin1.x_khmo";
            DataSet ds_hocky = new DataSet();
            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    OracleDataAdapter adapter = new OracleDataAdapter(query, connection);
                    adapter.Fill(ds_hocky);
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: " + ex.Message);
            }
            // Thêm mục "Tất cả" vào DataTable
            DataTable dt_hocky = ds_hocky.Tables[0];
            DataRow allRow = dt_hocky.NewRow();
            allRow["hocki"] = "Tất cả";
            dt_hocky.Rows.InsertAt(allRow, 0);

            comboBox_HocKy_KeHoachMo.DataSource = ds_hocky.Tables[0];
            comboBox_HocKy_KeHoachMo.DisplayMember = "hocki";
            comboBox_HocKy_KeHoachMo.ValueMember = "hocki";

        }
        private void UC_TruyVan_KeHoachMo_SV_Load(object sender, EventArgs e)
        {
            Fill_comboBox();
            comboBox_HocKy_KeHoachMo_SelectedIndexChanged(sender, e);
        }

        private void comboBox_HocKy_KeHoachMo_SelectedIndexChanged(object sender, EventArgs e)
        {
            string hocki = comboBox_HocKy_KeHoachMo.SelectedValue.ToString();
            if (hocki == "System.Data.DataRowView")
            {
                return;
            }

            string query = "";

            if (hocki == "Tất cả")
            {
                query = "select * from admin1.x_khmo";
            }
            else
            {
                query = $"select * from admin1.x_khmo where hk||'-'||nam = \'{hocki}\'";
            }

            DataSet ds = new DataSet();
            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    OracleDataAdapter adapter = new OracleDataAdapter(query, connection);
                    adapter.Fill(ds);
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: " + ex.Message);
            }
            dataGridView_KeHoachMo.DataSource = ds.Tables[0];
            dataGridView_KeHoachMo.Columns[0].HeaderText = "Mã học phần";
            dataGridView_KeHoachMo.Columns[1].HeaderText = "Học kì";
            dataGridView_KeHoachMo.Columns[2].HeaderText = "Năm";
            dataGridView_KeHoachMo.Columns[3].HeaderText = "Chương trình";
        }
    }
}
