﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using ATBM;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using NPOI.SS.Formula.Functions;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace ATBM
{
    public partial class Form_PI_SV : Form
    {
        public Form_PI_SV()
        {
            InitializeComponent();
        }

        private void Form_PI_SV_Load(object sender, EventArgs e)
        {
            // câu query1 lấy thông tin cá nhân của sinh viên
            string query1 = "Select * from admin1.X_SINHVIEN";


            DataSet ds = new DataSet();
            try
            {
                // Mở kết nối đến cơ sở dữ liệu
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    //lấy dữ liệu từ bảng
                    OracleDataAdapter adapter = new OracleDataAdapter(query1, connection);
                    adapter.Fill(ds);
                    // đóng kết nối
                    connection.Close();

                }
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có
                MessageBox.Show("Lỗi khi kiểm tra sự tồn tại của người dùng: " + ex.Message);
            }
            // hiển thị thông tin cá nhân của sinh viên
            textBox_username.Text = ds.Tables[0].Rows[0]["MASV"].ToString();
            textBox_hoten.Text = ds.Tables[0].Rows[0]["HOTEN"].ToString();
            textBox_ngaysinh.Text = ds.Tables[0].Rows[0]["NGSINH"].ToString();
            textBox_gioitinh.Text = ds.Tables[0].Rows[0]["PHAI"].ToString();
            textBox_sodienthoai.Text = ds.Tables[0].Rows[0]["DT"].ToString();
            textBox_diachi.Text = ds.Tables[0].Rows[0]["DCHI"].ToString();
            textBox_mact.Text = ds.Tables[0].Rows[0]["MACT"].ToString();
            textBox_manganh.Text = ds.Tables[0].Rows[0]["MANGANH"].ToString();
            textBox_sotctl.Text = ds.Tables[0].Rows[0]["SOTCTL"].ToString();
            textBox_dtbtl.Text = ds.Tables[0].Rows[0]["DTBTL"].ToString();
        }

        private void button_close_Click(object sender, EventArgs e)
        {
            this.FindForm().Close();
        }

        private void button_update_Click(object sender, EventArgs e)
        {
            string sdt = this.textBox_sodienthoai.Text;
            string dchi = this.textBox_diachi.Text;

            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();

                    OracleCommand cmd = new OracleCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "admin1.USP_UPDATE_SDT_DCHI_SV";
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Input parameters
                    cmd.Parameters.Add("SODIENTHOAI", OracleDbType.Varchar2).Value = sdt;
                    cmd.Parameters.Add("DIACHI", OracleDbType.Varchar2).Value = dchi;

                    // Output parameters
                    OracleParameter errorCodeParam = new OracleParameter("p_error_code", OracleDbType.Int32);
                    errorCodeParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(errorCodeParam);

                    OracleParameter errorMsgParam = new OracleParameter("p_error_msg", OracleDbType.Varchar2, 1000);
                    errorMsgParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(errorMsgParam);

                    // Execute the command
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Update thành công!");
                    // reload thông tin hiển thị trên form

                    connection.Close();

                }
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có
                MessageBox.Show("ERR: " + ex.Message);
            }
        }
    }
}
