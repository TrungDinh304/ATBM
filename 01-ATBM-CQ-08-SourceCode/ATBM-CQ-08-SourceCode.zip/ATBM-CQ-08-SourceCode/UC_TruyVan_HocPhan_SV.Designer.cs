﻿namespace ATBM
{
    partial class UC_TruyVan_HocPhan_SV
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_TruyVan_HocPhan_SV));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button_TimKiem_HocPhan = new System.Windows.Forms.Button();
            this.textBox_TimKiem_HocPhan = new System.Windows.Forms.TextBox();
            this.dataGridView_HocPhan = new System.Windows.Forms.DataGridView();
            this.label_TimKiem = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_HocPhan)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(164, 87);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(35, 30);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 32;
            this.pictureBox1.TabStop = false;
            // 
            // button_TimKiem_HocPhan
            // 
            this.button_TimKiem_HocPhan.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_TimKiem_HocPhan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_TimKiem_HocPhan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_TimKiem_HocPhan.Font = new System.Drawing.Font("Arial", 10F);
            this.button_TimKiem_HocPhan.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_TimKiem_HocPhan.Location = new System.Drawing.Point(1029, 85);
            this.button_TimKiem_HocPhan.Name = "button_TimKiem_HocPhan";
            this.button_TimKiem_HocPhan.Size = new System.Drawing.Size(144, 30);
            this.button_TimKiem_HocPhan.TabIndex = 31;
            this.button_TimKiem_HocPhan.Text = "Tìm Kiếm";
            this.button_TimKiem_HocPhan.UseVisualStyleBackColor = false;
            this.button_TimKiem_HocPhan.Click += new System.EventHandler(this.button_TimKiem_HocPhan_Click);
            // 
            // textBox_TimKiem_HocPhan
            // 
            this.textBox_TimKiem_HocPhan.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_TimKiem_HocPhan.Font = new System.Drawing.Font("Arial", 14F);
            this.textBox_TimKiem_HocPhan.Location = new System.Drawing.Point(205, 87);
            this.textBox_TimKiem_HocPhan.Name = "textBox_TimKiem_HocPhan";
            this.textBox_TimKiem_HocPhan.Size = new System.Drawing.Size(830, 27);
            this.textBox_TimKiem_HocPhan.TabIndex = 30;
            // 
            // dataGridView_HocPhan
            // 
            this.dataGridView_HocPhan.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView_HocPhan.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_HocPhan.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_HocPhan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 10F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_HocPhan.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_HocPhan.Enabled = false;
            this.dataGridView_HocPhan.Location = new System.Drawing.Point(39, 123);
            this.dataGridView_HocPhan.Name = "dataGridView_HocPhan";
            this.dataGridView_HocPhan.ReadOnly = true;
            this.dataGridView_HocPhan.RowHeadersWidth = 51;
            this.dataGridView_HocPhan.RowTemplate.Height = 24;
            this.dataGridView_HocPhan.Size = new System.Drawing.Size(1134, 566);
            this.dataGridView_HocPhan.TabIndex = 29;
            // 
            // label_TimKiem
            // 
            this.label_TimKiem.AutoSize = true;
            this.label_TimKiem.Font = new System.Drawing.Font("Arial", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_TimKiem.Location = new System.Drawing.Point(34, 87);
            this.label_TimKiem.Name = "label_TimKiem";
            this.label_TimKiem.Size = new System.Drawing.Size(137, 28);
            this.label_TimKiem.TabIndex = 28;
            this.label_TimKiem.Text = "Học Phần: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(32, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(188, 38);
            this.label1.TabIndex = 27;
            this.label1.Text = "HỌC PHẦN";
            // 
            // UC_TruyVan_HocPhan_SV
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button_TimKiem_HocPhan);
            this.Controls.Add(this.textBox_TimKiem_HocPhan);
            this.Controls.Add(this.dataGridView_HocPhan);
            this.Controls.Add(this.label_TimKiem);
            this.Controls.Add(this.label1);
            this.Name = "UC_TruyVan_HocPhan_SV";
            this.Size = new System.Drawing.Size(1204, 720);
            this.Load += new System.EventHandler(this.UC_TruyVan_HocPhan_SV_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_HocPhan)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button_TimKiem_HocPhan;
        private System.Windows.Forms.TextBox textBox_TimKiem_HocPhan;
        private System.Windows.Forms.DataGridView dataGridView_HocPhan;
        private System.Windows.Forms.Label label_TimKiem;
        private System.Windows.Forms.Label label1;
    }
}
