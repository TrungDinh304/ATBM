﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;


namespace ATBM
{
    public partial class GVU_DV : Form
    {
        public GVU_DV()
        {
            InitializeComponent();

        }


        private void GVU_DV_Load(object sender, EventArgs e)
        {
            LoadUserData();
        }



        /*Hiển thị tất cả sinh viên */
        DataSet getAllUser()
        {
            DataSet data = new DataSet();
            String query = "select * from admin1.X_DONVI";
            using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
            {
                connection.Open();
                OracleDataAdapter adapter = new OracleDataAdapter(query, connection);
                adapter.Fill(data);

                connection.Close();
            }
            return data;
        }

        private void LoadUserData()
        {
            // Call getAllUser to retrieve data
            DataSet userData = getAllUser();

            // Check if there is at least one table in the DataSet
            if (userData.Tables.Count > 0)
            {
                // Set the DataGridView DataSource to the first table in the DataSet
                gvu_dv_dataGridView1.DataSource = userData.Tables[0];
            }
        }


        private DataSet GetDataFromDatabase(string query)
        {
            DataSet data = new DataSet();
            using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
            {
                connection.Open();
                OracleDataAdapter adapter = new OracleDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }



        // tìm kiếm kế hoạch mở theo mã
        private void gvu_dv_textBox1_TextChanged(object sender, EventArgs e)
        {
            // Lấy dữ liệu từ TextBox
            string username = gvu_dv_textBox1.Text.Trim();

            // Kiểm tra xem người dùng đã nhập tên người dùng hay chưa
            if (!string.IsNullOrEmpty(username))
            {
                // Gọi phương thức để lấy dữ liệu từ cơ sở dữ liệu và hiển thị trên DataGridView
                LoadUserData(username);
            }
            else
            {
                LoadUserData();
            }
        }

        private void LoadUserData(string input)
        {
            // Format font column headers
            this.gvu_dv_dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft Sans Serif", 12, FontStyle.Bold);

            // Format font row
            foreach (DataGridViewRow row in gvu_dv_dataGridView1.Rows)
            {
                row.DefaultCellStyle.Font = new Font("Microsoft Sans Serif", 12, FontStyle.Regular);
            }

            // Tạo câu truy vấn dựa trên username
            string query = $"SELECT * FROM admin1.X_DONVI WHERE MADV LIKE '%{input}%' OR TENDV LIKE '%{input}%'";

            // Gọi phương thức để thực hiện truy vấn
            DataSet userData = GetDataFromDatabase(query);

            // Hiển thị dữ liệu trên DataGridView
            gvu_dv_dataGridView1.DataSource = userData.Tables[0];

        }


        private void insertDonVi(string MADV, string TENDV, string TRGDV)
        {
            string query = $"INSERT INTO admin1.X_DONVI VALUES('{MADV}','{TENDV}', '{TRGDV}')";

            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    using (OracleCommand alterSessionCommand = new OracleCommand(query, connection))
                    {
                        alterSessionCommand.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Đơn vị đã được thêm thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void updateDonVi(string OLDMADV, string MADV, string TENDV, string TRGDV)
        {
            string query = $"UPDATE admin1.X_DONVI SET MADV='{MADV}',TENDV='{TENDV}', TRGDV='{TRGDV}' WHERE MADV='{OLDMADV}'";

            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    using (OracleCommand alterSessionCommand = new OracleCommand(query, connection))
                    {
                        alterSessionCommand.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Đơn vị đã được cập nhật thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void deleteDonVi(string MADV)
        {
            string query = $"DELETE admin1.X_DONVI WHERE MADV='{MADV}'";

            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    using (OracleCommand alterSessionCommand = new OracleCommand(query, connection))
                    {
                        alterSessionCommand.ExecuteNonQuery();
                    }
                }
                LoadUserData();
                MessageBox.Show("Đơn vị đã được xóa thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private int indexOfContent;
        private string OLDMADV;
        private void gvu_dv_dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            indexOfContent = e.RowIndex;
            DataGridViewRow t = gvu_dv_dataGridView1.Rows[indexOfContent];
            //textBox1.Text = t.Cells[0].Value.ToString();
            OLDMADV = t.Cells[0].Value.ToString();
        }

        private void gvu_dv_btn1_Click(object sender, EventArgs e)
        {
            DataGridViewRow t = gvu_dv_dataGridView1.Rows[indexOfContent];
            string MADV = t.Cells[0].Value.ToString();
            string TENDV = t.Cells[1].Value.ToString();
            string TRGDV = t.Cells[2].Value.ToString();
            insertDonVi(MADV, TENDV, TRGDV);
        }

        private void gvu_dv_btn2_Click(object sender, EventArgs e)
        {
            DataGridViewRow t = gvu_dv_dataGridView1.Rows[indexOfContent];
            string MADV = t.Cells[0].Value.ToString();
            string TENDV = t.Cells[1].Value.ToString();
            string TRGDV = t.Cells[2].Value.ToString();
            updateDonVi(OLDMADV, MADV, TENDV, TRGDV);
        }

        private void gvu_dv_btn3_Click(object sender, EventArgs e)
        {
            DataGridViewRow t = gvu_dv_dataGridView1.Rows[indexOfContent];
            string MADV = t.Cells[0].Value.ToString();

            deleteDonVi(MADV);
        }
    }
}
