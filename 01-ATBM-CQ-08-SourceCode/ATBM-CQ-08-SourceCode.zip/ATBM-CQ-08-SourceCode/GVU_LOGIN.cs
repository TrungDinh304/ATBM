﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;

namespace ATBM
{

    public partial class GVU_LOGIN : Form
    {

        public GVU_LOGIN()
        {
            InitializeComponent();
        }

        string textBox_Username_string = " # Tên đăng nhập.";
        string textBox_Password_string = " # Mật khẩu.";

        private void GVU_LOGIN_Load(object sender, EventArgs e)
        {
            this.textBox_username.Text = textBox_Username_string;
            this.textBox_password.Text = textBox_Password_string;
        }

        private void textBox_username_Leave(object sender, EventArgs e)
        {
            if (textBox_username.Text == "")
            {
                textBox_username.Text = textBox_Username_string;
                // đổi màu chữ thành màu xám
                textBox_username.ForeColor = Color.Gray;
            }
        }

        private void textBox_password_Click(object sender, EventArgs e)
        {
            if (textBox_password.Text == textBox_Password_string)
            {
                textBox_password.Text = "";
                // đổi màu chữ thành màu đen
                textBox_password.ForeColor = Color.Black;
                textBox_password.PasswordChar = '*';
            }
        }

        private void textBox_password_Leave(object sender, EventArgs e)
        {
            if (textBox_password.Text == "")
            {
                textBox_password.Text = textBox_Password_string;
                // đổi màu chữ thành màu xám
                textBox_password.ForeColor = Color.Gray;
                textBox_password.PasswordChar = '\0';
            }
        }

        private void textBox_username_Click(object sender, EventArgs e)
        {
            if (textBox_username.Text == textBox_Username_string)
            {
                textBox_username.Text = "";
                // đổi màu chữ thành màu đen
                textBox_username.ForeColor = Color.Black;
            }
        }

        private void button_Login_Click(object sender, EventArgs e)
        {
            string current_username = textBox_username.Text;
            string current_password = textBox_password.Text;
            ConnectionStr.connectionStr = @"DATA SOURCE=localhost:1521/xe;PERSIST SECURITY INFO=True;USER ID=" + current_username + ";PASSWORD=" + current_password;

            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                }
                Login_information.username = current_username;
                Login_information.password = current_password;

                this.Hide();


            }
            catch (Exception ex)
            {
                MessageBox.Show("Đăng nhập thất bại. Vui lòng kiểm tra lại thông tin đăng nhập.\n" + ex.Message);
                // In ra nguyên nhân lỗi
                textBox_password.Text = "";
            }

            string query = "select hoten, vaitro, madv from admin1.V_Nhansu_Nhanvien";
            DataSet ds = new DataSet();
            try
            {
                // Mở kết nối đến cơ sở dữ liệu
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    //lấy dữ liệu từ bảng
                    OracleDataAdapter adapter = new OracleDataAdapter(query, connection);
                    adapter.Fill(ds);
                    // đóng kết nối
                    connection.Close();

                }
                Login_information.role = ds.Tables[0].Rows[0]["vaitro"].ToString();
                Login_information.fullname = ds.Tables[0].Rows[0]["hoten"].ToString();
                Login_information.Donvi = ds.Tables[0].Rows[0]["madv"].ToString();
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có
                MessageBox.Show("Lỗi khi kiểm tra sự tồn tại của người dùng: " + ex.Message);
            }


            if (Login_information.role == "Giao vu")
            {
                GVU Form_GV = new GVU();
                Form_GV.Show();
                Form_GV.FormClosed += (s, args) => this.Show();
                textBox_username.Text = textBox_Username_string;
                textBox_password.Text = textBox_Password_string;
            }
            

        }

        private void textBox_password_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button_Login_Click(sender, e);
            }
        }

        private void textBox_password_TextChanged(object sender, EventArgs e)
        {
            if (textBox_password.Text != textBox_Password_string)
            {
                textBox_password.PasswordChar = '*';
                textBox_password.ForeColor = Color.Black;
            }
            if (textBox_password.Text == textBox_Password_string)
            {
                textBox_password.PasswordChar = '\0';
                textBox_password.ForeColor = Color.Gray;
            }
        }

        private void textBox_username_TextChanged(object sender, EventArgs e)
        {
            if (textBox_username.Text != textBox_Username_string)
            {
                textBox_username.ForeColor = Color.Black;
            }
            if (textBox_username.Text == textBox_Username_string)
            {
                textBox_username.ForeColor = Color.Gray;
            }
        }
    }
}