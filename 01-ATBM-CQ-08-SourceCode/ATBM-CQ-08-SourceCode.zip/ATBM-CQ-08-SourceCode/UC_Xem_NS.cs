﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;


namespace ATBM
{
    public partial class UC_Xem_NS : UserControl
    {
        public UC_Xem_NS()
        {
            InitializeComponent();
        }

        private void UC_Xem_NS_Load(object sender, EventArgs e)
        {
            loadNS();
        }

        private void loadNS()
        {
            string NhanSu_search = textBox_TimKiem_GiangVien.Text;
            string query_string = $"select * from admin1.X_NHANSU where manv like '%{NhanSu_search}%' or hoten like '%{NhanSu_search}%'";

            DataSet ds_phancong = new DataSet();

            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    //lấy dữ liệu từ bảng
                    OracleDataAdapter adapter = new OracleDataAdapter(query_string, connection);
                    adapter.Fill(ds_phancong);
                    // đóng kết nối
                    connection.Close();
                    // rót dữ liệu vào datagridview
                    dataGridView_DS_GiangVien.DataSource = ds_phancong.Tables[0];
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: " + ex.Message);
            }
        }

        private void textBox_TimKiem_GiangVien_KeyPress(object sender, KeyPressEventArgs e)
        {
            loadNS();
        }

        public void RefreshContent()
        {
            // Add logic to refresh the content of Form1
            loadNS();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form_Insert_NS f = new Form_Insert_NS(this);
            f.ShowDialog();
        }

        public static string manv = null;
        private void button2_Click(object sender, EventArgs e)
        {
            // Ask for confirmation before deleting
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa nhân viên " + manv + " này?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                try
                {
                    using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                    {
                        connection.Open();

                        OracleCommand cmd = new OracleCommand();
                        cmd.Connection = connection;
                        cmd.CommandText = "admin1.USP_DELETE_NHANSU";
                        cmd.CommandType = CommandType.StoredProcedure;

                        // Input parameters
                        cmd.Parameters.Add("P_MANV", OracleDbType.Varchar2).Value = manv;

                        // Output parameters
                        OracleParameter errorCodeParam = new OracleParameter("P_ERROR_CODE", OracleDbType.Int32);
                        errorCodeParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(errorCodeParam);

                        OracleParameter errorMsgParam = new OracleParameter("P_ERROR_MSG", OracleDbType.Varchar2, 1000);
                        errorMsgParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(errorMsgParam);

                        // Execute the command
                        cmd.ExecuteNonQuery();

                        MessageBox.Show("Xóa thành công!");
                        // reload thông tin hiển thị trên form
                        loadNS();
                        connection.Close();
                    }
                }
                catch (Exception ex)
                {
                    // Xử lý lỗi nếu có
                    MessageBox.Show("ERR: " + ex.Message);
                }
            }
        }

        private void dataGridView_DS_GiangVien_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            manv = dataGridView_DS_GiangVien.Rows[e.RowIndex].Cells[0].Value.ToString();
        }

        private void dataGridView_DS_GiangVien_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (manv == null)
            {
                MessageBox.Show("Vui lòng chọn nhân viên!");
                return;
            }
            Form_Update_NS f = new Form_Update_NS(this);
            f.ShowDialog();
        }
    }
}
