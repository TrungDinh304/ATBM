﻿namespace ATBM
{
    partial class f_modify_PC_TK
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button_insert = new System.Windows.Forms.Button();
            this.button_delete = new System.Windows.Forms.Button();
            this.button_update = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_mact = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_nam = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_hk = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_mahp = new System.Windows.Forms.TextBox();
            this.label_magv = new System.Windows.Forms.Label();
            this.textBox_magv = new System.Windows.Forms.TextBox();
            this.label_modify = new System.Windows.Forms.Label();
            this.label_DS_KHM = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dataGridView_ds_KHM = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ds_KHM)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel1.Controls.Add(this.button_insert);
            this.panel1.Controls.Add(this.button_delete);
            this.panel1.Controls.Add(this.button_update);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.textBox_mact);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.textBox_nam);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.textBox_hk);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.textBox_mahp);
            this.panel1.Controls.Add(this.label_magv);
            this.panel1.Controls.Add(this.textBox_magv);
            this.panel1.Controls.Add(this.label_modify);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(452, 516);
            this.panel1.TabIndex = 0;
            // 
            // button_insert
            // 
            this.button_insert.BackColor = System.Drawing.Color.MediumAquamarine;
            this.button_insert.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button_insert.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_insert.Location = new System.Drawing.Point(112, 418);
            this.button_insert.Name = "button_insert";
            this.button_insert.Size = new System.Drawing.Size(209, 51);
            this.button_insert.TabIndex = 14;
            this.button_insert.Text = "Thêm";
            this.button_insert.UseVisualStyleBackColor = false;
            this.button_insert.Click += new System.EventHandler(this.button_insert_Click);
            // 
            // button_delete
            // 
            this.button_delete.BackColor = System.Drawing.Color.PaleVioletRed;
            this.button_delete.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button_delete.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_delete.Location = new System.Drawing.Point(241, 418);
            this.button_delete.Name = "button_delete";
            this.button_delete.Size = new System.Drawing.Size(174, 51);
            this.button_delete.TabIndex = 13;
            this.button_delete.Text = "Xóa";
            this.button_delete.UseVisualStyleBackColor = false;
            this.button_delete.Click += new System.EventHandler(this.button_delete_Click);
            // 
            // button_update
            // 
            this.button_update.BackColor = System.Drawing.Color.SteelBlue;
            this.button_update.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button_update.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_update.Location = new System.Drawing.Point(33, 418);
            this.button_update.Name = "button_update";
            this.button_update.Size = new System.Drawing.Size(174, 51);
            this.button_update.TabIndex = 12;
            this.button_update.Text = "Cập nhật";
            this.button_update.UseVisualStyleBackColor = false;
            this.button_update.Click += new System.EventHandler(this.button_update_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 10F);
            this.label4.Location = new System.Drawing.Point(29, 339);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 19);
            this.label4.TabIndex = 11;
            this.label4.Text = "Mã chương trình:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // textBox_mact
            // 
            this.textBox_mact.Enabled = false;
            this.textBox_mact.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBox_mact.Location = new System.Drawing.Point(201, 336);
            this.textBox_mact.Name = "textBox_mact";
            this.textBox_mact.Size = new System.Drawing.Size(214, 27);
            this.textBox_mact.TabIndex = 10;
            this.textBox_mact.TextChanged += new System.EventHandler(this.textBox_mact_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 10F);
            this.label3.Location = new System.Drawing.Point(29, 282);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 19);
            this.label3.TabIndex = 9;
            this.label3.Text = "Năm học:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // textBox_nam
            // 
            this.textBox_nam.Enabled = false;
            this.textBox_nam.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBox_nam.Location = new System.Drawing.Point(201, 279);
            this.textBox_nam.Name = "textBox_nam";
            this.textBox_nam.Size = new System.Drawing.Size(214, 27);
            this.textBox_nam.TabIndex = 8;
            this.textBox_nam.TextChanged += new System.EventHandler(this.textBox_nam_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 10F);
            this.label2.Location = new System.Drawing.Point(29, 225);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 19);
            this.label2.TabIndex = 7;
            this.label2.Text = "Học kì:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // textBox_hk
            // 
            this.textBox_hk.Enabled = false;
            this.textBox_hk.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBox_hk.Location = new System.Drawing.Point(201, 222);
            this.textBox_hk.Name = "textBox_hk";
            this.textBox_hk.Size = new System.Drawing.Size(214, 27);
            this.textBox_hk.TabIndex = 6;
            this.textBox_hk.TextChanged += new System.EventHandler(this.textBox_hk_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 10F);
            this.label1.Location = new System.Drawing.Point(29, 174);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 19);
            this.label1.TabIndex = 5;
            this.label1.Text = "Mã học phần:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // textBox_mahp
            // 
            this.textBox_mahp.Enabled = false;
            this.textBox_mahp.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBox_mahp.Location = new System.Drawing.Point(201, 171);
            this.textBox_mahp.Name = "textBox_mahp";
            this.textBox_mahp.Size = new System.Drawing.Size(214, 27);
            this.textBox_mahp.TabIndex = 4;
            this.textBox_mahp.TextChanged += new System.EventHandler(this.textBox_mahp_TextChanged);
            // 
            // label_magv
            // 
            this.label_magv.AutoSize = true;
            this.label_magv.Font = new System.Drawing.Font("Arial", 10F);
            this.label_magv.Location = new System.Drawing.Point(29, 122);
            this.label_magv.Name = "label_magv";
            this.label_magv.Size = new System.Drawing.Size(115, 19);
            this.label_magv.TabIndex = 3;
            this.label_magv.Text = "Mã giảng viên:";
            this.label_magv.Click += new System.EventHandler(this.label_magv_Click);
            // 
            // textBox_magv
            // 
            this.textBox_magv.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBox_magv.Location = new System.Drawing.Point(201, 119);
            this.textBox_magv.Name = "textBox_magv";
            this.textBox_magv.Size = new System.Drawing.Size(214, 27);
            this.textBox_magv.TabIndex = 2;
            this.textBox_magv.TextChanged += new System.EventHandler(this.textBox_magv_TextChanged);
            // 
            // label_modify
            // 
            this.label_modify.AutoSize = true;
            this.label_modify.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_modify.Location = new System.Drawing.Point(41, 26);
            this.label_modify.Name = "label_modify";
            this.label_modify.Size = new System.Drawing.Size(349, 33);
            this.label_modify.TabIndex = 1;
            this.label_modify.Text = "CHỈNH SỬA PHÂN CÔNG";
            // 
            // label_DS_KHM
            // 
            this.label_DS_KHM.AutoSize = true;
            this.label_DS_KHM.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_DS_KHM.Location = new System.Drawing.Point(73, 26);
            this.label_DS_KHM.Name = "label_DS_KHM";
            this.label_DS_KHM.Size = new System.Drawing.Size(393, 33);
            this.label_DS_KHM.TabIndex = 0;
            this.label_DS_KHM.Text = "DANH SÁCH KẾ HOẠCH MỞ";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel2.Controls.Add(this.dataGridView_ds_KHM);
            this.panel2.Controls.Add(this.label_DS_KHM);
            this.panel2.Location = new System.Drawing.Point(470, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(600, 516);
            this.panel2.TabIndex = 1;
            // 
            // dataGridView_ds_KHM
            // 
            this.dataGridView_ds_KHM.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView_ds_KHM.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial", 8F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_ds_KHM.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_ds_KHM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 8F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_ds_KHM.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_ds_KHM.Location = new System.Drawing.Point(18, 71);
            this.dataGridView_ds_KHM.Name = "dataGridView_ds_KHM";
            this.dataGridView_ds_KHM.ReadOnly = true;
            this.dataGridView_ds_KHM.RowHeadersWidth = 51;
            this.dataGridView_ds_KHM.RowTemplate.Height = 24;
            this.dataGridView_ds_KHM.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_ds_KHM.Size = new System.Drawing.Size(563, 442);
            this.dataGridView_ds_KHM.TabIndex = 0;
            this.dataGridView_ds_KHM.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_ds_KHM_CellClick);
            this.dataGridView_ds_KHM.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_ds_KHM_CellContentClick);
            // 
            // f_modify_PC_TK
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1096, 687);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "f_modify_PC_TK";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tùy chỉnh";
            this.Load += new System.EventHandler(this.f_modify_PC_TK_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ds_KHM)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox_magv;
        private System.Windows.Forms.Label label_modify;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_mact;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_nam;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_hk;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_mahp;
        private System.Windows.Forms.Label label_magv;
        private System.Windows.Forms.Button button_update;
        private System.Windows.Forms.Button button_delete;
        private System.Windows.Forms.Button button_insert;
        private System.Windows.Forms.Label label_DS_KHM;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dataGridView_ds_KHM;
    }
}