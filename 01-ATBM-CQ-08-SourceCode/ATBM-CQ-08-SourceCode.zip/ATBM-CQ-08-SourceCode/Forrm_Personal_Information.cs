﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using ATBM;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using NPOI.SS.Formula.Functions;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;


namespace ATBM
{
    public partial class Forrm_Personal_Information : Form
    {
        public Forrm_Personal_Information()
        {
            InitializeComponent();
        }

        private void Forrm_Personal_Information_Load(object sender, EventArgs e)
        {
            // câu query1 lấy thông tin cá nhân của sinh viên
            string query1 = "Select ns.*,(select TENDV from admin1.x_donvi dv where ns.MaDV = dv.Madv) as TENDV " +
                            "from admin1.UV_THONGTINCANHAN_NS ns";
            

            DataSet ds = new DataSet();
            try
            {
                // Mở kết nối đến cơ sở dữ liệu
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();
                    //lấy dữ liệu từ bảng
                    OracleDataAdapter adapter = new OracleDataAdapter(query1, connection);
                    adapter.Fill(ds);
                    // đóng kết nối
                    connection.Close();

                }
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có
                MessageBox.Show("Lỗi khi kiểm tra sự tồn tại của người dùng: " + ex.Message);
            }
            // hiển thị thông tin cá nhân của sinh viên
            textBox_username.Text = ds.Tables[0].Rows[0]["MANV"].ToString();
            textBox_hoten.Text = ds.Tables[0].Rows[0]["HOTEN"].ToString();
            textBox_ngaysinh.Text = ds.Tables[0].Rows[0]["NGSINH"].ToString();
            textBox_gioitinh.Text = ds.Tables[0].Rows[0]["PHAI"].ToString();
            textBox_sodienthoai.Text = ds.Tables[0].Rows[0]["DT"].ToString();
            textBox_phucap.Text = ds.Tables[0].Rows[0]["PHUCAP"].ToString();
            textBox_vaitro.Text = ds.Tables[0].Rows[0]["VAITRO"].ToString();
            textBox_donvi.Text = ds.Tables[0].Rows[0]["TENDV"].ToString();

        }

        private void button_close_Click(object sender, EventArgs e)
        {
            this.FindForm().Close();
        }

        private void button_update_Click(object sender, EventArgs e)
        {
            string sdt = this.textBox_sodienthoai.Text;
            

            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();

                    OracleCommand cmd = new OracleCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "admin1.USP_UPDATE_SDT_NV";
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Input parameters
                    cmd.Parameters.Add("SODIENTHOAI", OracleDbType.Varchar2).Value = sdt;

                    // Output parameters
                    OracleParameter errorCodeParam = new OracleParameter("p_error_code", OracleDbType.Int32);
                    errorCodeParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(errorCodeParam);

                    OracleParameter errorMsgParam = new OracleParameter("p_error_msg", OracleDbType.Varchar2, 1000);
                    errorMsgParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(errorMsgParam);

                    // Execute the command
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Update thành công!");
                    // reload thông tin hiển thị trên form

                    connection.Close();

                }
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có
                MessageBox.Show("ERR: " + ex.Message);
            }
        }
    }
}
