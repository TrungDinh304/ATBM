﻿namespace ATBM
{
    partial class Form_NVCB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_NVCB));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox_DonVi = new System.Windows.Forms.PictureBox();
            this.pictureBox_KeHoachMo = new System.Windows.Forms.PictureBox();
            this.pictureBox_HocPhan = new System.Windows.Forms.PictureBox();
            this.pictureBox_SinhVien = new System.Windows.Forms.PictureBox();
            this.label_TruyVan = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel_ControlContainer = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.label_role = new System.Windows.Forms.Label();
            this.lable_Username = new System.Windows.Forms.Label();
            this.pictureBox_avatar = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_DonVi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_KeHoachMo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_HocPhan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_SinhVien)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_avatar)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(229, 81);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox_DonVi
            // 
            this.pictureBox_DonVi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_DonVi.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_DonVi.Image")));
            this.pictureBox_DonVi.Location = new System.Drawing.Point(12, 204);
            this.pictureBox_DonVi.Name = "pictureBox_DonVi";
            this.pictureBox_DonVi.Size = new System.Drawing.Size(251, 42);
            this.pictureBox_DonVi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_DonVi.TabIndex = 19;
            this.pictureBox_DonVi.TabStop = false;
            this.pictureBox_DonVi.Click += new System.EventHandler(this.pictureBox_DonVi_Click);
            // 
            // pictureBox_KeHoachMo
            // 
            this.pictureBox_KeHoachMo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_KeHoachMo.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_KeHoachMo.Image")));
            this.pictureBox_KeHoachMo.Location = new System.Drawing.Point(12, 252);
            this.pictureBox_KeHoachMo.Name = "pictureBox_KeHoachMo";
            this.pictureBox_KeHoachMo.Size = new System.Drawing.Size(251, 42);
            this.pictureBox_KeHoachMo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_KeHoachMo.TabIndex = 18;
            this.pictureBox_KeHoachMo.TabStop = false;
            this.pictureBox_KeHoachMo.Click += new System.EventHandler(this.pictureBox_KeHoachMo_Click);
            // 
            // pictureBox_HocPhan
            // 
            this.pictureBox_HocPhan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_HocPhan.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_HocPhan.Image")));
            this.pictureBox_HocPhan.Location = new System.Drawing.Point(12, 300);
            this.pictureBox_HocPhan.Name = "pictureBox_HocPhan";
            this.pictureBox_HocPhan.Size = new System.Drawing.Size(251, 42);
            this.pictureBox_HocPhan.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_HocPhan.TabIndex = 17;
            this.pictureBox_HocPhan.TabStop = false;
            this.pictureBox_HocPhan.Click += new System.EventHandler(this.pictureBox_HocPhan_Click);
            // 
            // pictureBox_SinhVien
            // 
            this.pictureBox_SinhVien.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_SinhVien.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_SinhVien.Image")));
            this.pictureBox_SinhVien.Location = new System.Drawing.Point(12, 156);
            this.pictureBox_SinhVien.Name = "pictureBox_SinhVien";
            this.pictureBox_SinhVien.Size = new System.Drawing.Size(251, 42);
            this.pictureBox_SinhVien.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_SinhVien.TabIndex = 16;
            this.pictureBox_SinhVien.TabStop = false;
            this.pictureBox_SinhVien.Click += new System.EventHandler(this.pictureBox_SinhVien_Click);
            // 
            // label_TruyVan
            // 
            this.label_TruyVan.AutoSize = true;
            this.label_TruyVan.Font = new System.Drawing.Font("Arial", 10F);
            this.label_TruyVan.Location = new System.Drawing.Point(12, 124);
            this.label_TruyVan.Name = "label_TruyVan";
            this.label_TruyVan.Size = new System.Drawing.Size(75, 19);
            this.label_TruyVan.TabIndex = 15;
            this.label_TruyVan.Text = "Truy Vấn";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(217, 16);
            this.label2.TabIndex = 14;
            this.label2.Text = "______________________________";
            // 
            // panel_ControlContainer
            // 
            this.panel_ControlContainer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_ControlContainer.BackColor = System.Drawing.SystemColors.Control;
            this.panel_ControlContainer.Location = new System.Drawing.Point(290, -1);
            this.panel_ControlContainer.Name = "panel_ControlContainer";
            this.panel_ControlContainer.Size = new System.Drawing.Size(1185, 720);
            this.panel_ControlContainer.TabIndex = 20;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 641);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(217, 16);
            this.label3.TabIndex = 25;
            this.label3.Text = "______________________________";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(219, 675);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(44, 44);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 24;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Click += new System.EventHandler(this.pictureBox8_Click);
            // 
            // label_role
            // 
            this.label_role.AutoSize = true;
            this.label_role.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label_role.Font = new System.Drawing.Font("Arial", 8F);
            this.label_role.Location = new System.Drawing.Point(68, 700);
            this.label_role.Name = "label_role";
            this.label_role.Size = new System.Drawing.Size(62, 16);
            this.label_role.TabIndex = 23;
            this.label_role.Text = "Chức Vụ";
            // 
            // lable_Username
            // 
            this.lable_Username.AutoSize = true;
            this.lable_Username.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lable_Username.Font = new System.Drawing.Font("Arial", 10F);
            this.lable_Username.Location = new System.Drawing.Point(68, 677);
            this.lable_Username.Name = "lable_Username";
            this.lable_Username.Size = new System.Drawing.Size(82, 19);
            this.lable_Username.TabIndex = 22;
            this.lable_Username.Text = "Họ và Tên";
            this.lable_Username.Click += new System.EventHandler(this.lable_Username_Click);
            // 
            // pictureBox_avatar
            // 
            this.pictureBox_avatar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_avatar.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_avatar.Image")));
            this.pictureBox_avatar.Location = new System.Drawing.Point(12, 669);
            this.pictureBox_avatar.Name = "pictureBox_avatar";
            this.pictureBox_avatar.Size = new System.Drawing.Size(50, 50);
            this.pictureBox_avatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_avatar.TabIndex = 21;
            this.pictureBox_avatar.TabStop = false;
            this.pictureBox_avatar.Click += new System.EventHandler(this.pictureBox_avatar_Click);
            // 
            // Form_NVCB
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1468, 731);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.label_role);
            this.Controls.Add(this.lable_Username);
            this.Controls.Add(this.pictureBox_avatar);
            this.Controls.Add(this.panel_ControlContainer);
            this.Controls.Add(this.pictureBox_DonVi);
            this.Controls.Add(this.pictureBox_KeHoachMo);
            this.Controls.Add(this.pictureBox_HocPhan);
            this.Controls.Add(this.pictureBox_SinhVien);
            this.Controls.Add(this.label_TruyVan);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form_NVCB";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form_NVCB";
            this.Load += new System.EventHandler(this.Form_NVCB_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_DonVi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_KeHoachMo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_HocPhan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_SinhVien)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_avatar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox_DonVi;
        private System.Windows.Forms.PictureBox pictureBox_KeHoachMo;
        private System.Windows.Forms.PictureBox pictureBox_HocPhan;
        private System.Windows.Forms.PictureBox pictureBox_SinhVien;
        private System.Windows.Forms.Label label_TruyVan;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.Panel panel_ControlContainer;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label_role;
        private System.Windows.Forms.Label lable_Username;
        private System.Windows.Forms.PictureBox pictureBox_avatar;
    }
}