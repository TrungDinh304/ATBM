﻿namespace ATBM
{
    partial class UC_PhanCong_TK
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridView_PhanCong = new System.Windows.Forms.DataGridView();
            this.Option = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label_PhanCong = new System.Windows.Forms.Label();
            this.comboBox_HocKy_PC = new System.Windows.Forms.ComboBox();
            this.label_HocKy = new System.Windows.Forms.Label();
            this.button_insert = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_PhanCong)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView_PhanCong
            // 
            this.dataGridView_PhanCong.AllowUserToAddRows = false;
            this.dataGridView_PhanCong.AllowUserToDeleteRows = false;
            this.dataGridView_PhanCong.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_PhanCong.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView_PhanCong.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_PhanCong.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView_PhanCong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_PhanCong.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Option});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_PhanCong.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView_PhanCong.Location = new System.Drawing.Point(44, 159);
            this.dataGridView_PhanCong.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridView_PhanCong.Name = "dataGridView_PhanCong";
            this.dataGridView_PhanCong.ReadOnly = true;
            this.dataGridView_PhanCong.RowHeadersWidth = 51;
            this.dataGridView_PhanCong.RowTemplate.Height = 24;
            this.dataGridView_PhanCong.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_PhanCong.Size = new System.Drawing.Size(1276, 691);
            this.dataGridView_PhanCong.TabIndex = 5;
            this.dataGridView_PhanCong.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_PhanCong_CellContentClick);
            // 
            // Option
            // 
            this.Option.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Option.HeaderText = "";
            this.Option.MinimumWidth = 6;
            this.Option.Name = "Option";
            this.Option.ReadOnly = true;
            this.Option.Text = "Chỉnh sửa";
            this.Option.UseColumnTextForButtonValue = true;
            // 
            // label_PhanCong
            // 
            this.label_PhanCong.AutoSize = true;
            this.label_PhanCong.Font = new System.Drawing.Font("Arial", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_PhanCong.Location = new System.Drawing.Point(36, 35);
            this.label_PhanCong.Name = "label_PhanCong";
            this.label_PhanCong.Size = new System.Drawing.Size(265, 46);
            this.label_PhanCong.TabIndex = 4;
            this.label_PhanCong.Text = "PHÂN CÔNG";
            // 
            // comboBox_HocKy_PC
            // 
            this.comboBox_HocKy_PC.Cursor = System.Windows.Forms.Cursors.Hand;
            this.comboBox_HocKy_PC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_HocKy_PC.Font = new System.Drawing.Font("Arial", 10F);
            this.comboBox_HocKy_PC.FormattingEnabled = true;
            this.comboBox_HocKy_PC.Items.AddRange(new object[] {
            ""});
            this.comboBox_HocKy_PC.Location = new System.Drawing.Point(184, 110);
            this.comboBox_HocKy_PC.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox_HocKy_PC.Name = "comboBox_HocKy_PC";
            this.comboBox_HocKy_PC.Size = new System.Drawing.Size(620, 31);
            this.comboBox_HocKy_PC.Sorted = true;
            this.comboBox_HocKy_PC.TabIndex = 7;
            this.comboBox_HocKy_PC.SelectedIndexChanged += new System.EventHandler(this.comboBox_HocKy_PC_SelectedIndexChanged);
            // 
            // label_HocKy
            // 
            this.label_HocKy.AutoSize = true;
            this.label_HocKy.Font = new System.Drawing.Font("Arial", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label_HocKy.Location = new System.Drawing.Point(38, 105);
            this.label_HocKy.Name = "label_HocKy";
            this.label_HocKy.Size = new System.Drawing.Size(119, 35);
            this.label_HocKy.TabIndex = 6;
            this.label_HocKy.Text = "Học Kỳ:";
            // 
            // button_insert
            // 
            this.button_insert.BackColor = System.Drawing.Color.MediumAquamarine;
            this.button_insert.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button_insert.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_insert.Location = new System.Drawing.Point(921, 110);
            this.button_insert.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_insert.Name = "button_insert";
            this.button_insert.Size = new System.Drawing.Size(323, 41);
            this.button_insert.TabIndex = 13;
            this.button_insert.Text = "Thêm Phân Công";
            this.button_insert.UseVisualStyleBackColor = false;
            this.button_insert.Click += new System.EventHandler(this.button_insert_Click);
            // 
            // UC_PhanCong_TK
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.button_insert);
            this.Controls.Add(this.dataGridView_PhanCong);
            this.Controls.Add(this.label_PhanCong);
            this.Controls.Add(this.comboBox_HocKy_PC);
            this.Controls.Add(this.label_HocKy);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "UC_PhanCong_TK";
            this.Size = new System.Drawing.Size(1354, 900);
            this.Load += new System.EventHandler(this.UC_PhanCong_TK_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_PhanCong)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView_PhanCong;
        private System.Windows.Forms.Label label_PhanCong;
        private System.Windows.Forms.ComboBox comboBox_HocKy_PC;
        private System.Windows.Forms.Label label_HocKy;
        private System.Windows.Forms.DataGridViewButtonColumn Option;
        private System.Windows.Forms.Button button_insert;
    }
}
