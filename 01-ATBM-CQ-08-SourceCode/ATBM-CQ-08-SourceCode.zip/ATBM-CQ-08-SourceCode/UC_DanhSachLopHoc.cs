﻿using NPOI.POIFS.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using ATBM;


namespace ATBM
{
    public partial class UC_DanhSachLopHoc : UserControl
    {
        public UC_DanhSachLopHoc()
        {
            InitializeComponent();
        }
        string current_LopHoc = ATBM.UC_LopHoc.current_LopHoc;
        
        static public class Selected_infor
        {
            public static string MASV;
            public static string MAHP;
            public static string HK;
            public static string NAM;
            public static string MACT;

            public static string DiemTH;
            public static string DiemLT;
            public static string DiemCK;
            public static string DiemTK;
        }

        private void label_LopHoc_Click(object sender, EventArgs e)
        {
            //Kiểm tra đây có phải là Form_TruongDV không
            if(this.FindForm() is Form_TruongDV)
            {
                Form_TruongDV form = (Form_TruongDV)this.FindForm();
                form.panel_ControlContainer.Controls.Remove(this);

                foreach (Control control in form.panel_ControlContainer.Controls)
                {
                    if (control is UC_LopHoc)
                    {
                        form.open_UC_control(control);
                    }
                }
            }

            else if(this.FindForm() is Form_Home_GV)
            {
                Form_Home_GV form = (Form_Home_GV)this.FindForm();
                form.panel_ControlContainer.Controls.Remove(this);

                foreach (Control control in form.panel_ControlContainer.Controls)
                {
                    if (control is UC_LopHoc)
                    {
                        form.open_UC_control(control);
                    }
                }
            }

            //Kiểm tra đây có phải là Form_TrgKhoa không
            else if (this.FindForm() is Form_TrgKhoa)
            {
                Form_TrgKhoa form = (Form_TrgKhoa)this.FindForm();
                form.panel_ControlContainer.Controls.Remove(this);

                foreach (Control control in form.panel_ControlContainer.Controls)
                {
                    if (control is UC_LopHoc)
                    {
                        form.open_UC_control(control);
                    }
                }
            }
        }

        private void UC_DanhSachLopHoc_Load(object sender, EventArgs e)
        {
            label_Current.Text += current_LopHoc;
            // current lớp học là từ nội dung cell của datagridview
            Selected_infor.MAHP = current_LopHoc.Split('-')[0];
            Selected_infor.HK = current_LopHoc.Split('-')[1];
            Selected_infor.NAM = current_LopHoc.Split('-')[2];
            Selected_infor.MACT = current_LopHoc.Split('-')[3];

            textBox_filter_SinhVien_DSL.Text = "";

            this.button_TimKiem_SinhVien_DSL_Click(sender, e);
        }

        private void button_TimKiem_SinhVien_DSL_Click(object sender, EventArgs e)
        {
            Selected_infor.MASV = this.textBox_filter_SinhVien_DSL.Text;

            // Lấy danh sách sinh viên bằng cách truy vấn vào Procedure 
            try
            {
                using (OracleConnection connection = new OracleConnection(ConnectionStr.connectionStr))
                {
                    connection.Open();

                    OracleCommand cmd = new OracleCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "admin1.USP_Select_DK_GV";
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Input parameters
                    cmd.Parameters.Add("p_masv", OracleDbType.Varchar2).Value = Selected_infor.MASV;
                    cmd.Parameters.Add("p_mahp", OracleDbType.Varchar2).Value = Selected_infor.MAHP;
                    cmd.Parameters.Add("p_hk", OracleDbType.Int32).Value = Selected_infor.HK;
                    cmd.Parameters.Add("p_nam", OracleDbType.Int32).Value = Selected_infor.NAM;
                    cmd.Parameters.Add("p_mact", OracleDbType.Varchar2).Value = Selected_infor.MACT;



                    // Output parameters
                    OracleParameter refcur = new OracleParameter("p_result", OracleDbType.RefCursor);
                    refcur.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(refcur);

                    OracleParameter errorCodeParam = new OracleParameter("p_error_code", OracleDbType.Int32);
                    errorCodeParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(errorCodeParam);

                    OracleParameter errorMsgParam = new OracleParameter("p_error_msg", OracleDbType.Varchar2, 1000);
                    errorMsgParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(errorMsgParam);

                    OracleDataReader dr = cmd.ExecuteReader();

                    DataTable dataTable = new DataTable();
                    dataTable.Load(dr);
                    dataGridView_DanhSachLopHoc.DataSource = dataTable;
                    connection.Close();

                }
                dataGridView_DanhSachLopHoc.Columns["MASV"].HeaderText = "Mã Sinh Viên";
                dataGridView_DanhSachLopHoc.Columns["DIEMQT"].HeaderText = "Điểm Quá Trình";
                dataGridView_DanhSachLopHoc.Columns["DIEMTH"].HeaderText = "Điểm Thực Hành";
                dataGridView_DanhSachLopHoc.Columns["DIEMCK"].HeaderText = "Điểm Cuối Kỳ";
                dataGridView_DanhSachLopHoc.Columns["DIEMTK"].HeaderText = "Điểm Tổng Kết";

            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có
                MessageBox.Show("ERROR: " + ex.Message);
            }

            this.dataGridView_DanhSachLopHoc.Columns["Update"].DisplayIndex = dataGridView_DanhSachLopHoc.ColumnCount - 1;

        }

        private void dataGridView_DanhSachLopHoc_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Selected_infor.MASV = dataGridView_DanhSachLopHoc.Rows[e.RowIndex].Cells[1].Value.ToString();
            Selected_infor.DiemLT = dataGridView_DanhSachLopHoc.Rows[e.RowIndex].Cells[2].Value.ToString();
            Selected_infor.DiemTH = dataGridView_DanhSachLopHoc.Rows[e.RowIndex].Cells[3].Value.ToString();
            Selected_infor.DiemCK = dataGridView_DanhSachLopHoc.Rows[e.RowIndex].Cells[4].Value.ToString();
            Selected_infor.DiemTK = dataGridView_DanhSachLopHoc.Rows[e.RowIndex].Cells[5].Value.ToString();

            Form_Update_diem update_Diem = new Form_Update_diem();
            update_Diem.ShowDialog();
            // load lại khi đóng form update
            
            update_Diem.FormClosed += (s, args) => this.button_TimKiem_SinhVien_DSL_Click(s, args);
            this.button_TimKiem_SinhVien_DSL_Click(sender, e);
        }
    }
}
